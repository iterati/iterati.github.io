#!/bin/sh

osascript -e 'tell app "Terminal" to do script "
/Applications/Arduino.app/Contents/Java/hardware/tools/avr/bin/avrdude     -C/Applications/Arduino.app/Contents/Java/hardware/tools/avr/etc/avrdude.conf     -v -patmega328p -carduino -P/dev/cu.SLAB_USBtoUART -b115200 -D     -Uflash:w:\"/Volumes/Vectr 011316/Upload .hex.app/Contents/MacOS/firmware.hex\":i"'
