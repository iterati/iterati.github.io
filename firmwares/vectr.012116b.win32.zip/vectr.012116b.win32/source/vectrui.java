import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.event.KeyEvent; 
import processing.serial.*; 
import controlP5.*; 
import javax.swing.JFileChooser; 
import javax.swing.filechooser.FileNameExtensionFilter; 
import java.util.ArrayList; 
import java.util.Map; 
import java.util.ArrayList; 
import java.util.logging.Level; 
import processing.core.PApplet; 
import processing.core.PGraphics; 
import processing.core.PVector; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class vectrui extends PApplet {








static final int SER_DUMP       = 10;
static final int SER_SAVE       = 20;
static final int SER_READ       = 30;
static final int SER_WRITE      = 40;
static final int SER_MODE_SET   = 90;
static final int SER_VIEW_MODE  = 100;
static final int SER_VIEW_COLOR = 101;
static final int SER_HANDSHAKE  = 250;
static final int SER_DISCONNECT = 251;

Serial ports[] = new Serial[10];
int num_ports = 0;
Serial port = null;
ControlP5 cp5;

int gui_state = 0;
Boolean initialized = false;
Boolean reading = false;
Boolean flashing = false;

int cur_mode = 0;
Mode[] modes = new Mode[7];
Mode[] loaded_modes = new Mode[7];

Editor editor;
int counter = 0;
boolean view_mode = true;


public void printColor(int c) {
  int r = (c & 0xff0000) >> 16;
  int g = (c & 0x00ff00) >> 8;
  int b = (c & 0x0000ff) >> 0;
  /* println(r + ", " + g + ", " + b); */
}

public void setup() {
  surface.setTitle("VectrUI 01-21-16");
  
  cp5 = new ControlP5(this);
  /* cp5.setFont(createFont("Arial-Black", 11)); */
  cp5.setFont(createFont("Comfortaa-Bold", 14));

  editor = new Editor(0, 0);

  for (int i = 0; i < 7; i++) {
    modes[i] = new Mode();
    loaded_modes[i] = new Mode();
  }
}

public void connectLight() {
  for (String p: Serial.list()) {
    try {
      if (num_ports < 10) {
        ports[num_ports] = new Serial(this, p, 115200);
        num_ports++;
      }
    } catch (Exception e) {
    }
  }
}

public void draw() {
  background(192);
  if (!initialized) {
    connectLight();
  }

  if (port == null) {
    for (int i = 0; i < num_ports; i++) {
      if (ports[i].available() >= 3) {
        /* println("Narrowed it down from " + num_ports); */
        port = ports[i];
        readCommand();
      }
    }
  } else {
    while (port.available() >= 3) {
      readCommand();
    }
  }

  if (!initialized || reading || flashing) {
    editor.group.hide();
  } else {
    editor.group.show();
  }
}

public void readCommand() {
  int target = port.read();
  int addr = port.read();
  int val = port.read();
  /* println("in << " + target + " " + addr + " " + val); */

  if (target == SER_HANDSHAKE) {        // Light wants to connect
    if (addr == 100 && val == 100) {
      initialized = true;
      reading = true;
      sendCommand(SER_HANDSHAKE, 100, 13, 13);
    }
  } else if (target == 251) { // Light acked handshake
    cur_mode = addr;
    sendCommand(SER_DUMP, 200, 0, 0);
  } else if (target == 200) { // Start of a dump
    // addr is the mode about to be dumped, val is the current mode
    cur_mode = val;
    reading = true;
    if (flashing) {
    }
  } else if (target == 210) { // End of a dump
    // addr is the mode just dumped, val is the current mode
    cur_mode = val;
    editor.curModeChanged(cur_mode);
    reading = false;
    if (flashing) {
      sendMode(cur_mode);
      cur_mode++;
      if (cur_mode == 7) {
        flashing = false;
        sendCommand(SER_MODE_SET, 0, 0, 0);
      } else {
        sendCommand(SER_MODE_SET, cur_mode, 0, 0);
      }
    }
  } else if (target < 7) {    // Data on a mode
    modes[target].seta(addr, val);
  } else if (target == 100) {
    modes[cur_mode].seta(addr, val);
    editor.seta(addr, val);
  }
}

public void writeToLight(int target, int addr, int val) {
  sendCommand(SER_WRITE, target, addr, val);

  /* int rtarget = port.read(); */
  /* int raddr = port.read(); */
  /* int rval = port.read(); */

  /* if (addr != raddr || val != rval) { */
  /*   print("light didn't listen "); */
  /*   println(rtarget + " " + raddr + " " + rval); */
  /* } else { */
    if (target == 100) {
      modes[cur_mode].seta(addr, val);
    } else if (target < 7) {
      modes[target].seta(addr, val);
    }
  /* } */
}

public void sendCommand(int cmd, int target, int addr, int val) {
  /* println("out>>" + cmd + " " + target + " " + addr + " " + val); */

  if (initialized) {
    port.write(cmd);
    port.write(target);
    port.write(addr);
    port.write(val);
  }
}

public void controlEvent(CallbackEvent theEvent) {
  Controller eController = theEvent.getController();
  String eName = eController.getName();
  float eVal = eController.getValue();
  int eId = eController.getId();
  int eAction = theEvent.getAction();

  if (eController.equals(editor.patternThresh)) {
    if (eAction == ControlP5.ACTION_RELEASED || eAction == ControlP5.ACTION_RELEASEDOUTSIDE) {
      sendCommand(SER_WRITE, 100, 4, (int)editor.patternThresh.getMinA());
      sendCommand(SER_WRITE, 100, 5, (int)editor.patternThresh.getMaxA());
      sendCommand(SER_WRITE, 100, 6, (int)editor.patternThresh.getMinB());
      sendCommand(SER_WRITE, 100, 7, (int)editor.patternThresh.getMaxB());
    }
  } else if (eController.equals(editor.colorThresh)) {
    if (eAction == ControlP5.ACTION_RELEASED || eAction == ControlP5.ACTION_RELEASEDOUTSIDE) {
      sendCommand(SER_WRITE, 100, 8, (int)editor.colorThresh.getMinA());
      sendCommand(SER_WRITE, 100, 9, (int)editor.colorThresh.getMaxA());
      sendCommand(SER_WRITE, 100, 10, (int)editor.colorThresh.getMinB());
      sendCommand(SER_WRITE, 100, 11, (int)editor.colorThresh.getMaxB());
    }
  } else if (eController.equals(editor.base)) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      sendPatternChange((int)eVal);
      editor.patternChanged((int)eVal);
      editor.curModeChanged(cur_mode);
    } else if (eAction == ControlP5.ACTION_LEAVE) {
      editor.base.close();
    }
  } else if (eController.equals(editor.prevMode)) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      view_mode = true;
      editor.viewMode.setColorBackground(color(0, 90, 180));
      editor.viewColor.setColorBackground(color(0, 45, 90));
      sendCommand(SER_VIEW_MODE, 0, 0, 0);
      sendCommand(SER_MODE_SET, 99, 0, 0);
    }
  } else if (eController.equals(editor.nextMode)) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      view_mode = true;
      editor.viewMode.setColorBackground(color(0, 90, 180));
      editor.viewColor.setColorBackground(color(0, 45, 90));
      sendCommand(SER_VIEW_MODE, 0, 0, 0);
      sendCommand(SER_MODE_SET, 101, 0, 0);
    }
  } else if (eController.equals(editor.saveMode)) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      saveModeFile();
    }
  } else if (eController.equals(editor.loadMode)) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      openModeFile();
    }
  } else if (eController.equals(editor.writeMode)) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      sendCommand(SER_SAVE, 0, 0, 0);
    }
  } else if (eController.equals(editor.resetMode)) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      sendCommand(SER_MODE_SET, cur_mode, 0, 0);
    }
  } else if (eController.equals(editor.saveLight)) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      saveLightFile();
    }
  } else if (eController.equals(editor.writeLight)) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      openLightFile();
    }
  } else if (eController.equals(editor.disconnectLight)) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      sendCommand(SER_DISCONNECT, 0, 0, 0);
      initialized = false;
    }
  } else if (eController.equals(editor.viewMode)) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      if (!view_mode) {
        sendCommand(SER_VIEW_MODE, 0, 0, 0);
        view_mode = true;
        editor.viewMode.setColorBackground(color(0, 90, 180));
        editor.viewColor.setColorBackground(color(0, 45, 90));
      }
    }
  } else if (eController.equals(editor.viewColor)) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      if (view_mode) {
        sendCommand(SER_VIEW_COLOR, editor.color_set, editor.color_slot, 0);
        view_mode = false;
        editor.viewMode.setColorBackground(color(0, 45, 90));
        editor.viewColor.setColorBackground(color(0, 90, 180));
      }
    }
  } else if (eName.startsWith("editorArgs")) {
    if (eAction == ControlP5.ACTION_RELEASED ||
        eAction == ControlP5.ACTION_RELEASEDOUTSIDE) {
      sendCommand(SER_WRITE, 100, eId, (int)eVal);
    } else if (eAction == ControlP5.ACTION_BROADCAST) {
      sendCommand(SER_WRITE, 100, eId, (int)eVal);
    }
  } else if (eName.startsWith("editorTimings")) {
    if (eAction == ControlP5.ACTION_RELEASED ||
        eAction == ControlP5.ACTION_RELEASEDOUTSIDE) {
      sendCommand(SER_WRITE, 100, eId, (int)eVal);
    } else if (eAction == ControlP5.ACTION_BROADCAST) {
      sendCommand(SER_WRITE, 100, eId, (int)eVal);
    }
  } else if (eName.startsWith("editorNumColors")) {
    if (eAction == ControlP5.ACTION_RELEASED ||
        eAction == ControlP5.ACTION_RELEASEDOUTSIDE) {
      sendCommand(SER_WRITE, 100, eId, (int)eVal);
      editor.numColorsChanged(eId - 1, (int)eVal);
    } else if (eAction == ControlP5.ACTION_BROADCAST) {
      sendCommand(SER_WRITE, 100, eId, (int)eVal);
      editor.numColorsChanged(eId - 1, (int)eVal);
    }
  } else if (eId == 1000) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      editor.selectColor(eVal);
      if (!view_mode) {
        sendCommand(SER_VIEW_COLOR, editor.color_set, editor.color_slot, 0);
      }
    }
  } else if (eName.startsWith("editorColorValues")) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      if (editor.color_set >= 0 && editor.color_slot >= 0) {
        sendCommand(SER_WRITE, 100, 33 + (editor.color_slot * 9) + (editor.color_set * 3) + (eId - 500), (int)eVal);
        editor.seta(33 + (editor.color_slot * 9) + (editor.color_set * 3) + (eId - 500), (int)eVal);
      }
    }
  } else if (eId >= 2000 && eId < 2100) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      if (editor.color_set >= 0 && editor.color_slot >= 0) {
        sendCommand(SER_WRITE, 100, 33 + (editor.color_slot * 9) + (editor.color_set * 3), color_bank[eId - 2000][0]);
        sendCommand(SER_WRITE, 100, 34 + (editor.color_slot * 9) + (editor.color_set * 3), color_bank[eId - 2000][1]);
        sendCommand(SER_WRITE, 100, 35 + (editor.color_slot * 9) + (editor.color_set * 3), color_bank[eId - 2000][2]);
        editor.seta(33 + (editor.color_slot * 9) + (editor.color_set * 3), color_bank[eId - 2000][0]);
        editor.seta(34 + (editor.color_slot * 9) + (editor.color_set * 3), color_bank[eId - 2000][1]);
        editor.seta(35 + (editor.color_slot * 9) + (editor.color_set * 3), color_bank[eId - 2000][2]);
        editor.selectColor(editor.color_set, editor.color_slot);
      }
    }
  }
}

public void sendMode(int m) {
  Mode mode = (m == 100) ? modes[cur_mode] : loaded_modes[m];
  writeToLight(m, 0, mode.pattern);
  for (int i = 0; i < 3; i++) {
    writeToLight(m, i + 1, mode.numColors[i]);
  }
  for (int i = 0; i < 4; i++) {
    writeToLight(m, i + 4, mode.patternThresh[i / 2][i % 2]);
  }
  for (int i = 0; i < 4; i++) {
    writeToLight(m, i + 8, mode.colorThresh[i / 2][i % 2]);
  }
  for (int i = 0; i < 3; i++) {
    writeToLight(m, i + 12, mode.args[i]);
  }
  for (int i = 0; i < 18; i++) {
    writeToLight(m, i + 15, mode.timings[i / 6][i % 6]);
  }
  for (int i = 0; i < 81; i++) {
    writeToLight(m, i + 33, mode.colors[i / 9][(i % 9) / 3][i % 3]);
  }
}

public void sendPatternChange(int v) {
  sendCommand(SER_WRITE, 100, 0, v);
  // Set all args to 0
  for (int i = 0; i < 3; i++) { sendCommand(SER_WRITE, 100, 12 + i, 0); }

  if (v == 0) { // Strobe
    sendCommand(SER_WRITE, 100, 15, 9);
    sendCommand(SER_WRITE, 100, 16, 41);
    sendCommand(SER_WRITE, 100, 17, 0);
    sendCommand(SER_WRITE, 100, 18, 0);
    sendCommand(SER_WRITE, 100, 19, 0);
    sendCommand(SER_WRITE, 100, 20, 0);

    sendCommand(SER_WRITE, 100, 21, 25);
    sendCommand(SER_WRITE, 100, 22, 25);
    sendCommand(SER_WRITE, 100, 23, 0);
    sendCommand(SER_WRITE, 100, 24, 0);
    sendCommand(SER_WRITE, 100, 25, 0);
    sendCommand(SER_WRITE, 100, 26, 0);

    sendCommand(SER_WRITE, 100, 27, 3);
    sendCommand(SER_WRITE, 100, 28, 22);
    sendCommand(SER_WRITE, 100, 29, 0);
    sendCommand(SER_WRITE, 100, 30, 0);
    sendCommand(SER_WRITE, 100, 31, 0);
    sendCommand(SER_WRITE, 100, 32, 0);
  } else if (v == 1) { // Vexer
    sendCommand(SER_WRITE, 100, 15, 9);
    sendCommand(SER_WRITE, 100, 16, 0);
    sendCommand(SER_WRITE, 100, 17, 41);
    sendCommand(SER_WRITE, 100, 18, 0);
    sendCommand(SER_WRITE, 100, 19, 0);
    sendCommand(SER_WRITE, 100, 20, 0);

    sendCommand(SER_WRITE, 100, 21, 5);
    sendCommand(SER_WRITE, 100, 22, 0);
    sendCommand(SER_WRITE, 100, 23, 45);
    sendCommand(SER_WRITE, 100, 24, 0);
    sendCommand(SER_WRITE, 100, 25, 0);
    sendCommand(SER_WRITE, 100, 26, 0);

    sendCommand(SER_WRITE, 100, 27, 3);
    sendCommand(SER_WRITE, 100, 28, 0);
    sendCommand(SER_WRITE, 100, 29, 47);
    sendCommand(SER_WRITE, 100, 30, 0);
    sendCommand(SER_WRITE, 100, 31, 0);
    sendCommand(SER_WRITE, 100, 32, 0);
  } else if (v == 2) { // Edge
    sendCommand(SER_WRITE, 100, 15, 3);
    sendCommand(SER_WRITE, 100, 16, 0);
    sendCommand(SER_WRITE, 100, 17, 8);
    sendCommand(SER_WRITE, 100, 18, 50);
    sendCommand(SER_WRITE, 100, 19, 0);
    sendCommand(SER_WRITE, 100, 20, 0);

    sendCommand(SER_WRITE, 100, 21, 2);
    sendCommand(SER_WRITE, 100, 22, 0);
    sendCommand(SER_WRITE, 100, 23, 8);
    sendCommand(SER_WRITE, 100, 24, 50);
    sendCommand(SER_WRITE, 100, 25, 0);
    sendCommand(SER_WRITE, 100, 26, 0);

    sendCommand(SER_WRITE, 100, 27, 1);
    sendCommand(SER_WRITE, 100, 28, 0);
    sendCommand(SER_WRITE, 100, 29, 8);
    sendCommand(SER_WRITE, 100, 30, 50);
    sendCommand(SER_WRITE, 100, 31, 0);
    sendCommand(SER_WRITE, 100, 32, 0);
  } else if (v == 3) { // Double
    sendCommand(SER_WRITE, 100, 15, 25);
    sendCommand(SER_WRITE, 100, 16, 0);
    sendCommand(SER_WRITE, 100, 17, 25);
    sendCommand(SER_WRITE, 100, 18, 0);
    sendCommand(SER_WRITE, 100, 19, 25);
    sendCommand(SER_WRITE, 100, 20, 0);

    sendCommand(SER_WRITE, 100, 21, 25);
    sendCommand(SER_WRITE, 100, 22, 0);
    sendCommand(SER_WRITE, 100, 23, 5);
    sendCommand(SER_WRITE, 100, 24, 0);
    sendCommand(SER_WRITE, 100, 25, 25);
    sendCommand(SER_WRITE, 100, 26, 0);

    sendCommand(SER_WRITE, 100, 27, 5);
    sendCommand(SER_WRITE, 100, 28, 0);
    sendCommand(SER_WRITE, 100, 29, 5);
    sendCommand(SER_WRITE, 100, 30, 0);
    sendCommand(SER_WRITE, 100, 31, 25);
    sendCommand(SER_WRITE, 100, 32, 0);
  } else if (v == 4) { // Runner
    sendCommand(SER_WRITE, 100, 15, 3);
    sendCommand(SER_WRITE, 100, 16, 22);
    sendCommand(SER_WRITE, 100, 17, 3);
    sendCommand(SER_WRITE, 100, 18, 22);
    sendCommand(SER_WRITE, 100, 19, 25);
    sendCommand(SER_WRITE, 100, 20, 0);

    sendCommand(SER_WRITE, 100, 21, 25);
    sendCommand(SER_WRITE, 100, 22, 25);
    sendCommand(SER_WRITE, 100, 23, 3);
    sendCommand(SER_WRITE, 100, 24, 22);
    sendCommand(SER_WRITE, 100, 25, 25);
    sendCommand(SER_WRITE, 100, 26, 0);

    sendCommand(SER_WRITE, 100, 27, 3);
    sendCommand(SER_WRITE, 100, 28, 22);
    sendCommand(SER_WRITE, 100, 29, 25);
    sendCommand(SER_WRITE, 100, 30, 25);
    sendCommand(SER_WRITE, 100, 31, 25);
    sendCommand(SER_WRITE, 100, 32, 0);
  } else if (v == 5) { // Stepper
    sendCommand(SER_WRITE, 100, 15, 25);
    sendCommand(SER_WRITE, 100, 16, 5);
    sendCommand(SER_WRITE, 100, 17, 10);
    sendCommand(SER_WRITE, 100, 18, 15);
    sendCommand(SER_WRITE, 100, 19, 20);
    sendCommand(SER_WRITE, 100, 20, 25);

    sendCommand(SER_WRITE, 100, 21, 25);
    sendCommand(SER_WRITE, 100, 22, 5);
    sendCommand(SER_WRITE, 100, 23, 10);
    sendCommand(SER_WRITE, 100, 24, 15);
    sendCommand(SER_WRITE, 100, 25, 20);
    sendCommand(SER_WRITE, 100, 26, 25);

    sendCommand(SER_WRITE, 100, 27, 25);
    sendCommand(SER_WRITE, 100, 28, 5);
    sendCommand(SER_WRITE, 100, 29, 10);
    sendCommand(SER_WRITE, 100, 30, 15);
    sendCommand(SER_WRITE, 100, 31, 20);
    sendCommand(SER_WRITE, 100, 32, 25);
  } else if (v == 6) { // Random
    sendCommand(SER_WRITE, 100, 15, 1);
    sendCommand(SER_WRITE, 100, 16, 5);
    sendCommand(SER_WRITE, 100, 17, 10);
    sendCommand(SER_WRITE, 100, 18, 20);
    sendCommand(SER_WRITE, 100, 19, 0);
    sendCommand(SER_WRITE, 100, 20, 0);

    sendCommand(SER_WRITE, 100, 21, 1);
    sendCommand(SER_WRITE, 100, 22, 5);
    sendCommand(SER_WRITE, 100, 23, 10);
    sendCommand(SER_WRITE, 100, 24, 20);
    sendCommand(SER_WRITE, 100, 25, 0);
    sendCommand(SER_WRITE, 100, 26, 0);

    sendCommand(SER_WRITE, 100, 27, 1);
    sendCommand(SER_WRITE, 100, 28, 5);
    sendCommand(SER_WRITE, 100, 29, 10);
    sendCommand(SER_WRITE, 100, 30, 20);
    sendCommand(SER_WRITE, 100, 31, 0);
    sendCommand(SER_WRITE, 100, 32, 0);
  }
}


public void openLightFile() {
  selectInput("Select light file to flash to light", "_openLightFile");
}

public void _openLightFile(File file) {
  if (file == null) {
  } else {
    try {
      String path = file.getAbsolutePath();
      JSONArray jarr = loadJSONArray(path);
      for (int i = 0; i < 7; i++) {
        loaded_modes[i].fromJSON(jarr.getJSONObject(i));
      }
      flashing = true;
      sendCommand(SER_MODE_SET, 0, 0, 0);
    } catch (Exception ex) {
      // TODO popup error message
    }
  }
}


public void saveLightFile() {
  selectOutput("Select light file to save to", "_saveLightFile");
}

public void _saveLightFile(File file) {
  if (file == null) {
  } else {
    try {
      String path = file.getAbsolutePath();
      if (!path.endsWith(".light")) {
        path += ".light";
      }
      JSONArray jarr = new JSONArray();
      for (int i = 0; i < 7; i++) {
        jarr.setJSONObject(i, modes[i].asJSON());
      }
      saveJSONArray(jarr, path, "compact");
    } catch (Exception ex) {
      // TODO popup error message
    }
  }
}

public void openModeFile() {
  selectInput("Select mode file to load", "_openModeFile");
}

public void _openModeFile(File file) {
  if (file == null) {
  } else {
    try {
      String path = file.getAbsolutePath();
      modes[cur_mode].fromJSON(loadJSONObject(path));
      sendMode(100);
      editor.curModeChanged(cur_mode);
    } catch (Exception ex) {
      // TODO popup error message
    }
  }
}

public void saveModeFile() {
  selectOutput("Select mode file to save", "_saveModeFile");
}

public void _saveModeFile(File file) {
  if (file == null) {
  } else {
    try {
      String path = file.getAbsolutePath();
      if (!path.endsWith(".mode")) {
        path += ".mode";
      }
      saveJSONObject(modes[cur_mode].asJSON(), path, "compact");
    } catch (Exception ex) {
      // TODO popup error message
    }
  }
}



final static String[] PATTERNS = {
  "Strobe",
  "Vexer",
  "Edge",
  "Double",
  "Runner",
  "Stepper",
  "Random",
};

final static int color_bank[][] = {
  {0, 0, 0},
  {56, 64, 72},
  {24, 0, 0},
  {16, 16, 0},
  {0, 24, 0},
  {0, 16, 16},
  {0, 0, 24},
  {16, 0, 16},
  {255, 0, 0},
  {224, 32, 0},
  {192, 64, 0},
  {160, 96, 0},
  {128, 128, 0},
  {96, 160, 0},
  {64, 192, 0},
  {32, 224, 0},
  {0, 255, 0},
  {0, 224, 32},
  {0, 192, 64},
  {0, 160, 96},
  {0, 128, 128},
  {0, 96, 160},
  {0, 64, 192},
  {0, 32, 224},
  {0, 0, 255},
  {32, 0, 224},
  {64, 0, 192},
  {96, 0, 160},
  {128, 0, 128},
  {160, 0, 96},
  {192, 0, 64},
  {224, 0, 32},
  {64, 64, 64},
  {160, 16, 16},
  {16, 160, 16},
  {16, 16, 160},
  {128, 8, 48},
  {80, 48, 48},
  {128, 48, 8},
  {80, 80, 8},
  {48, 128, 8},
  {48, 80, 48},
  {8, 128, 48},
  {8, 80, 80},
  {8, 48, 128},
  {48, 48, 80},
  {48, 8, 128},
  {80, 8, 80},
};


class Editor {
  // GUI
  Group group;
  Textlabel title;
  Button nextMode;
  Button prevMode;
  DropdownList base;
  ThreshRange patternThresh;
  ThreshRange colorThresh;

  Textlabel[] argLabels = new Textlabel[3];
  Slider[] args = new Slider[3];

  Textlabel[] timingLabels = new Textlabel[6];
  Slider[][] timings = new Slider[3][6];

  Textlabel[] colorLabels = new Textlabel[3];
  Slider[] numColors = new Slider[3];
  Button[][] colors = new Button[3][9];
  Button colorSelect;
  int color_set = -1;
  int color_slot = -1;

  Slider[] colorValues = new Slider[3];
  Button[][] colorButtons = new Button[2][48];

  Button saveMode;
  Button loadMode;
  Button writeMode;
  Button resetMode;
  Button saveLight;
  Button writeLight;
  Button disconnectLight;
  Button viewMode;
  Button viewColor;

  Editor(int x, int y) {
    group = cp5.addGroup("editor")
      .setPosition(x, y)
      .setWidth(1000)
      .setHeight(800)
      .hideBar()
      .hideArrow();

    title = cp5.addTextlabel("editorTitle")
      .setGroup(group)
      .setValue("Mode 1")
      .setFont(createFont("Comfortaa-Regular", 32))
      .setPosition(443, 5)
      .setColorValue(color(0));

    patternThresh = new ThreshRange(cp5, "editorPatternThresh")
      .setBroadcast(false)
      .setGroup(group)
      .setLabel("Pattern Thresholds")
      .setBroadcast(true);
    patternThresh.setPosition((group.getWidth() - patternThresh.getWidth()) / 2, 130);
    style("editorPatternThresh");

    colorThresh = new ThreshRange(cp5, "editorColorThresh")
      .setBroadcast(false)
      .setGroup(group)
      .setLabel("Color Set Thresholds")
      .setBroadcast(true);
    colorThresh.setPosition((group.getWidth() - colorThresh.getWidth()) / 2, 400);
    style("editorColorThresh");

    colorSelect = cp5.addButton("editorColorSelect")
      .setGroup(group)
      .setSize(40, 40)
      .setPosition(0, 0)
      .setCaptionLabel("")
      .setColorBackground(color(255))
      .hide();

    for (int i = 0; i < 3; i++) {
      args[i] = cp5.addSlider("editorArgs" + i)
        .setBroadcast(false)
        .setCaptionLabel("")
        .setGroup(group)
        .setId(12 + i)
        .setSize(250, 20)
        .setPosition(125 + (i * 275), 70)
        .setColorBackground(color(32))
        .setColorActive(color(96))
        .setRange(0, 9)
        .setNumberOfTickMarks(10)
        .showTickMarks(false)
        .setDecimalPrecision(0)
        .setValue(0)
        .setBroadcast(true)
        .hide();

      for (int j = 0; j < 6; j++) {
        timings[i][j] = cp5.addSlider("editorTimings" + i + "." + j)
          .setBroadcast(false)
          .setCaptionLabel("")
          .setGroup(group)
          .setId(15 + (6 * i) + j)
          .setSize(250, 20)
          .setPosition(125 + (i * 275), 180 + (j * 30))
          .setColorBackground(color(32))
          .setColorActive(color(96))
          .setRange(0, 250)
          .setNumberOfTickMarks(251)
          .showTickMarks(false)
          .setDecimalPrecision(0)
          .setValue(0)
          .setBroadcast(true)
          .hide();
      }

      for (int j = 0; j < 9; j++) {
        colors[i][j] = cp5.addButton("editorColor" + i + "." + j, (i * 9) + j)
          .setId(1000)
          .setGroup(group)
          .setSize(32, 32)
          .setPosition(284 + (40 * j), 454 + (50 * i))
          .setCaptionLabel("")
          .setColorBackground(color(0));
      }

      colorLabels[i] = cp5.addTextlabel("editorColorLabels" + i)
        .setGroup(group)
        .setValue("Color Set " + (i + 1))
        .setPosition(30, 462 + (i * 50))
        .setColorValue(color(0));

      numColors[i] = cp5.addSlider("editorNumColors" + i)
        .setBroadcast(false)
        .setCaptionLabel("")
        .setGroup(group)
        .setId(1 + i)
        .setSize(150, 20)
        .setPosition(110, 460 + (i * 50))
        .setColorBackground(color(32))
        .setColorActive(color(96))
        .setRange(1, 9)
        .setNumberOfTickMarks(9)
        .showTickMarks(false)
        .setDecimalPrecision(0)
        .setBroadcast(true);
      style("editorNumColors" + i);
    }

    for (int i = 0; i < 3; i++) {
      argLabels[i] = cp5.addTextlabel("editorArgLabels" + i)
        .setGroup(group)
        .setValue("Arg")
        .setPosition(125 + (i * 275), 52)
        .setColorValue(color(0))
        .hide();
    }

    for (int i = 0; i < 6; i++) {
      timingLabels[i] = cp5.addTextlabel("editorTimingLabels" + i)
        .setGroup(group)
        .setValue("Timing")
        .setPosition(30, 182 + (i * 30))
        .setColorValue(color(0))
        .hide();
    }

    colorValues[0] = cp5.addSlider("editorColorValuesR")
      .setBroadcast(false)
      .setCaptionLabel("")
      .setGroup(group)
      .setId(500)
      .setSize(256, 20)
      .setPosition(660, 460)
      .setColorBackground(color(96, 0, 0))
      .setColorForeground(color(192, 0, 0))
      .setColorActive(color(255, 0, 0))
      .setRange(0, 255)
      .setNumberOfTickMarks(256)
      .showTickMarks(false)
      .setDecimalPrecision(0)
      .setValue(0)
      .setBroadcast(true);

    colorValues[1] = cp5.addSlider("editorColorValuesG")
      .setBroadcast(false)
      .setCaptionLabel("")
      .setGroup(group)
      .setId(501)
      .setSize(256, 20)
      .setPosition(660, 490)
      .setColorBackground(color(0, 96, 0))
      .setColorForeground(color(0, 192, 0))
      .setColorActive(color(0, 255, 0))
      .setRange(0, 255)
      .setNumberOfTickMarks(256)
      .showTickMarks(false)
      .setDecimalPrecision(0)
      .setValue(0)
      .setBroadcast(true);

    colorValues[2] = cp5.addSlider("editorColorValuesB")
      .setBroadcast(false)
      .setCaptionLabel("")
      .setGroup(group)
      .setId(502)
      .setSize(256, 20)
      .setPosition(660, 520)
      .setColorBackground(color(0, 0, 96))
      .setColorForeground(color(0, 0, 192))
      .setColorActive(color(0, 0, 255))
      .setRange(0, 255)
      .setNumberOfTickMarks(256)
      .showTickMarks(false)
      .setDecimalPrecision(0)
      .setValue(0)
      .setBroadcast(true);

    for (int i = 0; i < 48; i++) {
        colorButtons[0][i] = cp5.addButton("editorColorBankA" + i)
          .setId(2000 + i)
          .setGroup(group)
          .setSize(16, 16)
          .setPosition(22 + (20 * i), 607)
          .setCaptionLabel("")
          .setColorActive(translateColor(i))
          .setColorForeground(translateColor(i))
          .setColorBackground(translateColor(i));
        /*
        colorButtons[1][i] = cp5.addButton("editorColorBankB" + i)
          .setId(2048 + i)
          .setGroup(group)
          .setSize(16, 16)
          .setPosition(22 + (20 * i), 632)
          .setCaptionLabel("")
          .setColorActive(translateColor(48 + i))
          .setColorForeground(translateColor(48 + i))
          .setColorBackground(translateColor(48 + i));
        */
    }

    base = cp5.addDropdownList("editorBase")
      .setGroup(group)
      .setLabel("Base Pattern")
      .setPosition(30, 70)
      .setSize(80, 160)
      .setItems(PATTERNS)
      .setItemHeight(20)
      .setBarHeight(20);
    base.getCaptionLabel().toUpperCase(false);
    base.getValueLabel().toUpperCase(false);
    base.getCaptionLabel().getStyle().setPadding(4, 0, 0, 4);
    base.getValueLabel().getStyle().setPadding(4, 0, 0, 4);
    base.close();

    prevMode = cp5.addButton("editorPrevMode")
      .setCaptionLabel("<< Prev")
      .setGroup(group)
      .setSize(60, 20)
      .setPosition(340, 15);
    prevMode.getCaptionLabel().toUpperCase(false);
    prevMode.getCaptionLabel().getStyle().setPadding(-1, 0, 0, 0);

    nextMode = cp5.addButton("editorNextMode")
      .setCaptionLabel("Next >>")
      .setGroup(group)
      .setSize(60, 20)
      .setPosition(600, 15);
    nextMode.getCaptionLabel().toUpperCase(false);
    nextMode.getCaptionLabel().getStyle().setPadding(-1, 0, 0, 0);

    resetMode = cp5.addButton("editorResetMode")
      .setCaptionLabel("Reset Mode")
      .setGroup(group)
      .setSize(100, 20)
      .setPosition(30, 670);
    resetMode.getCaptionLabel().toUpperCase(false);
    resetMode.getCaptionLabel().getStyle().setPadding(-1, 0, 0, 0);

    writeMode = cp5.addButton("editorWriteMode")
      .setCaptionLabel("Write Mode")
      .setGroup(group)
      .setSize(100, 20)
      .setPosition(150, 670);
    writeMode.getCaptionLabel().toUpperCase(false);
    writeMode.getCaptionLabel().getStyle().setPadding(-1, 0, 0, 0);

    saveMode = cp5.addButton("editorSaveMode")
      .setCaptionLabel("Save Mode")
      .setGroup(group)
      .setSize(100, 20)
      .setPosition(270, 670);
    saveMode.getCaptionLabel().toUpperCase(false);
    saveMode.getCaptionLabel().getStyle().setPadding(-1, 0, 0, 0);

    loadMode = cp5.addButton("editorLoadMode")
      .setCaptionLabel("Load Mode")
      .setGroup(group)
      .setSize(100, 20)
      .setPosition(390, 670);
    loadMode.getCaptionLabel().toUpperCase(false);
    loadMode.getCaptionLabel().getStyle().setPadding(-1, 0, 0, 0);

    saveLight = cp5.addButton("editorSaveLight")
      .setCaptionLabel("Save Light")
      .setGroup(group)
      .setSize(100, 20)
      .setPosition(630, 670);
    saveLight.getCaptionLabel().toUpperCase(false);
    saveLight.getCaptionLabel().getStyle().setPadding(-1, 0, 0, 0);

    writeLight = cp5.addButton("editorWriteLight")
      .setCaptionLabel("Write Light")
      .setGroup(group)
      .setSize(100, 20)
      .setPosition(750, 670);
    writeLight.getCaptionLabel().toUpperCase(false);
    writeLight.getCaptionLabel().getStyle().setPadding(-1, 0, 0, 0);

    disconnectLight = cp5.addButton("editorDisconnectLight")
      .setCaptionLabel("Disconnect")
      .setGroup(group)
      .setSize(100, 20)
      .setPosition(870, 670);
    disconnectLight.getCaptionLabel().toUpperCase(false);
    disconnectLight.getCaptionLabel().getStyle().setPadding(-1, 0, 0, 0);

    viewMode = cp5.addButton("editorViewMode")
      .setCaptionLabel("View Mode")
      .setGroup(group)
      .setColorBackground(color(0, 90, 180))
      .setSize(100, 20)
      .setPosition(678, 560);
    viewMode.getCaptionLabel().toUpperCase(false);
    viewMode.getCaptionLabel().getStyle().setPadding(-1, 0, 0, 0);

    viewColor = cp5.addButton("editorViewColor")
      .setCaptionLabel("View Color")
      .setGroup(group)
      .setColorBackground(color(0, 45, 90))
      .setSize(100, 20)
      .setPosition(798, 560)
      .hide();
    viewColor.getCaptionLabel().toUpperCase(false);
    viewColor.getCaptionLabel().getStyle().setPadding(-1, 0, 0, 0);
  }

  public void curModeChanged(int m) {
    title.setText("Mode " + (m + 1));
    seta(0, modes[m].pattern);
    for (int i = 0; i < 3; i++) { seta(i + 1, modes[cur_mode].numColors[i]); }
    for (int i = 0; i < 4; i++) { seta(i + 4, modes[cur_mode].patternThresh[i / 2][i % 2]); }
    for (int i = 0; i < 4; i++) { seta(i + 8, modes[cur_mode].colorThresh[i / 2][i % 2]); }
    for (int i = 0; i < 3; i++) { seta(i + 12, modes[cur_mode].args[i]); }
    for (int i = 0; i < 18; i++) { seta(i + 15, modes[cur_mode].timings[i / 6][i % 6]); }
    for (int i = 0; i < 81; i++) { seta(i + 33, modes[cur_mode].colors[i / 9][(i % 9) / 3][i % 3]); }

    color_set = -1;
    color_slot = -1;
    colorSelect.hide();
    viewMode.hide();
    viewColor.hide();
  }

  public void numColorsChanged(int i, int v) {
    for (int j = 0; j < 9; j++) {
      if (j < v) {
        colors[i][j].show();
      } else {
        colors[i][j].hide();
      }
    }
    if (color_set == i && v <= color_slot) {
      color_set = -1;
      color_slot = -1;
      colorSelect.hide();
    }
  }

  public void patternThreshChanged(int i, int j) {
    patternThresh.setBroadcast(false).setArrayValue(i, j).setBroadcast(true);
  }

  public void colorThreshChanged(int i, int j) {
    colorThresh.setBroadcast(false).setArrayValue(i, j).setBroadcast(true);
  }

  public void patternChanged(int p) {
    // TODO
    switch (p) {
      case 0: // Strobe
        argLabels[0].setValue("Group Size").show();
        args[0].setBroadcast(false)
          .setRange(0, 9)
          .setNumberOfTickMarks(10)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        argLabels[1].setValue("Skip After").show();
        args[1].setBroadcast(false)
          .setRange(0, 9)
          .setNumberOfTickMarks(10)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        argLabels[2].setValue("Repeat Group").show();
        args[2].setBroadcast(false)
          .setRange(1, 100)
          .setNumberOfTickMarks(100)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        timingLabels[0].setValue("Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][0].show(); }

        timingLabels[1].setValue("Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][1].show(); }

        timingLabels[2].setValue("Tail Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][2].show(); }

        timingLabels[3].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][3].hide(); }

        timingLabels[4].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][4].hide(); }

        timingLabels[5].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][5].hide(); }
        break;

      case 1: // Vexer
        argLabels[0].setValue("Repeat Strobe").show();
        args[0].setBroadcast(false)
          .setRange(1, 100)
          .setNumberOfTickMarks(100)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        argLabels[1].setValue("Repeat Tracer").show();
        args[1].setBroadcast(false)
          .setRange(1, 100)
          .setNumberOfTickMarks(100)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        argLabels[2].setValue("").hide();
        args[2].hide();

        timingLabels[0].setValue("Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][0].show(); }

        timingLabels[1].setValue("Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][1].show(); }

        timingLabels[2].setValue("Tracer Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][2].show(); }

        timingLabels[3].setValue("Tracer Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][3].show(); }

        timingLabels[4].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][4].hide(); }

        timingLabels[5].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][5].hide(); }
        break;

      case 2: // Edge
        argLabels[0].setValue("Group Size").show();
        args[0].setBroadcast(false)
          .setRange(0, 9)
          .setNumberOfTickMarks(10)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        argLabels[1].setValue("").hide();
        args[1].hide();

        argLabels[2].setValue("").hide();
        args[2].hide();

        timingLabels[0].setValue("Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][0].show(); }

        timingLabels[1].setValue("Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][1].show(); }

        timingLabels[2].setValue("Center Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][2].show(); }

        timingLabels[3].setValue("Trailing Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][3].show(); }

        timingLabels[4].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][4].hide(); }

        timingLabels[5].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][5].hide(); }
        break;

      case 3: // Double
        argLabels[0].setValue("Repeat First").show();
        args[0].setBroadcast(false)
          .setRange(1, 100)
          .setNumberOfTickMarks(100)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        argLabels[1].setValue("Repeat Second").show();
        args[1].setBroadcast(false)
          .setRange(1, 100)
          .setNumberOfTickMarks(100)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        argLabels[2].setValue("Skip Colors").show();
        args[2].setBroadcast(false)
          .setRange(0, 8)
          .setNumberOfTickMarks(9)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        timingLabels[0].setValue("First Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][0].show(); }

        timingLabels[1].setValue("First Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][1].show(); }

        timingLabels[2].setValue("Second Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][2].show(); }

        timingLabels[3].setValue("Second Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][3].show(); }

        timingLabels[4].setValue("Split Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][4].show(); }

        timingLabels[5].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][5].hide(); }
        break;

      case 4: // Runner
        argLabels[0].setValue("Group Size").show();
        args[0].setBroadcast(false)
          .setRange(0, 9)
          .setNumberOfTickMarks(10)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        argLabels[1].setValue("Skip Between").show();
        args[1].setBroadcast(false)
          .setRange(0, 9)
          .setNumberOfTickMarks(10)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        argLabels[2].setValue("Repeat Runner").show();
        args[2].setBroadcast(false)
          .setRange(1, 100)
          .setNumberOfTickMarks(100)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        timingLabels[0].setValue("Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][0].show(); }

        timingLabels[1].setValue("Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][1].show(); }

        timingLabels[2].setValue("Runner Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][2].show(); }

        timingLabels[3].setValue("Runner Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][3].show(); }

        timingLabels[4].setValue("Split Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][4].show(); }

        timingLabels[5].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][5].hide(); }
        break;

      case 5: // Stepper
        argLabels[0].setValue("Use Steps").show();
        args[0].setBroadcast(false)
          .setRange(1, 5)
          .setNumberOfTickMarks(5)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        argLabels[1].setValue("").hide();
        args[1].hide();

        argLabels[2].setValue("").hide();
        args[2].hide();

        timingLabels[0].setValue("Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][0].show(); }

        timingLabels[1].setValue("Step 1").show();
        for (int i = 0; i < 3; i++) { timings[i][1].show(); }

        timingLabels[2].setValue("Step 2").show();
        for (int i = 0; i < 3; i++) { timings[i][2].show(); }

        timingLabels[3].setValue("Step 3").show();
        for (int i = 0; i < 3; i++) { timings[i][3].show(); }

        timingLabels[4].setValue("Step 4").show();
        for (int i = 0; i < 3; i++) { timings[i][4].show(); }

        timingLabels[5].setValue("Step 5").show();
        for (int i = 0; i < 3; i++) { timings[i][5].show(); }
        break;

      case 6: // Random
        argLabels[0].setValue("Random Color Order (0 = no, 1 = yes)").show();
        args[0].setBroadcast(false)
          .setRange(0, 1)
          .setNumberOfTickMarks(2)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        argLabels[1].setValue("Time Multiplier").show();
        args[1].setBroadcast(false)
          .setRange(1, 10)
          .setNumberOfTickMarks(10)
          .showTickMarks(false)
          .setValue(0)
          .setBroadcast(true)
          .show();

        argLabels[2].setValue("").hide();
        args[2].hide();

        timingLabels[0].setValue("Strobe Low").show();
        for (int i = 0; i < 3; i++) { timings[i][0].show(); }

        timingLabels[1].setValue("Strobe High").show();
        for (int i = 0; i < 3; i++) { timings[i][1].show(); }

        timingLabels[2].setValue("Blank Low").show();
        for (int i = 0; i < 3; i++) { timings[i][2].show(); }

        timingLabels[3].setValue("Blank High").show();
        for (int i = 0; i < 3; i++) { timings[i][3].show(); }

        timingLabels[4].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][4].hide(); }

        timingLabels[5].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][5].hide(); }
        break;
    }
  }

  public void seta(int addr, int val) {
    try {
      if (addr == 0) {
        base.setBroadcast(false).setValue(val).setBroadcast(true);
        base.setCaptionLabel(base.getItem(val).get("text").toString());
        patternChanged(val);
      } else if (addr < 4) {
        numColors[addr - 1].setBroadcast(false).setValue(val).setBroadcast(true);
        numColorsChanged(addr - 1, val);
      } else if (addr < 8) {
        patternThresh.setBroadcast(false).setArrayValue(addr - 4, val).setBroadcast(true);
      } else if (addr < 12) {
        colorThresh.setBroadcast(false).setArrayValue(addr - 8, val).setBroadcast(true);
      } else if (addr < 15) {
        args[addr - 12].setBroadcast(false).setValue(val).setBroadcast(true);
      } else if (addr < 33) {
        timings[(addr - 15) / 6][(addr - 15) % 6].setBroadcast(false).setValue(val).setBroadcast(true);
      } else if (addr < 114) {
        int chan = (addr - 33) % 3;
        int slot = (addr - 33) / 9;
        int set = ((addr - 33) % 9) / 3;
        int r = 0;
        int g = 0;
        int b = 0;

        if (chan == 0) {
          r = (val == 0) ? 0 : (val / 2) + 128;
          modes[cur_mode].colors[slot][set][0] = val;
          g = modes[cur_mode].colors[slot][set][1];
          b = modes[cur_mode].colors[slot][set][2];
          g = (g == 0) ? 0 : (g / 2) + 128;
          b = (b == 0) ? 0 : (b / 2) + 128;
        } else if (chan == 1) {
          g = (val == 0) ? 0 : (val / 2) + 128;
          modes[cur_mode].colors[slot][set][1] = val;
          r = modes[cur_mode].colors[slot][set][0];
          b = modes[cur_mode].colors[slot][set][2];
          r = (r == 0) ? 0 : (r / 2) + 128;
          b = (b == 0) ? 0 : (b / 2) + 128;
        } else if (chan == 2) {
          b = (val == 0) ? 0 : (val / 2) + 128;
          modes[cur_mode].colors[slot][set][2] = val;
          r = modes[cur_mode].colors[slot][set][0];
          g = modes[cur_mode].colors[slot][set][1];
          r = (r == 0) ? 0 : (r / 2) + 128;
          g = (g == 0) ? 0 : (g / 2) + 128;
        }
        colors[set][slot].setColorBackground(color(r, g, b));
        colors[set][slot].setColorForeground(color(r, g, b));
        colors[set][slot].setColorActive(color(r, g, b));
      }
    } catch (Exception ex) {
    }
  }

  public void selectColor(float v) {
    selectColor((int)v / 9, (int)v % 9);
  }

  public void selectColor(int set, int slot) {
    if (slot >= modes[cur_mode].numColors[set]) { return; }

    color_set = set;
    color_slot = slot;

    float p[] = colors[set][slot].getPosition();
    colorSelect.setPosition(p[0] - 4, p[1] - 4).show();
    viewMode.show();
    viewColor.show();

    for (int i = 0; i < 3; i++) {
      colorValues[i].setBroadcast(false)
        .setValue(modes[cur_mode].colors[slot][set][i])
        .setBroadcast(true);
    }
  }
}


public void style(String theControllerName) {
  Controller c = cp5.getController(theControllerName);
  c.getCaptionLabel().toUpperCase(false);
  c.getCaptionLabel().getStyle().setPadding(4, 4, 4, 4);
  c.getCaptionLabel().getStyle().setMargin(-4, 0, 0, 0);
}

public int translateColor(int i) {
  int r, g, b;
  r = (color_bank[i][0] == 0) ? 0 : 128 + (color_bank[i][0] / 2);
  g = (color_bank[i][1] == 0) ? 0 : 128 + (color_bank[i][1] / 2);
  b = (color_bank[i][2] == 0) ? 0 : 128 + (color_bank[i][2] / 2);
  return (255 << 24) + (r << 16) + (g << 8) + b;
}
class Mode {
  int       pattern;
  int[]     numColors = new int[3];
  int[][]   patternThresh = new int[2][2];
  int[][]   colorThresh = new int[2][2];
  int[]     args = new int[3];
  int[][]   timings = new int[3][6];
  int[][][] colors = new int[9][3][3];

  Mode() {
  }

  public int geta(int addr) {
    if (addr == 0) {
      return pattern;
    } else if (addr < 4) {
      return numColors[addr - 1];
    } else if (addr < 8) {
      return patternThresh[(addr - 5) / 2][(addr - 4) % 2];
    } else if (addr < 12) {
      return colorThresh[(addr - 8) / 2][(addr - 8) % 2];
    } else if (addr < 15) {
      return args[addr - 12];
    } else if (addr < 33) {
      return timings[(addr - 15) / 6][(addr - 21) % 6];
    } else if (addr < 114) {
      return colors[(addr - 33) / 9][((addr - 33) % 9) / 3][(addr - 33) % 3];
    }
    return -1;
  }

  public void seta(int addr, int val) {
    if (addr == 0) {
      pattern = val;
    } else if (addr < 4) {
      numColors[addr - 1] = val;
    } else if (addr < 8) {
      patternThresh[(addr - 4) / 2][(addr - 4) % 2] = val;
    } else if (addr < 12) {
      colorThresh[(addr - 8) / 2][(addr - 8) % 2] = val;
    } else if (addr < 15) {
      args[addr - 12] = val;
    } else if (addr < 33) {
      timings[(addr - 15) / 6][(addr - 15) % 6] = val;
    } else if (addr < 114) {
      colors[(addr - 33) / 9][((addr - 33) % 9) / 3][(addr - 33) % 3] = val;
    }
  }

  public JSONArray j_numColors() {
    JSONArray jarr = new JSONArray();
    for (int i = 0; i < 3; i++) {
      jarr.setInt(i, numColors[i]);
    }
    return jarr;
  }

  public JSONArray j_patternThresh() {
    JSONArray jarr = new JSONArray();
    for (int i = 0; i < 2; i++) {
      JSONArray jarr1 = new JSONArray();
      for (int j = 0; j < 2; j++) {
        jarr1.setInt(j, patternThresh[i][j]);
      }
      jarr.setJSONArray(i, jarr1);
    }
    return jarr;
  }

  public JSONArray j_colorThresh() {
    JSONArray jarr = new JSONArray();
    for (int i = 0; i < 2; i++) {
      JSONArray jarr1 = new JSONArray();
      for (int j = 0; j < 2; j++) {
        jarr1.setInt(j, colorThresh[i][j]);
      }
      jarr.setJSONArray(i, jarr1);
    }
    return jarr;
  }

  public JSONArray j_args() {
    JSONArray jarr = new JSONArray();
    for (int i = 0; i < 3; i++) {
      jarr.setInt(i, args[i]);
    }
    return jarr;
  }

  public JSONArray j_timings() {
    JSONArray jarr = new JSONArray();
    for (int i = 0; i < 3; i++) {
      JSONArray jarr1 = new JSONArray();
      for (int j = 0; j < 6; j++) {
        jarr1.setInt(j, timings[i][j]);
      }
      jarr.setJSONArray(i, jarr1);
    }
    return jarr;
  }

  public JSONArray j_colors() {
    JSONArray jarr = new JSONArray();
    for (int i = 0; i < 3; i++) {
      JSONArray jarr1 = new JSONArray();
      for (int j = 0; j < 9; j++) {
        JSONArray jarr2 = new JSONArray();
        for (int k = 0; k < 3; k++) {
          jarr2.setInt(k, colors[j][i][k]);
        }
        jarr1.setJSONArray(j, jarr2);
      }
      jarr.setJSONArray(i, jarr1);
    }
    return jarr;
  }

  public JSONObject asJSON() {
    JSONObject j_mode = new JSONObject();
    j_mode.setInt("pattern", pattern);
    j_mode.setJSONArray("num_colors", j_numColors());
    j_mode.setJSONArray("pattern_thresh", j_patternThresh());
    j_mode.setJSONArray("color_thresh", j_colorThresh());
    j_mode.setJSONArray("args", j_args());
    j_mode.setJSONArray("timings", j_timings());
    j_mode.setJSONArray("colors", j_colors());
    return j_mode;
  }

  public void json_numColors(JSONArray jarr) {
    for (int i = 0; i < 3; i++) {
      numColors[i] = jarr.getInt(i);
    }
  }

  public void json_patternThresh(JSONArray jarr) {
    for (int i = 0; i < 2; i++) {
      JSONArray jarr1 = jarr.getJSONArray(i);
      for (int j = 0; j < 2; j++) {
        patternThresh[i][j] = jarr1.getInt(j);
      }
    }
  }

  public void json_colorThresh(JSONArray jarr) {
    for (int i = 0; i < 2; i++) {
      JSONArray jarr1 = jarr.getJSONArray(i);
      for (int j = 0; j < 2; j++) {
        colorThresh[i][j] = jarr1.getInt(j);
      }
    }
  }

  public void json_args(JSONArray jarr) {
    for (int i = 0; i < 3; i++) {
      args[i] = jarr.getInt(i);
    }
  }

  public void json_timings(JSONArray jarr) {
    for (int i = 0; i < 3; i++) {
      JSONArray jarr1 = jarr.getJSONArray(i);
      for (int j = 0; j < 6; j++) {
        timings[i][j] = jarr1.getInt(j);
      }
    }
  }

  public void json_colors(JSONArray jarr) {
    for (int i = 0; i < 3; i++) {
      JSONArray jarr1 = jarr.getJSONArray(i);
      for (int j = 0; j < 9; j++) {
        JSONArray jarr2 = jarr1.getJSONArray(j);
        for (int k = 0; k < 3; k++) {
          colors[j][i][k] = jarr2.getInt(k);
        }
      }
    }
  }

  public void fromJSON(JSONObject json) {
    pattern = json.getInt("pattern");
    json_numColors(json.getJSONArray("num_colors"));
    json_patternThresh(json.getJSONArray("pattern_thresh"));
    json_colorThresh(json.getJSONArray("color_thresh"));
    json_args(json.getJSONArray("args"));
    json_timings(json.getJSONArray("timings"));
    json_colors(json.getJSONArray("colors"));
  }
}










public class ThreshRange extends Controller<ThreshRange> {
  protected static final String MANY_SPACES = "                    ";
  protected static final int MODE_OFF = -1;
  protected static final int MODE_01S = 0;
  protected static final int MODE_01 = 1;
  protected static final int MODE_01E = 2;
  protected static final int MODE_12S = 3;
  protected static final int MODE_12 = 4;
  protected static final int MODE_12E = 5;
  protected static final int MODE_0 = 6;
  protected static final int MODE_1 = 7;
  protected static final int MODE_2 = 8;

  protected static final int HORIZONTAL = 0;
  protected static final int VERTICAL = 1;

  public int alignValueLabel = CENTER;
  private int mode = -1;

  protected int handleSize = 6;
  protected int handleSize2 = 3;
  public int autoWidth = 99;
  public int autoHeight = 9;
  public  PVector autoSpacing = new PVector(0, 5, 0);

  protected float _myValuePosition;
  protected float _myValueRange;

  protected boolean isDragging;
  protected boolean isDraggable = true;
  protected boolean isFirstClick;

  //protected Label _myValueLabel;  // For low value
  protected Label _myMidValueLabel;
  protected Label _myHighValueLabel;

  protected int minAHandle = 0;
  protected int maxAHandle = 0;
  protected int minBHandle = 0;
  protected int maxBHandle = 0;

  int dA = 0;
  int dB = 0;


  public ThreshRange(ControlP5 theControlP5, String theName) {
    this(theControlP5, theControlP5.getDefaultTab(), theName, 0, 32, 4, 14, 18, 28, 0, 0, 792, 20);
    theControlP5.register(theControlP5.papplet, theName, this);
  }

  public ThreshRange(
      ControlP5 theControlP5,
      ControllerGroup<?> theParent,
      String theName,
      float theMin,
      float theMax,
      float theDefaultMinAValue,
      float theDefaultMaxAValue,
      float theDefaultMinBValue,
      float theDefaultMaxBValue,
      int theX,
      int theY,
      int theWidth,
      int theHeight) {

    super(theControlP5, theParent, theName, theX, theY, theWidth, theHeight);

    _myArrayValue = new float[] {theDefaultMinAValue , theDefaultMaxAValue, theDefaultMinBValue, theDefaultMaxBValue};

    _myMin = theMin;
    _myMax = theMax;
    _myValueRange = _myMax - _myMin;

    minAHandle = (int)(_myArrayValue[0] * 24) + 3;
    maxAHandle = (int)(_myArrayValue[1] * 24) + 9;
    minBHandle = (int)(_myArrayValue[2] * 24) + 15;
    maxBHandle = (int)(_myArrayValue[3] * 24) + 21;
    dA = maxAHandle - minAHandle;
    dB = maxBHandle - minBHandle;

    _myCaptionLabel = new controlP5.Label(cp5, theName)
      .setColor(0)
      .align(CENTER, TOP_OUTSIDE);

    _myValueLabel = new controlP5.Label(cp5, theName + "LowLabel")
      .setColor(0)
      .set("" + (int)theDefaultMinAValue)
      .setFont(createFont("Arial", 10))
      .align(LEFT, BOTTOM_OUTSIDE);

    _myMidValueLabel = new controlP5.Label(cp5, theName + "MidLabel")
      .setColor(0)
      .set("" + (int)theDefaultMaxAValue + MANY_SPACES + (int)theDefaultMinBValue)
      .setFont(createFont("Arial", 10))
      .align(CENTER, BOTTOM_OUTSIDE);

    _myHighValueLabel = new controlP5.Label(cp5, theName + "HighLabel")
      .setColor(0)
      .set("" + (int)theDefaultMaxBValue)
      .setFont(createFont("Arial", 10))
      .align(RIGHT, BOTTOM_OUTSIDE);

    _myValue = theDefaultMinAValue;
    update();
  }

  @Override public ThreshRange setColorValueLabel(int theColor) {
    _myValueLabel.setColor(theColor);
    _myMidValueLabel.setColor(theColor);
    _myHighValueLabel.setColor(theColor);
    return this;
  }

  @Override public ThreshRange setColorCaptionLabel(int theColor) {
    _myCaptionLabel.setColor(theColor);
    return this;
  }

  public ThreshRange setLowValueLabel(final String theLabel) {
    _myValueLabel.set(theLabel);
    return this;
  }

  public ThreshRange setMidValueLabel(final String theLabel) {
    _myMidValueLabel.set(theLabel);
    return this;
  }

  public ThreshRange setHighValueLabel(final String theLabel) {
    _myHighValueLabel.set(theLabel);
    return this;
  }

  public ThreshRange setSliderMode(int theMode) {
    return this;
  }

  public ThreshRange setHandleSize(int theSize) {
    handleSize = theSize;
    handleSize2 = theSize / 2;
    setMinA(_myArrayValue[0], false);
    setMaxA(_myArrayValue[1], false);
    setMinB(_myArrayValue[2], false);
    setMaxB(_myArrayValue[3], false);
    return this;
  }

  public int getMode() {
    final float posX = x(_myParent.getAbsolutePosition()) + x(position);
    final float posY = y(_myParent.getAbsolutePosition()) + y(position);
    final float mX = mouseX;
    final float mY = mouseY;

    if (mY < posY || mY > posY + getHeight()) {
      // Not inside
      return MODE_OFF;
    }

    int x0 = (int)(posX + minAHandle);
    int x1 = (int)(posX + maxAHandle);
    int x2 = (int)(posX + minBHandle);
    int x3 = (int)(posX + maxBHandle);

    if (mX >= x0 - handleSize2 && mX < x0 + handleSize2) {
      return MODE_01S;
    } else if (mX >= x0 + handleSize2 && mX < x1 - handleSize2) {
      return MODE_01;
    } else if (mX >= x1 - handleSize2 && mX < x1 + handleSize2) {
      return MODE_01E;
    } else if (mX >= x2 - handleSize2 && mX < x2 + handleSize2) {
      return MODE_12S;
    } else if (mX >= x2 + handleSize2 && mX < x3 - handleSize2) {
      return MODE_12;
    } else if (mX >= x3 - handleSize2 && mX < x3 + handleSize2) {
      return MODE_12E;
    } else if (mX >= posX && mX < x0 - handleSize2) {
      return MODE_0;
    } else if (mX >= x1 + handleSize2 && mX < x2 - handleSize2) {
      return MODE_1;
    } else if (mX >= x3 + handleSize2 && mX < posX + getWidth()) {
      return MODE_2;
    }
    return MODE_OFF;
  }

  @Override public void mousePressed() {
    mode = getMode();
  }

  public ThreshRange updateInternalEvents(PApplet theApplet) {
    if (isVisible) {
      int c = mouseX - pmouseX;
      if (c == 0) {
        return this;
      }
      if (isMousePressed && !cp5.isAltDown()) {
        switch (mode) {
          case MODE_01S:
            // 0 - (MaxA
            minAHandle = PApplet.max(3, PApplet.min(maxAHandle - 6, minAHandle + c));
            break;
          case MODE_01E:
            // MinA) - (MinB
            maxAHandle = PApplet.max(minAHandle + 6, PApplet.min(minBHandle - 6, maxAHandle + c));
            break;
          case MODE_12S:
            // MaxA) - (MaxB
            minBHandle = PApplet.max(maxAHandle + 6, PApplet.min(maxBHandle - 6, minBHandle + c));
            break;
          case MODE_12E:
            // MinB) - width
            maxBHandle = PApplet.max(minBHandle + 6, PApplet.min(getWidth() - 3, maxBHandle + c));
            break;

          case MODE_01:
            minAHandle = PApplet.max(3, PApplet.min(minBHandle - dA - 6, minAHandle + c));
            maxAHandle = PApplet.max(minAHandle + 6, PApplet.min(minBHandle - 6, minAHandle + dA));
            break;
          case MODE_12:
            minBHandle = PApplet.max(maxAHandle + 6, PApplet.min(getWidth() - dB - 3, minBHandle + c));
            maxBHandle = PApplet.max(minBHandle + 6, PApplet.min(getWidth() - 3, minBHandle + dB));
            break;

          case MODE_0:
            break;
          case MODE_1:
            break;
          case MODE_2:
            break;

        }
        update();
        dA = maxAHandle - minAHandle;
        dB = maxBHandle - minBHandle;
      }
    }
    return this;
  }

  @Override public ThreshRange setValue(float theValue) {
    _myValue = theValue;
    broadcast(ARRAY);
    return this;
  }

  @Override public ThreshRange update() {
    _myArrayValue[0] = min((minAHandle - 3) / 24, 32);
    _myArrayValue[1] = min((maxAHandle - 9) / 24, 32);
    _myArrayValue[2] = min((minBHandle - 15) / 24, 32);
    _myArrayValue[3] = min((maxBHandle - 21) / 24, 32);

    _myValueLabel.set("" + (int)_myArrayValue[0]);
    _myMidValueLabel.set("" + (int)_myArrayValue[1] + MANY_SPACES + (int)_myArrayValue[2]);
    _myHighValueLabel.set("" + (int)_myArrayValue[3]);
    return setValue(_myValue);
  }

  public ThreshRange setDraggable(boolean theFlag) {
    isDraggable = theFlag;
    isDragging = (theFlag == false) ? false : isDragging;
    return this;
  }

  public float[] getArrayValue() {
    return _myArrayValue;
  }

  protected float snapValue(float theValue) {
    return (float)(int)theValue;
  }

  private ThreshRange setMinA(float theValue, boolean isUpdate) {
    _myArrayValue[0] = PApplet.max(_myMin, snapValue(theValue));
    minAHandle = (int)(_myArrayValue[0] * 24) + 3;
    dA = maxAHandle - minAHandle;
    return (isUpdate) ? update() : this;
  }

  public ThreshRange setMinA(float theValue) {
    return setMinA(theValue, true);
  }

  private ThreshRange setMaxA(float theValue, boolean isUpdate) {
    _myArrayValue[1] = PApplet.max(_myMin, snapValue(theValue));
    maxAHandle = (int)(_myArrayValue[1] * 24) + 9;
    dA = maxAHandle - minAHandle;
    return (isUpdate) ? update() : this;
  }

  public ThreshRange setMaxA(float theValue) {
    return setMaxA(theValue, true);
  }

  private ThreshRange setMinB(float theValue, boolean isUpdate) {
    _myArrayValue[2] = PApplet.max(_myMin, snapValue(theValue));
    minBHandle = (int)(_myArrayValue[2] * 24) + 15;
    dB = maxBHandle - minBHandle;
    return (isUpdate) ? update() : this;
  }

  public ThreshRange setMinB(float theValue) {
    return setMinB(theValue, true);
  }

  private ThreshRange setMaxB(float theValue, boolean isUpdate) {
    _myArrayValue[3] = PApplet.max(_myMin, snapValue(theValue));
    maxBHandle = (int)(_myArrayValue[3] * 24) + 21;
    dB = maxBHandle - minBHandle;
    return (isUpdate) ? update() : this;
  }

  public ThreshRange setMaxB(float theValue) {
    return setMaxB(theValue, true);
  }

  public ThreshRange setArrayValue(int i, float v) {
    if (i == 0) {
      setMinA(v, false);
    } else if (i == 1) {
      setMaxA(v, false);
    } else if (i == 2) {
      setMinB(v, false);
    } else if (i == 3) {
      setMaxB(v, false);
    }
    return update();
  }

  @Override public ThreshRange setArrayValue(float[] theArray) {
    setMinA(theArray[0], false);
    setMaxA(theArray[1], false);
    setMinB(theArray[2], false);
    setMaxB(theArray[3], false);
    return update();
  }

  @Override public ThreshRange setMin(float theValue) {
    _myMin = theValue;
    _myValueRange = _myMax - _myMin;
    return setMinA(_myArrayValue[0]);
  }

  @Override public ThreshRange setMax(float theValue) {
    _myMax = theValue;
    _myValueRange = _myMax - _myMin;
    return setMaxB(_myArrayValue[1]);
  }

  public float getMinA() {
    return _myArrayValue[0];
  }

  public float getMaxA() {
    return _myArrayValue[1];
  }

  public float getMinB() {
    return _myArrayValue[2];
  }

  public float getMaxB() {
    return _myArrayValue[3];
  }

  @Override public ThreshRange setWidth(int theValue) {
    super.setWidth(theValue);
    return this;
  }

  @Override public ThreshRange setHeight(int theValue) {
    super.setHeight(theValue);
    return this;
  }

  @Override public void mouseReleased() {
    isDragging = false;
    // Align
    switch (mode) {
      case MODE_01S:
        minAHandle = (int)(_myArrayValue[0] * 24) + 3;
        break;
      case MODE_01E:
        maxAHandle = (int)(_myArrayValue[1] * 24) + 9;
        break;
      case MODE_12S:
        minBHandle = (int)(_myArrayValue[2] * 24) + 15;
        break;
      case MODE_12E:
        maxBHandle = (int)(_myArrayValue[3] * 24) + 21;
        break;
      case MODE_01:
        minAHandle = (int)(_myArrayValue[0] * 24) + 3;
        maxAHandle = (int)(_myArrayValue[1] * 24) + 9;
        break;
      case MODE_12:
        minBHandle = (int)(_myArrayValue[2] * 24) + 15;
        maxBHandle = (int)(_myArrayValue[3] * 24) + 21;
        break;
    }
    dA = maxAHandle - minAHandle;
    dB = maxBHandle - minBHandle;
    mode = MODE_OFF;
  }

  @Override public void mouseReleasedOutside() {
    mouseReleased();
  }

  @Override public void onLeave() {
    isDragging = false;
  }

  public ThreshRange setRange(float theMinValue, float theMaxValue) {
    setMin(theMinValue);
    setMax(theMaxValue);
    return this;
  }

  public ThreshRange setRangeValues(float theMinA, float theMaxA, float theMinB, float theMaxB) {
    return setArrayValue(new float[] {theMinA, theMaxA, theMinB, theMaxB});
  }

  @Override public ThreshRange updateDisplayMode(int theMode) {
    _myDisplayMode = theMode;
    switch (theMode) {
      case (DEFAULT):
        _myControllerView = new ThreshRangeView();
        break;
      case (SPRITE):
        _myControllerView = new ThreshRangeSpriteView();
        break;
      case (IMAGE):
        _myControllerView = new ThreshRangeImageView();
        break;
      case (CUSTOM):
      default:
        break;
    }
    return this;
  }

  class ThreshRangeSpriteView implements ControllerView<ThreshRange> {
    public void display(PGraphics theGraphics, ThreshRange theController) {
      ControlP5.logger().log(Level.INFO, "ThreshRangeSpriteDisplay not available.");
    }
  }

  class ThreshRangeView implements ControllerView<ThreshRange> {
    public void display(PGraphics theGraphics, ThreshRange theController) {
      int high = getMode();
      theGraphics.pushMatrix();

      // Pattern Zones
      theGraphics.fill(0);
      theGraphics.stroke(0);
      theGraphics.rect(0, 0, getWidth(), getHeight());

      theGraphics.fill(color(255, 0, 0));
      theGraphics.rect(0, 0, minAHandle, getHeight());
      theGraphics.fill(color(255, 255, 0));
      theGraphics.rect(minAHandle, 0, maxAHandle - minAHandle, getHeight());
      theGraphics.fill(color(0, 255, 0));
      theGraphics.rect(maxAHandle, 0, minBHandle - maxAHandle, getHeight());
      theGraphics.fill(color(0, 255, 255));
      theGraphics.rect(minBHandle, 0, maxBHandle - minBHandle, getHeight());
      theGraphics.fill(color(0, 0, 255));
      theGraphics.rect(maxBHandle, 0, getWidth() - maxBHandle, getHeight());

      if (high == 0) {
        theGraphics.fill(128);
        theGraphics.stroke(255);
      } else {
        theGraphics.fill(255);
        theGraphics.stroke(0);
      }
      theGraphics.rect(minAHandle - handleSize2, 0, handleSize, getHeight());
      if (high == 2) {
        theGraphics.fill(128);
        theGraphics.stroke(255);
      } else {
        theGraphics.fill(255);
        theGraphics.stroke(0);
      }
      theGraphics.rect(maxAHandle - handleSize2, 0, handleSize, getHeight());
      if (high == 3) {
        theGraphics.fill(128);
        theGraphics.stroke(255);
      } else {
        theGraphics.fill(255);
        theGraphics.stroke(0);
      }
      theGraphics.rect(minBHandle - handleSize2, 0, handleSize, getHeight());
      if (high == 5) {
        theGraphics.fill(128);
        theGraphics.stroke(255);
      } else {
        theGraphics.fill(255);
        theGraphics.stroke(0);
      }
      theGraphics.rect(maxBHandle - handleSize2, 0, handleSize, getHeight());

      if (isLabelVisible) {
        _myCaptionLabel.draw(theGraphics, 0, 0, theController);
        _myValueLabel.draw(theGraphics, 0, 0, theController);
        _myMidValueLabel.draw(theGraphics, 0, 0, theController);
        _myHighValueLabel.draw(theGraphics, 0, 0, theController);
      }

      theGraphics.popMatrix();
    }
  }

  class ThreshRangeImageView implements ControllerView<ThreshRange> {
    public void display(PGraphics theGraphics, ThreshRange theController) {
      ControlP5.logger().log(Level.INFO, "ThreshRangeImageDisplay not implemented.");
    }
  }

  @Override public String toString() {
    return "type:\tThreshRange\n" + super.toString();
  }

  @Deprecated public float lowValue() {
    return getMinA();
  }

  @Deprecated public float highValue() {
    return getMaxB();
  }

  @Deprecated public float[] arrayValue() {
    return _myArrayValue;
  }
}
  public void settings() {  size(1000, 700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "vectrui" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
