import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.event.KeyEvent; 
import processing.serial.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class tekton extends PApplet {

/*
The MIT License (MIT)

Copyright (c) 2015 John Joseph Miller

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/




Serial port;
ControlP5 cp5;

// 0, mode
// 1, bundle
// 2, palette
// 3, patterns
int gui_state = 0;
Boolean gui_initialized = false;
Boolean initialized = false;
Boolean reading = true;

int color_palette[][] = new int[48][3];
int user_patterns[][] = new int[16][8];
int cur_preset_idx = 0;

Textlabel tlLoading;
GuiUI guiui;
PresetEditor preset_editor;
PalettePanel palette_panel;
BundleEditor bundle_editor;

Boolean shifted = false;


public void setup() {
  frame.setTitle("Tekton for Primer 0.8");
  
  cp5 = new ControlP5(this);

  guiui = new GuiUI(0, 240);
  palette_panel = new PalettePanel(60, 0);
  preset_editor = new PresetEditor(100, 0);
  bundle_editor = new BundleEditor(100, 0);

  tlLoading = cp5.addTextlabel("loading")
    .setText("Connecting")
    .setPosition(430, 400)
    .setColorValue(0xff8888ff)
    .setFont(createFont("Arial", 32))
    .hide();

  gui_initialized = true;
}

public void connectLight() {
  for (String p: Serial.list()) {
    try {
      port = new Serial(this, p, 57600);
    } catch (Exception e) {
    }
  }
}

public void draw() {
  background(8);
  if (!initialized) {
    connectLight();
  }

  while (port.available() >= 3) {
    readResp();
  }

  if (!initialized || reading) {
    tlLoading.show();
    guiui.hide();
    preset_editor.hide();
    palette_panel.hide();
    bundle_editor.hide();
  } else {
    tlLoading.hide();
    guiui.show();
    if (gui_state == 0) {
      preset_editor.show();
      palette_panel.show();
      bundle_editor.hide();
    } else if (gui_state == 1) {
      preset_editor.hide();
      palette_panel.show();
      bundle_editor.hide();
    } else if (gui_state == 2) {
      preset_editor.hide();
      palette_panel.hide();
      bundle_editor.show();
    } else if (gui_state == 3) {
      preset_editor.hide();
      palette_panel.hide();
      bundle_editor.hide();
    }
  }
}

public void sendCmd(char cmd, int target, int addr, int val) {
  port.write(cmd);
  port.write(target);
  port.write(addr);
  port.write(val);
}

public void readResp() {
  int target = port.read();
  int addr = port.read();
  int val = port.read();

  if (target == 100) { // Ack from light
    cur_preset_idx = addr;
    tlLoading.setText("Loading").setPosition(440, 400);
    initialized = true;
    sendCmd('X', 10, 0, 0); // Change to gui play mode
    sendCmd('D', 99, 0, 0); // Get dump of everything
    sendCmd('D', cur_preset_idx, 0, 0);
  } else if (target == 200) {
    cur_preset_idx = val;
    reading = true;
  } else if (target == 201) {
    reading = false;
    preset_editor.refresh();
    bundle_editor.refresh();
    palette_panel.refresh();
  } else {
    readData(target, addr, val);
  }
}

public void changeMode(int mode) {
  gui_state = mode;
  preset_editor.deselect();
  palette_panel.deselect();
  palette_panel.sldRed.setValue(0);
  palette_panel.sldGreen.setValue(0);
  palette_panel.sldBlue.setValue(0);
  sendCmd('X', 20, 0, 0);
  bundle_editor.deselect();
}

public void readData(int target, int addr, int val) {
  if (target < 16) {
    preset_editor.update(target, addr, val);
  } else if (target == 16) {
    bundle_editor.update(addr, val);
  } else if (target == 17) {
    palette_panel.update(addr, val);
    color_palette[addr / 3][addr % 3] = val;
  }
}

public int getColor(int v) {
  int s = v >> 6;
  int c = v % 64;
  int alpha = 127 + (128 >> s);
  println(c);
  if (c != 0) {
    float r = ((color_palette[c][0] / 255.0f) * 192) + 63;
    float g = ((color_palette[c][1] / 255.0f) * 192) + 63;
    float b = ((color_palette[c][2] / 255.0f) * 192) + 63;
    return (alpha << 24) + (PApplet.parseInt(r) << 16) + (PApplet.parseInt(g) << 8) + PApplet.parseInt(b);
  } else {
    return 0;
  }
}

public void controlEvent(ControlEvent theEvent) {
  int val = PApplet.parseInt(theEvent.getValue());
  String evt = theEvent.getName();

  if (gui_initialized) {
    if (evt.startsWith("presetAccMode")) {
      preset_editor.setv(cur_preset_idx, 0, val);
    } else if (evt.startsWith("presetAccSens")) {
      preset_editor.setv(cur_preset_idx, 1, val);
    } else if (evt.startsWith("presetPattern1")) {
      preset_editor.setv(cur_preset_idx, 2, val);
    } else if (evt.startsWith("presetPattern2")) {
      preset_editor.setv(cur_preset_idx, 20, val);
    } else if (evt.startsWith("presetColor")) {
      preset_editor.select(val);
    } else if (evt.startsWith("presetLess1")) {
      preset_editor.setv(cur_preset_idx, 3, 99);
    } else if (evt.startsWith("presetLess2")) {
      preset_editor.setv(cur_preset_idx, 21, 99);
    } else if (evt.startsWith("presetMore1")) {
      int v = preset_editor.setv(cur_preset_idx, 3, 100);
      /* sendCmd('R', cur_preset_idx, 3 + v, 0); */
    } else if (evt.startsWith("presetMore2")) {
      int v = preset_editor.setv(cur_preset_idx, 21, 100);
      /* sendCmd('R', cur_preset_idx, 21 + v, 0); */
    } else if (evt.startsWith("presetReload")) {
      sendCmd('L', cur_preset_idx, 0, 0);
    } else if (evt.startsWith("presetWrite")) {
      sendCmd('S', cur_preset_idx, 0, 0);
    } else if (evt.startsWith("presetSave")) {
      preset_editor.save();
    } else if (evt.startsWith("presetLoad")) {
      preset_editor.load();
    } else if (evt.startsWith("presetPrev")) {
      cur_preset_idx = (cur_preset_idx + 15) % 16;
      sendCmd('X', 0, 0, 0);
      sendCmd('D', cur_preset_idx, 0, 0);
    } else if (evt.startsWith("presetNext")) {
      cur_preset_idx = (cur_preset_idx + 1) % 16;
      sendCmd('X', 1, 0, 0);
      sendCmd('D', cur_preset_idx, 0, 0);
    } else if (evt.startsWith("paletteColor")) {
      if (gui_state == 0) {
        preset_editor.guiChangeColor(val);
      } else if (gui_state == 1) {
        palette_panel.select(val);
      } else if (gui_state == 2) {
      }
    } else if (evt.startsWith("paletteRedSlider")) {
      palette_panel.guiSetR();
    } else if (evt.startsWith("paletteGreenSlider")) {
      palette_panel.guiSetG();
    } else if (evt.startsWith("paletteBlueSlider")) {
      palette_panel.guiSetB();
    } else if (evt.startsWith("paletteReload")) {
      sendCmd('L', 17, 0, 0);
      sendCmd('D', 17, 0, 0);
    } else if (evt.startsWith("paletteWrite")) {
      sendCmd('S', 17, 0, 0);
    } else if (evt.startsWith("paletteSave")) {
      palette_panel.save();
    } else if (evt.startsWith("paletteLoad")) {
      palette_panel.load();
    } else if (evt.startsWith("bundleSlot")) {
      bundle_editor.select(val);
    } else if (evt.startsWith("bundlePreset")) {
      bundle_editor.guiChangeSlot(val);
      sendCmd('X', 2, val, 0);
    } else if (evt.startsWith("bundleReload")) {
      bundle_editor.btnSelected.hide();
      bundle_editor.selected_s = -1;
      sendCmd('L', 16, 0, 0);
      sendCmd('D', 16, 0, 0);
    } else if (evt.startsWith("bundleLess")) {
      bundle_editor.setv(20 * val, 99);
    } else if (evt.startsWith("bundleMore")) {
      bundle_editor.setv(20 * val, 100);
    } else if (evt.startsWith("bundleWrite")) {
      sendCmd('S', 16, 0, 0);
    } else if (evt.startsWith("bundleSave")) {
      bundle_editor.save();
    } else if (evt.startsWith("bundleLoad")) {
      bundle_editor.load();
    } else if (evt.startsWith("guiEditPresets")) {
      changeMode(0);
      sendCmd('X', 2, cur_preset_idx, 0);
      sendCmd('X', 10, 0, 0);
    } else if (evt.startsWith("guiEditPalette")) {
      changeMode(1);
      sendCmd('X', 10, 1, 0);
    } else if (evt.startsWith("guiEditBundles")) {
      changeMode(2);
      sendCmd('D', 16, 0, 0);
      sendCmd('X', 10, 2, 0);
    } else if (evt.startsWith("guiReload")) {
      sendCmd('L', 99, 0, 0);
      sendCmd('D', 99, 0, 0);
    } else if (evt.startsWith("guiWrite")) {
      sendCmd('S', 99, 0, 0);
    } else if (evt.startsWith("guiSave")) {
      guiui.save();
    } else if (evt.startsWith("guiLoad")) {
      guiui.load();
    } else if (evt.startsWith("guiFlash")) {
      guiui.load();
      sendCmd('S', 99, 0, 0);
    } else if (evt.startsWith("guiDisconnect")) {
      sendCmd('X', 10, 99, 0);
      initialized = false;
      tlLoading.setText("Connecting").setPosition(430, 400);
      reading = true;
    } else if (evt.startsWith("guiExit")) {
      sendCmd('X', 10, 99, 0);
      exit();
    }
  } else if (theEvent.isGroup()) {
  } else if (theEvent.isController()) {
  }
}

private static final String codes = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+=";

public char encode(int i) {
  return codes.charAt(i);
}

public int decode(char c) {
  return codes.indexOf(c);
}

public void keyPressed() {
  if (keyCode == KeyEvent.VK_SHIFT) {
    shifted = true;
  }

  if (initialized) {
    if (gui_state == 0) {
      if (keyCode == KeyEvent.VK_UP) {
        int v = (shifted) ? 1 : 0;
        int p = (preset_editor.presets[cur_preset_idx].pattern[v] + NUM_PATTERNS - 1) % NUM_PATTERNS;
        preset_editor.setv(cur_preset_idx, 2 + (v * 18), p);
      } else if (keyCode == DOWN) {
        int v = (shifted) ? 1 : 0;
        int p = (preset_editor.presets[cur_preset_idx].pattern[v] + 1) % NUM_PATTERNS;
        preset_editor.setv(cur_preset_idx, 2 + (v * 18), p);
      }
    } else if (gui_state == 1) {
      if (key == 'q') {
        palette_panel.sldRed.setValue(PApplet.parseFloat(PApplet.parseInt(palette_panel.sldRed.getValue() - 8)));
      } else if (key == 'w') {
        palette_panel.sldRed.setValue(PApplet.parseFloat(PApplet.parseInt(palette_panel.sldRed.getValue() - 1)));
      } else if (key == 'e') {
        palette_panel.sldRed.setValue(PApplet.parseFloat(PApplet.parseInt(palette_panel.sldRed.getValue() + 1)));
      } else if (key == 'r') {
        palette_panel.sldRed.setValue(PApplet.parseFloat(PApplet.parseInt(palette_panel.sldRed.getValue() + 8)));

      } else if (key == 'a') {
        palette_panel.sldGreen.setValue(PApplet.parseFloat(PApplet.parseInt(palette_panel.sldGreen.getValue() - 8)));
      } else if (key == 's') {
        palette_panel.sldGreen.setValue(PApplet.parseFloat(PApplet.parseInt(palette_panel.sldGreen.getValue() - 1)));
      } else if (key == 'd') {
        palette_panel.sldGreen.setValue(PApplet.parseFloat(PApplet.parseInt(palette_panel.sldGreen.getValue() + 1)));
      } else if (key == 'f') {
        palette_panel.sldGreen.setValue(PApplet.parseFloat(PApplet.parseInt(palette_panel.sldGreen.getValue() + 8)));

      } else if (key == 'z') {
        palette_panel.sldBlue.setValue(PApplet.parseFloat(PApplet.parseInt(palette_panel.sldBlue.getValue() - 8)));
      } else if (key == 'x') {
        palette_panel.sldBlue.setValue(PApplet.parseFloat(PApplet.parseInt(palette_panel.sldBlue.getValue() - 1)));
      } else if (key == 'c') {
        palette_panel.sldBlue.setValue(PApplet.parseFloat(PApplet.parseInt(palette_panel.sldBlue.getValue() + 1)));
      } else if (key == 'v') {
        palette_panel.sldBlue.setValue(PApplet.parseFloat(PApplet.parseInt(palette_panel.sldBlue.getValue() + 8)));
      }
    }
  }
}

public void keyReleased() {
  if (keyCode == KeyEvent.VK_SHIFT) {
    shifted = false;
  }
}
class BundleEditor {
  Group grp;
  Textlabel tlTitle;
  Button[][] btnBundles = new Button[4][16];
  Button[] btnLess = new Button[4];
  Button[] btnMore = new Button[4];
  Button btnReload, btnWrite, btnSave, btnLoad;
  Textfield tfPath;
  Button btnSelected;
  Button[] btnPresets = new Button[16];
  int bundle_slots[] = new int[4];
  int bundles[][] = new int[4][16];
  int selected_b, selected_s = -1;

  BundleEditor(int x, int y) {
    grp = cp5.addGroup("bundleEditor")
      .setPosition(x, y)
      .hideBar()
      .hideArrow();

    tlTitle = cp5.addTextlabel("bundleTitle")
      .setText("Bundles")
      .setPosition(320, 20)
      .setColorValue(0xff8888ff)
      .setFont(createFont("Arial", 32))
      .setGroup(grp);

    btnSelected = cp5.addButton("bundleSelected")
      .setPosition(0, 0)
      .setSize(40, 40)
      .setColorBackground(color(192))
      .setCaptionLabel("")
      .setGroup(grp)
      .hide();

    btnReload = cp5.addButton("bundleReload")
      .setPosition(110, 250)
      .setSize(80, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Reload Bundles")
      .setGroup(grp);

    btnWrite = cp5.addButton("bundleWrite")
      .setPosition(210, 250)
      .setSize(80, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Write Bundles")
      .setGroup(grp);

    btnSave = cp5.addButton("bundleSave")
      .setPosition(640, 250)
      .setSize(30, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Save")
      .setGroup(grp);

    btnLoad = cp5.addButton("bundleLoad")
      .setPosition(680, 250)
      .setSize(30, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Load")
      .setGroup(grp);

    tfPath = cp5.addTextfield("bundlePath")
      .setValue("")
      .setPosition(490, 250)
      .setSize(140, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("")
      .setText("primer.bundle")
      .setGroup(grp);

    for (int b = 0; b < 4; b++) {
      btnLess[b] = cp5.addButton("bundleLess" + (b + 1))
        .setPosition(20, 78 + (b * 40))
        .setValue(b)
        .setSize(40, 20)
        .setColorBackground(color(64))
        .setCaptionLabel("Less")
        .setGroup(grp);

      btnMore[b] = cp5.addButton("bundleMore" + (b + 1))
        .setPosition(740, 78 + (b * 40))
        .setValue(b)
        .setSize(40, 20)
        .setColorBackground(color(64))
        .setCaptionLabel("More")
        .setGroup(grp);

      for (int s = 0; s < 16; s++) {
        int v = (b * 16) + s;
        btnBundles[b][s] = cp5.addButton("bundleSlot" + v, v)
          .setPosition(84 + (s * 40), 70 + (b * 40))
          .setSize(32, 32)
          .setCaptionLabel("")
          .setGroup(grp)
          .setColorBackground(color(64));
      }
    }

    for (int s = 0; s < 16; s++) {
      btnPresets[s] = cp5.addButton("bundlePreset" + s, s)
        .setPosition(84 + (s * 40), 400)
        .setSize(32, 32)
        .setCaptionLabel("PS" + (s + 1))
        .setGroup(grp)
        .setColorBackground(color(64));
    }
  }

  public void hide() {
    grp.hide();
  }

  public void show() {
    grp.show();
  }

  public void select(int i) {
    int b = i / 16;
    int s = i % 16;
    if (s < bundle_slots[b]) {
      float[] pos = btnBundles[b][s].getPosition();
      btnSelected.setPosition(pos[0] - 4, pos[1] - 4);
      btnSelected.show();
    }
    selected_b = b;
    selected_s = s;
  }

  public void deselect() {
    selected_b = selected_s = -1;
    btnSelected.hide();
  }

  public void guiChangeSlot(int val) {
    if (selected_s >= 0) {
      setv((20 * selected_b) + selected_s + 1, val);
    }
  }

  public int update(int addr, int val) {
    println("addr: " + addr + " v: " + val);
    if (addr % 20 == 0) {
      return setNumSlots(addr / 20, val);
    } else {
      return setSlot(addr / 20, (addr % 20) - 1, val);
    }
  }

  public int setSlot(int b, int s, int v) {
    bundles[b][s] = v;
    if (s < bundle_slots[b]) {
      btnBundles[b][s].setCaptionLabel("PS" + (v + 1)).setColorBackground(color(64));
    } else {
      btnBundles[b][s].setCaptionLabel("off").setColorBackground(0);
    }
    return v;
  }

  public int setNumSlots(int b, int val) {
    if (val == 100) {
      val = bundle_slots[b] + 1;
    } else if (val == 99) {
      val = bundle_slots[b] - 1;
      if (selected_b == b && selected_s >= val) {
        selected_s = -1;
        btnSelected.hide();
      }
    }

    if (val < 1 || val > 16) {
      return bundle_slots[b];
    }
    bundle_slots[b] = val;
    if (val == 1) {
      btnLess[b].hide();
      btnMore[b].show();
    } else if (val == 16) {
      btnLess[b].show();
      btnMore[b].hide();
    } else {
      btnLess[b].show();
      btnMore[b].show();
    }
    for (int i = 0; i < 16; i++) {
      if (i < val) {
        btnBundles[b][i].setCaptionLabel("PS" + (bundles[b][i] + 1)).setColorBackground(color(64));
      } else {
        btnBundles[b][i].setCaptionLabel("off").setColorBackground(0);
      }
    }
    return bundle_slots[b];
  }

  public void setv(int addr, int val) {
    val = update(addr, val);
    sendCmd('W', 16, addr, val);
  }

  public String compress() {
    char[] rtn = new char[68];
    for (int b = 0; b < 4; b++) {
      rtn[b * 17] = encode(bundle_slots[b]);
      for (int s = 0; s < 16; s++) {
        rtn[(b * 17) + s + 1] = encode(bundles[b][s]);
      }
    }

    return new String(rtn);
  }

  public void save() {
    String[] strs = new String[1];
    strs[0] = compress();
    saveStrings(tfPath.getText(), strs);
  }

  public void decompress(String s) {
    if (s.length() == 68) {
      for (int b = 0; b < 4; b++) {
        setv(b * 20, decode(s.charAt(b * 17)));
        for (int i = 0; i < 16; i++) {
          setv((b * 20) + i + 1, decode(s.charAt((b * 17) + i + 1)));
        }
      }
    }
  }

  public void load() {
    String[] strs = loadStrings(tfPath.getText());
    decompress(strs[0]);
  }

  public void refresh() {
    btnSelected.hide();
    for (int b = 0; b < 4; b++) {
      if (bundle_slots[b] == 1) {
        btnLess[b].hide();
        btnMore[b].show();
      } else if (bundle_slots[b] == 16) {
        btnLess[b].show();
        btnMore[b].hide();
      } else {
        btnLess[b].show();
        btnMore[b].show();
      }
      for (int s = 0; s < 16; s++) {
        if (s < bundle_slots[b]) {
          btnBundles[b][s].setCaptionLabel("PS" + (bundles[b][s] + 1)).setColorBackground(color(64));
        } else {
          btnBundles[b][s].setCaptionLabel("off").setColorBackground(0);
        }
      }
    }
  }
}
class GuiUI {
  Group grp;
  Button btnEditPresets, btnEditPalette, btnEditBundles, btnExit;
  Button btnReload, btnWrite, btnSave, btnLoad, btnFlash, btnDisconnect;
  Textfield tfPath;

  GuiUI(int x, int y) {
    grp = cp5.addGroup("guiUi")
      .setPosition(x, y)
      .hideBar()
      .hideArrow();

    btnEditPresets = cp5.addButton("guiEditPresets")
      .setPosition(30, 10)
      .setSize(60, 20)
      .setColorLabel(color(0))
      .setColorBackground(color(240))
      .setCaptionLabel("Edit Presets")
      .setGroup(grp);

    btnEditPalette = cp5.addButton("guiEditPalette")
      .setPosition(30, 40)
      .setSize(60, 20)
      .setColorLabel(color(0))
      .setColorBackground(color(240))
      .setCaptionLabel("Edit Palette")
      .setGroup(grp);

    btnEditBundles = cp5.addButton("guiEditBundles")
      .setPosition(30, 70)
      .setSize(60, 20)
      .setColorLabel(color(0))
      .setColorBackground(color(240))
      .setCaptionLabel("Edit Bundles")
      .setGroup(grp);

    btnReload = cp5.addButton("guiReload")
      .setPosition(30, 130)
      .setSize(60, 20)
      .setColorBackground((255 << 24) + (128 << 16) + (64 << 8) + (64))
      .setCaptionLabel("Reload Light")
      .setGroup(grp);

    btnWrite = cp5.addButton("guiWrite")
      .setPosition(30, 160)
      .setSize(60, 20)
      .setColorBackground((255 << 24) + (128 << 16) + (64 << 8) + (64))
      .setCaptionLabel("Write Light")
      .setGroup(grp);

    btnFlash = cp5.addButton("guiFlash")
      .setPosition(30, 190)
      .setSize(60, 20)
      .setColorBackground((255 << 24) + (128 << 16) + (64 << 8) + (64))
      .setCaptionLabel("Upload Light")
      .setGroup(grp);

    tfPath = cp5.addTextfield("guiPath")
      .setPosition(20, 220)
      .setSize(80, 20)
      .setColorBackground(color(0))
      .setCaptionLabel("")
      .setText("primer.light")
      .setGroup(grp);

    btnSave = cp5.addButton("guiSave")
      .setPosition(30, 250)
      .setSize(60, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Save")
      .setGroup(grp);

    btnLoad = cp5.addButton("guiLoad")
      .setPosition(30, 280)
      .setSize(60, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Load")
      .setGroup(grp);

    btnLoad = cp5.addButton("guiDisconnect")
      .setPosition(30, 340)
      .setSize(60, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Disconnect")
      .setGroup(grp);

    btnExit = cp5.addButton("guiExit")
      .setPosition(30, 370)
      .setSize(60, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Exit")
      .setGroup(grp);
  }

  public void hide() {
    grp.hide();
  }

  public void show() {
    grp.show();
  }

  public void save() {
    String[] strs = new String[18];
    for (int i = 0; i < 16; i++) {
      strs[i] = preset_editor.compressMode(i);
    }
    strs[16] = bundle_editor.compress();
    strs[17] = palette_panel.compress();
    saveStrings(tfPath.getText(), strs);
  }

  public void load() {
    String[] strs = loadStrings(tfPath.getText());
    palette_panel.decompress(strs[17]);
    palette_panel.refresh();
    for (int i = 0; i < 16; i++) {
      preset_editor.decompressMode(i, strs[i]);
    }
    preset_editor.refresh();
    bundle_editor.decompress(strs[16]);
    bundle_editor.refresh();
  }
}
int NUM_COLORS = 64;

class PalettePanel {
  Group grp, grpEdit;
  Textlabel tlTitle;
  Textfield tfPath;
  Button[][] btnPalette = new Button[48][4];
  Button btnSelected;
  Button btnReload, btnWrite, btnSave, btnLoad;
  Slider sldRed, sldGreen, sldBlue;
  int selected = 0;
  int selected_shade = 0;

  PalettePanel(int x, int y) {
    grpEdit = cp5.addGroup("paletteEditor")
      .setPosition(x, y)
      .hideBar()
      .hideArrow();

    grp = cp5.addGroup("palettePanel")
      .setPosition(x, y + 240)
      .hideBar()
      .hideArrow();

    btnSelected = cp5.addButton("paletteSelected")
      .setPosition(0, 0)
      .setSize(40, 160)
      .setColorBackground(color(192))
      .setCaptionLabel("")
      .setGroup(grp)
      .hide();

    btnReload = cp5.addButton("paletteReload")
      .setPosition(110, 190)
      .setSize(80, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Reload Palette")
      .setGroup(grpEdit);

    btnWrite = cp5.addButton("paletteWrite")
      .setPosition(210, 190)
      .setSize(80, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Write Palette")
      .setGroup(grpEdit);

    btnSave = cp5.addButton("paletteSave")
      .setPosition(640, 190)
      .setSize(30, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Save")
      .setGroup(grpEdit);

    btnLoad = cp5.addButton("paletteLoad")
      .setPosition(680, 190)
      .setSize(30, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Load")
      .setGroup(grpEdit);

    tfPath = cp5.addTextfield("palettePath")
      .setValue("")
      .setPosition(490, 190)
      .setSize(140, 20)
      .setColorBackground(color(0))
      .setCaptionLabel("")
      .setText("primer.palette")
      .setGroup(grpEdit);

    for (int c = 0; c < 48; c++) {
      for (int s = 0; s < 4; s++) {
        int v = (s << 6) + c;
        int g = c / 8;
        btnPalette[c][s] = cp5.addButton("paletteColor" + v, v)
          .setPosition(((g % 2) * 340) + ((c % 8) * 40) + 114,
                       ((g / 2) * 180) + (s * 40) + 4)
          .setSize(32, 32)
          .setCaptionLabel(c + "/" + (s + 1))
          .setGroup(grp)
          .setColorBackground(getColor(v));
      }
    }

    tlTitle = cp5.addTextlabel("paletteTitle")
      .setText("Palette")
      .setPosition(330, 20)
      .setColorValue(0xff8888ff)
      .setFont(createFont("Arial", 32))
      .setGroup(grpEdit);

    sldRed = cp5.addSlider("paletteRedSlider")
       .setPosition(40, 70)
       .setSize(720, 30)
       .setRange(0, 255)
       .setValue(0)
       .setColorForeground(color(192, 0, 0))
       .setColorBackground(color(64, 0, 0))
       .setColorActive(color(255, 0, 0))
       .setCaptionLabel("")
       .setGroup(grpEdit);

    sldGreen = cp5.addSlider("paletteGreenSlider")
       .setPosition(40, 110)
       .setSize(720, 30)
       .setRange(0, 255)
       .setValue(0)
       .setColorForeground(color(0, 192, 0))
       .setColorBackground(color(0, 64, 0))
       .setColorActive(color(0, 255, 0))
       .setCaptionLabel("")
       .setGroup(grpEdit);

    sldBlue = cp5.addSlider("paletteBlueSlider")
       .setPosition(40, 150)
       .setSize(720, 30)
       .setRange(0, 255)
       .setValue(0)
       .setColorForeground(color(0, 0, 192))
       .setColorBackground(color(0, 0, 64))
       .setColorActive(color(0, 0, 255))
       .setCaptionLabel("")
       .setGroup(grpEdit);
  }

  public void update(int addr, int val) {
    int v = addr / 3;
    int c = addr % 3 ;
    color_palette[v][c] = val;

    btnPalette[v][0].setColorBackground(getColor(v));
    btnPalette[v][1].setColorBackground(getColor(v + 64));
    btnPalette[v][2].setColorBackground(getColor(v + 128));
    btnPalette[v][3].setColorBackground(getColor(v + 192));
  }

  public void setv(int addr, int val) {
    update(addr, val);
    sendCmd('W', 17, addr, val);
  }

  public void guiSetR() {
    if (selected >= 0) {
      setv((selected * 3), PApplet.parseInt(sldRed.getValue()));
    }
  }

  public void guiSetG() {
    if (selected >= 0) {
      setv((selected * 3) + 1, PApplet.parseInt(sldGreen.getValue()));
    }
  }

  public void guiSetB() {
    if (selected >= 0) {
      setv((selected * 3) + 2, PApplet.parseInt(sldBlue.getValue()));
    }
  }

  public void select(int val) {
    selected = val % 64;
    selected_shade = val / 64;
    if (selected != 0) {
      float[] pos = btnPalette[selected][0].getPosition();
      btnSelected.setPosition(pos[0] - 4, pos[1] - 4);
      btnSelected.show();
      sldRed.setValue(color_palette[selected][0]);
      sldGreen.setValue(color_palette[selected][1]);
      sldBlue.setValue(color_palette[selected][2]);
      sendCmd('X', 20, selected, selected_shade);
    } else {
      btnSelected.hide();
    }
  }

  public void deselect() {
    btnSelected.hide();
    selected = selected_shade = -1;
  }

  public void show() {
    if (gui_state == 1) {
      grpEdit.show();
    } else {
      grpEdit.hide();
    }
    grp.show();
  }

  public void hide() {
    grp.hide();
    grpEdit.hide();
  }

  public String compress() {
    char[] rtn = new char[192];
    int i;
    for (int c = 0; c < 32; c++) {
      i = c * 6;
      rtn[i + 0] = encode(color_palette[c][0] >> 6);
      rtn[i + 1] = encode(color_palette[c][0] % 64);
      rtn[i + 2] = encode(color_palette[c][1] >> 6);
      rtn[i + 3] = encode(color_palette[c][1] % 64);
      rtn[i + 4] = encode(color_palette[c][2] >> 6);
      rtn[i + 5] = encode(color_palette[c][2] % 64);
    }
    return new String(rtn);
  }

  public void save() {
    String[] strs = new String[1];
    strs[0] = compress();
    saveStrings(tfPath.getText(), strs);
  }

  public void decompress(String s) {
    if (s.length() == 192) {
      for (int c = 0; c < 32; c++) {
        palette_panel.setv((c * 4) + 0, (decode(s.charAt((c * 6) + 0)) << 6) + decode(s.charAt((c * 6) + 1)));
        palette_panel.setv((c * 4) + 1, (decode(s.charAt((c * 6) + 2)) << 6) + decode(s.charAt((c * 6) + 3)));
        palette_panel.setv((c * 4) + 2, (decode(s.charAt((c * 6) + 4)) << 6) + decode(s.charAt((c * 6) + 5)));
      }
    }
  }

  public void load() {
    String[] strs = loadStrings(tfPath.getText());
    decompress(strs[0]);
  }

  public void refresh() {
    select(0);
    for (int c = 0; c < 32; c++) {
      for (int s = 0; s < 4; s++) {
        int v = (s << 6) + c;
        btnPalette[c][s].setColorBackground(getColor(v));
      }
    }
  }
}
int NUM_PATTERNS = 62;
String[] pattern_names = {
  "RIBBON",
  "HYPER",
  "STROBE",
  "NANO",
  "DOPS",
  "SLOW_STROBE",
  "STROBIE",
  "FAINT",
  "SIGNAL",
  "BLASTER",
  "HEAVYBLASTER",
  "AUTOBLASTER",
  "STROBE2",
  "HYPER3",
  "DOPS3",
  "BLASTER3",
  "HEAVYBLASTER3",
  "AUTOBLASTER3",
  "TRACER",
  "DASHDOPS",
  "DOPSDASH",
  "VEXING",
  "VEXING3",
  "RIBBONTRACER",
  "DOTTED",
  "FIREWORK",
  "BOTTLEROCKET",
  "GROW",
  "SHRINK",
  "STRETCH",
  "WAVE",
  "SHIFT",
  "COMET",
  "METEOR",
  "EMBERS",
  "INFLUX",
  "SWORD",
  "SWORD5",
  "RAZOR",
  "RAZOR5",
  "BARBS",
  "BARBS5",
  "CYCLOPS",
  "FADEIN",
  "STROBEIN",
  "FADEOUT",
  "STROBEOUT",
  "PULSE",
  "PULSAR",
  "SLOW_MORPH",
  "MORPH",
  "DOPMORPH",
  "STROBIEMORPH",
  "STROBEMORPH",
  "HYPERMORPH",
  "DASHMORPH",
  "FUSE",
  "DOPFUSE",
  "STROBEFUSE",
  "STROBIEFUSE",
  "HYPERFUSE",
  "DASHFUSE",
};

String[] accel_mode_names = {"Off", "Speed", "Tilt X", "Tilt Y", "Flip Z"};
String[] accel_sens_names = {"Low", "Medium", "High"};


class Preset {
  int idx;
  int accMode, accSens;
  int[] pattern = new int[2];
  int[] numColors = new int[2];
  int[][] colors = new int[2][16];

  Preset(int i) {
    idx = i;
  }
}

class PresetEditor {
  Group grp;
  Textlabel tlTitle;
  DropdownList ddlAccMode, ddlAccSens;
  DropdownList[] ddlPattern = new DropdownList[2];
  Button[] btnLess = new Button[2];
  Button[] btnMore = new Button[2];
  Button btnSelected;
  Button[][] btnColors = new Button[2][16];
  Button btnPrev, btnNext;
  Button btnReload, btnWrite, btnSave, btnLoad;
  Textfield tfPath;
  Preset[] presets = new Preset[16];
  int selected_v, selected_s = -1;

  PresetEditor(int x, int y) {
    for (int i = 0; i < 16; i++) {
      presets[i] = new Preset(i);
    }

    grp = cp5.addGroup("presetEditor")
      .setPosition(x, y)
      .hideBar()
      .hideArrow();

    tlTitle = cp5.addTextlabel("presetTitle")
      .setText("Preset 1")
      .setPosition(330, 20)
      .setColorValue(0xff8888ff)
      .setFont(createFont("Arial", 32))
      .setGroup(grp);

    btnSelected = cp5.addButton("presetSelected")
      .setPosition(0, 0)
      .setSize(40, 40)
      .setColorBackground(color(192))
      .setCaptionLabel("")
      .setGroup(grp)
      .hide();

    btnReload = cp5.addButton("presetReload")
      .setPosition(210, 190)
      .setSize(80, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Reload Preset")
      .setGroup(grp);

    btnWrite = cp5.addButton("presetWrite")
      .setPosition(310, 190)
      .setSize(80, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Write Preset")
      .setGroup(grp);

    btnPrev = cp5.addButton("presetPrev")
      .setPosition(250, 30)
      .setSize(50, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("<< PREV")
      .setGroup(grp);

    btnNext = cp5.addButton("presetNext")
      .setPosition(500, 30)
      .setSize(50, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("NEXT >>")
      .setGroup(grp);

    btnSave = cp5.addButton("presetSave")
      .setPosition(560, 190)
      .setSize(30, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Save")
      .setGroup(grp);

    btnLoad = cp5.addButton("presetLoad")
      .setPosition(600, 190)
      .setSize(30, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Load")
      .setGroup(grp);

    tfPath = cp5.addTextfield("presetPath")
      .setValue("")
      .setPosition(410, 190)
      .setSize(140, 20)
      .setColorBackground(color(0))
      .setText("primer1.mode")
      .setCaptionLabel("")
      .setGroup(grp);

    for (int v = 0; v < 2; v++) {
      for (int s = 0; s < 16; s++) {
        btnColors[v][s] = cp5.addButton("presetColor" + v + "_" + s)
          .setValue((v << 4) + s)
          .setPosition(84 + (s * 40), 100 + (v * 40))
          .setSize(32, 32)
          .setColorBackground(color(0))
          .setCaptionLabel("")
          .setGroup(grp);
      }

      btnLess[v] = cp5.addButton("presetLess" + (v + 1))
        .setPosition(34, 104 + (v * 40))
        .setSize(40, 20)
        .setColorBackground(color(64))
        .setCaptionLabel("Less")
        .setGroup(grp);

      btnMore[v] = cp5.addButton("presetMore" + (v + 1))
        .setPosition(726, 104 + (v * 40))
        .setSize(40, 20)
        .setColorBackground(color(64))
        .setCaptionLabel("More")
        .setGroup(grp);
    }

    ddlPattern[0] = buildPatternDropdown(0)
      .setPosition(70, 70)
      .setSize(150, 500)
      .setItemHeight(15)
      .setColorBackground(color(64))
      .setGroup(grp);

    ddlAccMode = buildAccModeDropdown()
      .setPosition(240, 70)
      .setSize(150, 500)
      .setItemHeight(15)
      .setColorBackground(color(64))
      .setGroup(grp);

    ddlAccSens = buildAccSensDropdown()
      .setPosition(410, 70)
      .setSize(150, 500)
      .setItemHeight(15)
      .setColorBackground(color(64))
      .setGroup(grp);

    ddlPattern[1] = buildPatternDropdown(1)
      .setPosition(580, 70)
      .setSize(150, 500)
      .setItemHeight(15)
      .setColorBackground(color(64))
      .setGroup(grp);
  }

  public DropdownList buildAccSensDropdown() {
    DropdownList dd = cp5.addDropdownList("presetAccSens");
    dd.setBackgroundColor(color(200));
    dd.setColorActive(color(255, 128));
    dd.setItemHeight(20);
    dd.setBarHeight(15);
    for (int j = 0; j < 3; j++) {
      dd.addItem(accel_sens_names[j], j);
    }
    dd.close();
    return dd;
  }

  public DropdownList buildAccModeDropdown() {
    DropdownList dd = cp5.addDropdownList("presetAccMode");
    dd.setBackgroundColor(color(200));
    dd.setColorActive(color(255, 128));
    dd.setItemHeight(20);
    dd.setBarHeight(15);
    for (int j = 0; j < 5; j++) {
      dd.addItem(accel_mode_names[j], j);
    }
    dd.close();
    return dd;
  }

  public DropdownList buildPatternDropdown(int var) {
    DropdownList dd = cp5.addDropdownList("presetPattern" + (var + 1));
    dd.setBackgroundColor(color(200));
    dd.setColorActive(color(255, 128));
    dd.setItemHeight(20);
    dd.setBarHeight(15);
    for (int j = 0; j < NUM_PATTERNS; j++) {
      dd.addItem((j + 1) + ": " + pattern_names[j], j);
    }
    dd.close();
    return dd;
  }

  public int update(int target, int addr, int val) {
    if (addr == 0) {
      return setAccMode(target, val);
    } else if (addr == 1) {
      return setAccSens(target, val);
    } else if (addr == 2) {
      return setPattern(target, 0, val);
    } else if (addr == 3) {
      return setNumColors(target, 0, val);
    } else if (addr < 20) {
      return setColor(target, 0, addr - 4, val);
    } else if (addr == 20) {
      return setPattern(target, 1, val);
    } else if (addr == 21) {
      return setNumColors(target, 1, val);
    } else if (addr < 38) {
      return setColor(target, 1, addr - 22, val);
    }
    return 0;
  }

  public int setv(int target, int addr, int val) {
    val = update(target, addr, val);
    sendCmd('W', target, addr, val);
    return val;
  }

  public void hide() {
    grp.hide();
  }

  public void show() {
    grp.show();
  }

  public void select(int i) {
    int v = i / 16;
    int s = i % 16;
    if (s < presets[cur_preset_idx].numColors[v]) {
      float[] pos = btnColors[v][s].getPosition();
      btnSelected.setPosition(pos[0] - 4, pos[1] - 4);
      btnSelected.show();
    }
    selected_v = v;
    selected_s = s;
  }

  public void deselect() {
    selected_v = selected_s = -1;
    btnSelected.hide();
  }

  public void guiChangeColor(int val) {
    if (selected_s >= 0) {
      setv(cur_preset_idx, (selected_v * 18) + selected_s + 4, val);
    }
  }

  public int setAccMode(int target, int val) {
    if (target == cur_preset_idx) {
      ddlAccMode.setCaptionLabel(accel_mode_names[val]);
    }
    presets[target].accMode = val;
    return val;
  }

  public int setAccSens(int target, int val) {
    if (target == cur_preset_idx) {
      ddlAccSens.setCaptionLabel(accel_sens_names[val]);
    }
    presets[target].accSens = val;
    return val;
  }

  public int setPattern(int target, int var, int val) {
    if (target == cur_preset_idx) {
      ddlPattern[var].setCaptionLabel("Pattern " + (var + 1) + ": " + pattern_names[val]);
    }
    presets[target].pattern[var] = val;
    return val;
  }

  public int setColor(int target, int var, int slot, int val) {
    if (target == cur_preset_idx) {
      btnColors[var][slot].setColorBackground(getColor(val));
    }
    presets[target].colors[var][slot] = val;
    setNumColors(target, var, presets[target].numColors[var]);
    return val;
  }

  public int setNumColors(int target, int var, int val) {
    if (val == 100) {
      val = presets[target].numColors[var] + 1;
    } else if (val == 99) {
      val = presets[target].numColors[var] - 1;
      if (selected_v == var && selected_s == val) {
        selected_s = -1;
        btnSelected.hide();
      }
    }

    if (val < 1 || val > 16) {
      return presets[target].numColors[var];
    }
    presets[target].numColors[var] = val;
    refresh();
    return val;
  }

  public String compressMode(int target) {
    char[] rtn = new char[69];
    rtn[0] = encode((preset_editor.presets[target].accSens * 8) + preset_editor.presets[target].accMode);
    for (int v = 0; v < 2; v++) {
      rtn[(v * 34) + 1] = encode(preset_editor.presets[target].pattern[v]);
      rtn[(v * 34) + 2] = encode(preset_editor.presets[target].numColors[v]);
      for (int s = 0; s < 16; s++) {
        rtn[(v * 34) + (s * 2) + 3] = encode((preset_editor.presets[target].colors[v][s] >> 6));
        rtn[(v * 34) + (s * 2) + 4] = encode((preset_editor.presets[target].colors[v][s] % 64));
      }
    }

    return new String(rtn);
  }

  public void save() {
    String[] strs = new String[1];
    strs[0] = compressMode(cur_preset_idx);
    saveStrings(tfPath.getText(), strs);
  }

  public void decompressMode(int target, String s) {
    if (s.length() == 69) {
      setv(target, 0, decode(s.charAt(0)) % 8);
      setv(target, 1, decode(s.charAt(0)) / 8);
      for (int v = 0; v < 2; v++) {
        setv(target, (v * 18) + 2, decode(s.charAt((v * 34) + 1)));
        setv(target, (v * 18) + 3, decode(s.charAt((v * 34) + 2)));
        for (int c = 0; c < 16; c++) {
          setv(target, (v * 18) + c + 4,
              (decode(s.charAt((v * 34) + (2 * c) + 3)) << 6) +
              decode(s.charAt((v * 34) + (2 * c) + 4)));
        }
      }
    }
  }

  public void load() {
    String[] strs = loadStrings(tfPath.getText());
    decompressMode(cur_preset_idx, strs[0]);
  }

  public void refresh() {
    tlTitle.setText("Preset " + (cur_preset_idx + 1));
    tfPath.setText("primer" + (cur_preset_idx + 1) + ".mode");
    ddlAccMode.setCaptionLabel(accel_mode_names[presets[cur_preset_idx].accMode]);
    ddlAccSens.setCaptionLabel(accel_sens_names[presets[cur_preset_idx].accSens]);
    for (int v = 0; v < 2; v++) {
      ddlPattern[v].setCaptionLabel("Pattern " + (v + 1) + ": " + pattern_names[presets[cur_preset_idx].pattern[v]]);
      for (int s = 0; s < 16; s++) {
        if (s < presets[cur_preset_idx].numColors[v]) {
          btnColors[v][s].setColorBackground(getColor(presets[cur_preset_idx].colors[v][s]));
          btnColors[v][s].setCaptionLabel((presets[cur_preset_idx].colors[v][s] % 64) + "/" +
                                          ((presets[cur_preset_idx].colors[v][s] >> 6) + 1));
        } else {
          btnColors[v][s].setColorBackground(color(0));
          btnColors[v][s].setCaptionLabel("off").setColorBackground(0);
        }
      }
      if (presets[cur_preset_idx].numColors[v] == 1) {
        btnLess[v].hide();
        btnMore[v].show();
      } else if (presets[cur_preset_idx].numColors[v] == 16) {
        btnLess[v].show();
        btnMore[v].hide();
      } else {
        btnLess[v].show();
        btnMore[v].show();
      }
    }
  }
}
  public void settings() {  size(1000, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "tekton" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
