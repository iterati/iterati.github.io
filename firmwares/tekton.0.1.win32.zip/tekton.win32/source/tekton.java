import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 
import controlP5.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class tekton extends PApplet {

/*
The MIT License (MIT)

Copyright (c) 2015 John Joseph Miller

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/




Serial port;
ControlP5 cp5;

Group grpPalette;
Button[] btnPalette = new Button[32 * 4];
Button btnGlow;
int activeColor = -1;
int activeVariant = -1;

Mode mode;
Boolean init = true;
Boolean lightConnected = false;

public void setup() {
  int v, xo, yo;
  

  cp5 = new ControlP5(this);

  grpPalette = cp5.addGroup("palette")
    .setPosition(0, 0)
    .hideBar()
    .hideArrow();

  btnGlow = cp5.addButton("glow")
    .setPosition(0, 0)
    .setSize(40, 40)
    .setColorBackground(color(240))
    .setCaptionLabel("")
    .setGroup(grpPalette)
    .hide();

  for (int g = 0; g < 4; g++) {
    for (int s = 0; s < 4; s++) {
      for (int i = 0; i < 8; i++) {
        xo = (g % 2) * 400;
        yo = (g / 2) * 182;
        v = (s << 6) + i + (g * 8);
        btnPalette[i] = cp5.addButton("palette" + v, v)
          .setPosition(xo + 44 + (i * 40), yo + 230 + + (s * 40))
          .setCaptionLabel("" + v)
          .setSize(32, 32)
          .setGroup(grpPalette)
          .setColorBackground(getColor(v));
      }
    }
  }

  for (String p: Serial.list()) {
    try {
      port = new Serial(this, p, 57600);
      lightConnected = true;
    } catch (Exception e) {
    }
  }

  mode = new Mode(0.0f, 0.0f);
  mode.hide();
  init = false;

  if (!lightConnected) {
    mode.tlLoading.setText("Connect light and restart");
  }
}

public void sendValue(int addr, int val) {
  port.write('W');
  port.write(addr);
  port.write(val);
  mode.update(addr, val);
}

public void loadMode() {
  String[] strs = loadStrings(mode.tfPath.getText());
  decompressMode(strs[0]);
}

public void saveMode() {
  String[] strs = new String[1];
  strs[0] = compressMode();
  saveStrings(mode.tfPath.getText(), strs);
}

public void draw() {
  int in1, in2;

  background(8);
  if (lightConnected && port.available() > 1) {
    in1 = port.read();
    in2 = port.read();
    if (in1 == 100) {
      port.write('D');
    } else if (in1 == 101) {
      mode.hide();
      btnGlow.hide();
      activeColor = -1;
      activeVariant = -1;
    } else if (in1 == 102) {
      mode.setLightIdx(in2);
      mode.show();
    } else if (in1 >= 0 && in1 < 38) {
      mode.update(in1, in2);
    }
  } else {
  }
}

public void controlEvent(ControlEvent theEvent) {
  int val = PApplet.parseInt(theEvent.getValue());
  String evt = theEvent.getName();

  if (!init) {
    if (evt.startsWith("accMode")) {
      sendValue(0, val);
    } else if (evt.startsWith("accSens")) {
      sendValue(1, val);
    } else if (evt.startsWith("pattern0")) {
      sendValue(2, val);
    } else if (evt.startsWith("pattern1")) {
      sendValue(20, val);
    } else if (evt.startsWith("color")) {
      if (val % 16 < mode.numColors[val >> 6]) {
        activeVariant = val >> 6;
        activeColor = val % 16;
        btnGlow.setPosition(80 + (activeColor * 40), 96 + (activeVariant * 40));
        btnGlow.show();
      }
    } else if (evt.startsWith("lessA")) {
      mode.setNumColors(0, mode.numColors[0] - 1);
      sendValue(3, mode.numColors[0]);
    } else if (evt.startsWith("lessB")) {
      mode.setNumColors(1, mode.numColors[1] - 1);
      sendValue(21, mode.numColors[1]);
    } else if (evt.startsWith("moreA")) {
      mode.setNumColors(0, mode.numColors[0] + 1);
      sendValue(3, mode.numColors[0]);
      port.write('R');
      port.write(mode.numColors[0] + 3);
    } else if (evt.startsWith("moreB")) {
      mode.setNumColors(1, mode.numColors[1] + 1);
      sendValue(21, mode.numColors[1]);
      port.write('R');
      port.write(mode.numColors[1] + 21);
    } else if (evt.startsWith("reloadMode")) {
      port.write('X');
    } else if (evt.startsWith("writeMode")) {
      port.write('S');
    } else if (evt.startsWith("saveMode")) {
      // read from textfield and try to write more to disk
      saveMode();
    } else if (evt.startsWith("loadMode")) {
      loadMode();
    } else if (evt.startsWith("nextMode")) {
      port.write('N');
    } else if (evt.startsWith("prevMode")) {
      port.write('P');
    } else if (evt.startsWith("palette")) {
      if (activeColor >= mode.numColors[activeVariant]) {
      } else if (activeVariant < 0 || activeColor < 0) {
      } else {
        sendValue((activeVariant * 18) + activeColor + 4, val);
      }
    }
  } else if (theEvent.isGroup()) {
  } else if (theEvent.isController()) {
  }
}

public char encode(int i) {
  return PApplet.parseChar(i + 48);
}

public int decode(char c) {
  return PApplet.parseInt(c) - 48;
}

public String compressMode() {
  char[] rtn = new char[70];
  rtn[0] = 'Z';
  rtn[1] = encode((mode.accSens << 3) + mode.accMode);
  for (int v = 0; v < 2; v++) {
    rtn[(v * 34) + 2] = encode(mode.pattern[v]);
    rtn[(v * 34) + 3] = encode(mode.numColors[v]);
    for (int s = 0; s < 16; s++) {
      rtn[(v * 34) + (s * 2) + 4] = encode((mode.colors[v][s] >> 6));
      rtn[(v * 34) + (s * 2) + 5] = encode((mode.colors[v][s] % 64));
    }
  }

  return new String(rtn);
}

public void decompressMode(String s) {
  if (s.length() == 70 && s.charAt(0) == 'Z') {
    sendValue(0, decode(s.charAt(1)) % 8);
    sendValue(1, decode(s.charAt(1)) >> 3);
    for (int v = 0; v < 2; v++) {
      sendValue((v * 18) + 2, decode(s.charAt((v * 34) + 2)));
      sendValue((v * 18) + 3, decode(s.charAt((v * 34) + 3)));
      for (int c = 0; c < 16; c++) {
        sendValue((v * 18) + c + 4,
            (decode(s.charAt((v * 34) + (2 * c) + 4)) << 6) +
            decode(s.charAt((v * 34) + (2 * c) + 5)));
      }
    }
  }
}


int[][] palette = new int[][] {
  {0, 0, 0},
  {255, 255, 255},
  {64, 0, 0},
  {64, 64, 0},
  {0, 64, 0},
  {0, 64, 64},
  {0, 0, 64},
  {64, 0, 64},
  {255, 0, 0},
  {255, 0, 0},
  {224, 32, 0},
  {192, 64, 0},
  {160, 96, 0},
  {128, 128, 0},
  {96, 160, 0},
  {64, 192, 0},
  {32, 224, 0},
  {0, 255, 0},
  {0, 224, 32},
  {0, 192, 64},
  {0, 160, 96},
  {0, 128, 128},
  {0, 96, 160},
  {0, 64, 192},
  {0, 32, 224},
  {0, 0, 255},
  {32, 0, 224},
  {64, 0, 192},
  {96, 0, 160},
  {128, 0, 128},
  {160, 0, 96},
  {192, 0, 64},
  {224, 0, 32},
};


class Mode {
  Group grpMode;
  Textlabel tlTitle, tlLoading;
  DropdownList ddlAccMode, ddlAccSens;
  DropdownList[] ddlPattern = new DropdownList[2];
  Textfield tfPath;
  Button btnReload, btnWrite, btnSave, btnLoad;
  Button[] btnCycle = new Button[2];
  Button[] btnLess = new Button[2];
  Button[] btnMore = new Button[2];
  Button[][] btnColors = new Button[2][16];
  int accMode, accSens;
  int[] pattern = new int[2];
  int[] numColors = new int[2];
  int[][] colors = new int[2][16];

  Mode(float x, float y) {
    grpMode = cp5.addGroup("mode")
      .setPosition(x, y)
      .setBackgroundColor(color(192))
      .hideBar()
      .hideArrow();

    tlLoading = cp5.addTextlabel("loading")
      .setText("Loading data from light...")
      .setPosition(120, 100)
      .setColorValue(0xff8888ff)
      .setFont(createFont("Arial", 48))
      .hide();

    tlTitle = cp5.addTextlabel("title")
      .setText("Mode 0")
      .setPosition(330, 20)
      .setColorValue(0xff8888ff)
      .setFont(createFont("Arial", 32))
      .setGroup(grpMode);

    btnCycle[0] = cp5.addButton("prevMode")
      .setPosition(280, 30)
      .setSize(20, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("<<")
      .setGroup(grpMode);

    btnCycle[1] = cp5.addButton("nextMode")
      .setPosition(490, 30)
      .setSize(20, 20)
      .setColorBackground(color(64))
      .setCaptionLabel(">>")
      .setGroup(grpMode);

    for (int v = 0; v < 2; v++) {
      for (int s = 0; s < 16; s++) {
        btnColors[v][s] = cp5.addButton("color" + v + "_" + s)
          .setValue((v << 6) + s)
          .setPosition(84 + (s * 40), 100 + (v * 40))
          .setSize(32, 32)
          .setColorBackground(color(64))
          .setCaptionLabel("")
          .setGroup(grpMode);
      }
    }

    btnLess[0] = cp5.addButton("lessA")
      .setPosition(34, 104)
      .setSize(40, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Less")
      .setGroup(grpMode);

    btnLess[1] = cp5.addButton("lessB")
      .setPosition(34, 144)
      .setSize(40, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Less")
      .setGroup(grpMode);

    btnMore[0] = cp5.addButton("moreA")
      .setPosition(726, 104)
      .setSize(40, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("More")
      .setGroup(grpMode);

    btnMore[1] = cp5.addButton("moreB")
      .setPosition(726, 144)
      .setSize(40, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("More")
      .setGroup(grpMode);

    btnReload = cp5.addButton("reloadMode")
      .setPosition(110, 190)
      .setSize(80, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Reload Mode")
      .setGroup(grpMode);

    btnSave = cp5.addButton("writeMode")
      .setPosition(210, 190)
      .setSize(80, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Write Mode")
      .setGroup(grpMode);

    btnWrite = cp5.addButton("saveMode")
      .setPosition(640, 190)
      .setSize(30, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Save")
      .setGroup(grpMode);

    btnLoad = cp5.addButton("loadMode")
      .setPosition(680, 190)
      .setSize(30, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("Load")
      .setGroup(grpMode);

    tfPath = cp5.addTextfield("path")
      .setValue("")
      .setPosition(490, 190)
      .setSize(140, 20)
      .setColorBackground(color(64))
      .setCaptionLabel("")
      .setGroup(grpMode);

    ddlPattern[0] = buildPatternDropdown(0)
      .setPosition(70, 70)
      .setSize(150, 500)
      .setItemHeight(15)
      .setColorBackground(color(64))
      .setCaptionLabel("")
      .setGroup(grpMode);

    ddlAccMode = buildAccModeDropdown()
      .setPosition(240, 70)
      .setSize(150, 500)
      .setItemHeight(15)
      .setColorBackground(color(64))
      .setCaptionLabel("")
      .setGroup(grpMode);

    ddlAccSens = buildAccSensDropdown()
      .setPosition(410, 70)
      .setSize(150, 500)
      .setItemHeight(15)
      .setColorBackground(color(64))
      .setCaptionLabel("")
      .setGroup(grpMode);

    ddlPattern[1] = buildPatternDropdown(1)
      .setPosition(580, 70)
      .setSize(150, 500)
      .setItemHeight(15)
      .setColorBackground(color(64))
      .setCaptionLabel("")
      .setGroup(grpMode);
  }

  public void setLightIdx(int i) {
    grpMode.setCaptionLabel("Mode " + (1 + i));
    tlTitle.setText("Mode " + (1 + i));
    tfPath.setValue("mode" + (1 + i) + ".mde");
  }

  public void update(int addr, int val) {
    if (addr == 0) {
      setAccMode(val);
    } else if (addr == 1) {
      setAccSens(val);
    } else if (addr == 2) {
      setPattern(0, val);
    } else if (addr == 3) {
      setNumColors(0, val);
    } else if (addr < 20) {
      setColor(0, addr - 4, val);
    } else if (addr == 20) {
      setPattern(1, val);
    } else if (addr == 21) {
      setNumColors(1, val);
    } else if (addr < 38) {
      setColor(1, addr - 22, val);
    }
  }

  public void hide() {
    grpMode.hide();
    tlLoading.show();
  }

  public void show() {
    tlLoading.hide();
    grpMode.show();
  }

  public void setAccMode(int val) {
    ddlAccMode.setCaptionLabel(getAccModeName(val));
    accMode = val;
  }

  public void setAccSens(int val) {
    ddlAccSens.setCaptionLabel(getAccSensName(val));
    accSens = val;
  }

  public void setPattern(int var, int val) {
    ddlPattern[var].setCaptionLabel(getPatternName(var, val));
    pattern[var] = val;
  }

  public void setColor(int var, int slot, int val) {
    btnColors[var][slot].setColorBackground(getColor(val));
    colors[var][slot] = val;
    setNumColors(var, numColors[var]);
  }

  public void setNumColors(int var, int val) {
    if (val < 1) {
      return;
    }
    numColors[var] = val;
    if (val == 1) {
      btnLess[var].hide();
      btnMore[var].show();
    } else if (val == 16) {
      btnLess[var].show();
      btnMore[var].hide();
    } else {
      btnLess[var].show();
      btnMore[var].show();
    }
    for (int i = 0; i < 16; i++) {
      if (i < val) {
        btnColors[var][i].setCaptionLabel("");
      } else {
        btnColors[var][i].setCaptionLabel("off").setColorBackground(0);
      }
    }
  }
}


public int getColor(int v) {
  int shade = v >> 6;
  int alpha = 63 + (192 >> shade);
  return (alpha << 24) + (palette[v % 32][0] << 16) + (palette[v % 32][1] << 8) + palette[v % 32][2];
}

public DropdownList buildAccSensDropdown() {
  DropdownList dd = cp5.addDropdownList("accSens");
  dd.setBackgroundColor(color(0));
  dd.setItemHeight(20);
  dd.setBarHeight(15);
  for (int j = 0; j < 3; j++) {
    dd.addItem(getAccSensName(j), j);
  }
  dd.setColorBackground(color(60));
  dd.setColorActive(color(255, 128));
  dd.close();
  return dd;
}

public DropdownList buildAccModeDropdown() {
  DropdownList dd = cp5.addDropdownList("accMode");
  dd.setBackgroundColor(color(200));
  dd.setItemHeight(20);
  dd.setBarHeight(15);
  for (int j = 0; j < 5; j++) {
    dd.addItem(getAccModeName(j), j);
  }
  dd.setColorBackground(color(60));
  dd.setColorActive(color(255, 128));
  dd.close();
  return dd;
}

public DropdownList buildPatternDropdown(int var) {
  DropdownList dd = cp5.addDropdownList("pattern" + var);
  dd.setBackgroundColor(color(200));
  dd.setItemHeight(20);
  dd.setBarHeight(15);
  for (int j = 0; j < 48; j++) {
    dd.addItem(getPatternName(var, j), j);
  }
  dd.setColorBackground(color(60));
  dd.setColorActive(color(255, 128));
  dd.close();
  return dd;
}

public String getPatternName(int var, int val) {
  if (val == 0) {
    return "PATTERN " + (var + 1) + ": STROBE FAST";
  } else if (val == 1) {
    return "PATTERN " + (var + 1) + ": STROBE";
  } else if (val == 2) {
    return "PATTERN " + (var + 1) + ": STROBE SLOW";
  } else if (val == 3) {
    return "PATTERN " + (var + 1) + ": NANODOPS";
  } else if (val == 4) {
    return "PATTERN " + (var + 1) + ": DOPS";
  } else if (val == 5) {
    return "PATTERN " + (var + 1) + ": STROBIE";
  } else if (val == 6) {
    return "PATTERN " + (var + 1) + ": SEIZURE";
  } else if (val == 7) {
    return "PATTERN " + (var + 1) + ": ULTRA";
  } else if (val == 8) {
    return "PATTERN " + (var + 1) + ": HYPER";
  } else if (val == 9) {
    return "PATTERN " + (var + 1) + ": MEGA";
  } else if (val == 10) {
    return "PATTERN " + (var + 1) + ": PULSE STROBE";
  } else if (val == 11) {
    return "PATTERN " + (var + 1) + ": PULSE FAST";
  } else if (val ==12) { 
    return "PATTERN " + (var + 1) + ": PULSE";
  } else if (val == 13) {
    return "PATTERN " + (var + 1) + ": PULSE SLOW";
  } else if (val == 14) {
    return "PATTERN " + (var + 1) + ": LAZER";
  } else if (val == 15) {
    return "PATTERN " + (var + 1) + ": TRACER";
  } else if (val == 16) {
    return "PATTERN " + (var + 1) + ": TAZER";
  } else if (val == 17) {
    return "PATTERN " + (var + 1) + ": DASHDOPS2";
  } else if (val == 18) {
    return "PATTERN " + (var + 1) + ": DASHDOPS7";
  } else if (val == 19) {
    return "PATTERN " + (var + 1) + ": DASHSTROBE";
  } else if (val == 20) {
    return "PATTERN " + (var + 1) + ": DASHDASH";
  } else if (val == 21) {
    return "PATTERN " + (var + 1) + ": QUICKE";
  } else if (val == 22) {
    return "PATTERN " + (var + 1) + ": BLINKE";
  } else if (val == 23) {
    return "PATTERN " + (var + 1) + ": STRIBBON";
  } else if (val == 24) {
    return "PATTERN " + (var + 1) + ": RAZOR";
  } else if (val == 25) { 
    return "PATTERN " + (var + 1) + ": EDGE";
  } else if (val == 26) {
    return "PATTERN " + (var + 1) + ": SWORD";
  } else if (val == 27) {
    return "PATTERN " + (var + 1) + ": BARBWIRE";
  } else if (val == 28) {
    return "PATTERN " + (var + 1) + ": LEGO MINI";
  } else if (val == 29) {
    return "PATTERN " + (var + 1) + ": LEGO";
  } else if (val == 30) {
    return "PATTERN " + (var + 1) + ": LEGO HUGE";
  } else if (val == 31) {
    return "PATTERN " + (var + 1) + ": CHASE SHORT";
  } else if (val == 32) {
    return "PATTERN " + (var + 1) + ": CHASE";
  } else if (val == 33) {
    return "PATTERN " + (var + 1) + ": CHASE LONG";
  } else if (val == 34) {
    return "PATTERN " + (var + 1) + ": MORPH";
  } else if (val == 35) {
    return "PATTERN " + (var + 1) + ": MORPH SLOW";
  } else if (val == 36) {
    return "PATTERN " + (var + 1) + ": MORPH STROBE";
  } else if (val == 37) {
    return "PATTERN " + (var + 1) + ": MORPH HYPER";
  } else if (val == 38) {
    return "PATTERN " + (var + 1) + ": RIBBON5";
  } else if (val == 39) {
    return "PATTERN " + (var + 1) + ": RIBBON10";
  } else if (val == 40) {
    return "PATTERN " + (var + 1) + ": RIBBON20";
  } else if (val == 41) {
    return "PATTERN " + (var + 1) + ": COMET SHORT";
  } else if (val == 42) {
    return "PATTERN " + (var + 1) + ": COMET";
  } else if (val == 43) {
    return "PATTERN " + (var + 1) + ": COMET LONG";
  } else if (val == 44) {
    return "PATTERN " + (var + 1) + ": CANDY2";
  } else if (val == 45) {
    return "PATTERN " + (var + 1) + ": CANDY3";
  } else if (val == 46) {
    return "PATTERN " + (var + 1) + ": CANDOPS";
  } else if (val == 47) {
    return "PATTERN " + (var + 1) + ": CANDYCRUSH";
  }
  return "";
}

public String getAccSensName(int val) {
  if (val == 0) {
    return "ACCEL SENSITIVITY: LOW";
  } else if (val == 1) {
    return "ACCEL SENSITIVITY: MEDIUM";
  } else if (val == 2) {
    return "ACCEL SENSITIVITY: HIGH";
  }
  return "";
}

public String getAccModeName(int val) {
  if (val == 0) {
    return "ACCEL MODE: OFF";
  } else if (val == 1) {
    return "ACCEL MODE: SPEED";
  } else if (val == 2) {
    return "ACCEL MODE: TILT X";
  } else if (val == 3) {
    return "ACCEL MODE: TILT Y";
  } else if (val == 4) {
    return "ACCEL MODE: FLIP Z";
  }
  return "";
}
  public void settings() {  size(800, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "tekton" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
