import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.event.KeyEvent; 
import processing.serial.*; 
import controlP5.*; 
import java.util.ArrayList; 
import java.util.Map; 
import java.util.ArrayList; 
import java.util.logging.Level; 
import processing.core.PApplet; 
import processing.core.PGraphics; 
import processing.core.PVector; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class vectrui extends PApplet {





static final int SER_DUMP       = 10;
static final int SER_SAVE       = 20;
static final int SER_READ       = 30;
static final int SER_WRITE      = 40;
static final int SER_MODE_SET   = 90;
static final int SER_VIEW_MODE  = 100;
static final int SER_VIEW_COLOR = 101;
static final int SER_HANDSHAKE  = 250;
static final int SER_DISCONNECT = 251;

Serial port;
ControlP5 cp5;

int gui_state = 0;
Boolean initialized = false;
Boolean reading = false;

int cur_mode = 0;
Mode[] modes = new Mode[7];

Editor editor;
int counter = 0;
boolean view_mode = true;


public void printColor(int c) {
  int r = (c & 0xff0000) >> 16;
  int g = (c & 0x00ff00) >> 8;
  int b = (c & 0x0000ff) >> 0;
  println(r + ", " + g + ", " + b);
}

public void setup() {
  surface.setTitle("VectrUI");
  
  cp5 = new ControlP5(this);
  /* cp5.setFont(createFont("Verdana", 10)); */
  cp5.setFont(createFont("Arial-Black", 11));

  editor = new Editor(0, 0);

  for (int i = 0; i < 7; i++) {
    modes[i] = new Mode();
  }
}

public void connectLight() {
  for (String p: Serial.list()) {
    try {
      port = new Serial(this, p, 115200);
    } catch (Exception e) {
    }
  }
}

public void draw() {
  background(192);
  if (!initialized) {
    connectLight();
  }

  while (port.available() >= 3) {
    readCommand();
  }

  if (!initialized || reading) {
    editor.group.hide();
  } else {
    editor.group.show();
  }
}

public void readCommand() {
  int target = port.read();
  int addr = port.read();
  int val = port.read();

  if (target == SER_HANDSHAKE) {        // Light wants to connect
    if (addr == 100 && val == 100) {
      initialized = true;
      reading = true;
      sendCommand(SER_HANDSHAKE, 100, 13, 13);
    }
  } else if (target == 251) { // Light acked handshake
    cur_mode = addr;
    sendCommand(SER_DUMP, 200, 0, 0);
  } else if (target == 200) { // Start of a dump
    // addr is the mode about to be dumped, val is the current mode
    reading = true;
  } else if (target == 210) { // End of a dump
    // addr is the mode just dumped, val is the current mode
    cur_mode = val;
    editor.curModeChanged(cur_mode);
    reading = false;
  } else if (target < 7) {    // Data on a mode
    modes[target].seta(addr, val);
  }
}

public void sendCommand(int cmd, int target, int addr, int val) {
  /* println("cmd: " + cmd + " " + target + " " + addr + " " + val); */
  if (cmd == SER_WRITE) {
    if (target == 100) {
      modes[cur_mode].seta(addr, val);
    } else if (target < 7) {
      modes[target].seta(addr, val);
    }
  }

  if (initialized) {
    port.write(cmd);
    port.write(target);
    port.write(addr);
    port.write(val);
  }
}

public void controlEvent(CallbackEvent theEvent) {
  Controller eController = theEvent.getController();
  String eName = eController.getName();
  float eVal = eController.getValue();
  int eId = eController.getId();
  int eAction = theEvent.getAction();

  if (eController.equals(editor.patternThresh)) {
    if (eAction == ControlP5.ACTION_RELEASED || eAction == ControlP5.ACTION_RELEASEDOUTSIDE) {
      sendCommand(SER_WRITE, 100, 4, (int)editor.patternThresh.getMinA());
      sendCommand(SER_WRITE, 100, 5, (int)editor.patternThresh.getMaxA());
      sendCommand(SER_WRITE, 100, 6, (int)editor.patternThresh.getMinB());
      sendCommand(SER_WRITE, 100, 7, (int)editor.patternThresh.getMaxB());
    }
  } else if (eController.equals(editor.colorThresh)) {
    if (eAction == ControlP5.ACTION_RELEASED || eAction == ControlP5.ACTION_RELEASEDOUTSIDE) {
      sendCommand(SER_WRITE, 100, 8, (int)editor.colorThresh.getMinA());
      sendCommand(SER_WRITE, 100, 9, (int)editor.colorThresh.getMaxA());
      sendCommand(SER_WRITE, 100, 10, (int)editor.colorThresh.getMinB());
      sendCommand(SER_WRITE, 100, 11, (int)editor.colorThresh.getMaxB());
    }
  } else if (eController.equals(editor.base)) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      sendPatternChange((int)eVal);
      editor.patternChanged((int)eVal);
      editor.curModeChanged(cur_mode);
    } else if (theEvent.getAction() == ControlP5.ACTION_LEAVE) {
      editor.base.close();
    }
  } else if (eController.equals(editor.prevMode)) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      view_mode = true;
      editor.viewMode.setColorBackground(color(0, 90, 180));
      editor.viewColor.setColorBackground(color(0, 45, 90));
      sendCommand(SER_VIEW_MODE, 0, 0, 0);
      sendCommand(SER_MODE_SET, 99, 0, 0);
    }
  } else if (eController.equals(editor.nextMode)) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      view_mode = true;
      editor.viewMode.setColorBackground(color(0, 90, 180));
      editor.viewColor.setColorBackground(color(0, 45, 90));
      sendCommand(SER_VIEW_MODE, 0, 0, 0);
      sendCommand(SER_MODE_SET, 101, 0, 0);
    }
  } else if (eController.equals(editor.saveMode)) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      saveJSONObject(modes[cur_mode].asJSON(), editor.modeFilename.getText(), "compact");
    }
  } else if (eController.equals(editor.loadMode)) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      modes[cur_mode].fromJSON(loadJSONObject(editor.modeFilename.getText()));
      sendMode(100);
      editor.curModeChanged(cur_mode);
    }
  } else if (eController.equals(editor.writeMode)) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      sendCommand(SER_SAVE, 0, 0, 0);
    }
  } else if (eController.equals(editor.resetMode)) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      sendCommand(SER_MODE_SET, cur_mode, 0, 0);
    }
  } else if (eController.equals(editor.saveLight)) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      JSONArray jarr = new JSONArray();
      for (int i = 0; i < 7; i++) {
        jarr.setJSONObject(i, modes[i].asJSON());
      }
      saveJSONArray(jarr, editor.lightFilename.getText(), "compact");
    }
  } else if (eController.equals(editor.writeLight)) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      JSONArray jarr = loadJSONArray(editor.lightFilename.getText());
      for (int i = 0; i < 7; i++) {
        modes[i].fromJSON(jarr.getJSONObject(i));
        sendMode(i);
      }
      editor.curModeChanged(cur_mode);
    }
  } else if (eController.equals(editor.disconnectLight)) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      sendCommand(SER_DISCONNECT, 0, 0, 0);
      initialized = false;
    }
  } else if (eController.equals(editor.viewMode)) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      if (!view_mode) {
        sendCommand(SER_VIEW_MODE, 0, 0, 0);
        view_mode = true;
        editor.viewMode.setColorBackground(color(0, 90, 180));
        editor.viewColor.setColorBackground(color(0, 45, 90));
      }
    }
  } else if (eController.equals(editor.viewColor)) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      if (view_mode) {
        sendCommand(SER_VIEW_COLOR, editor.color_set, editor.color_slot, 0);
        view_mode = false;
        editor.viewMode.setColorBackground(color(0, 45, 90));
        editor.viewColor.setColorBackground(color(0, 90, 180));
      }
    }
  } else if (eName.startsWith("editorArgs")) {
    if (theEvent.getAction() == ControlP5.ACTION_RELEASED ||
        theEvent.getAction() == ControlP5.ACTION_RELEASEDOUTSIDE) {
      sendCommand(SER_WRITE, 100, eId, (int)eVal);
    }
  } else if (eName.startsWith("editorTimings")) {
    if (theEvent.getAction() == ControlP5.ACTION_RELEASED ||
        theEvent.getAction() == ControlP5.ACTION_RELEASEDOUTSIDE) {
      sendCommand(SER_WRITE, 100, eId, (int)eVal);
    }
  } else if (eName.startsWith("editorNumColors")) {
    if (theEvent.getAction() == ControlP5.ACTION_RELEASED ||
        theEvent.getAction() == ControlP5.ACTION_RELEASEDOUTSIDE) {
      sendCommand(SER_WRITE, 100, eId, (int)eVal);
      editor.numColorsChanged(eId - 1, (int)eVal);
    } else if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      editor.numColorsChanged(eId - 1, (int)eVal);
    }
  } else if (eId == 1000) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      editor.selectColor(eVal);
      if (!view_mode) {
        sendCommand(SER_VIEW_COLOR, editor.color_set, editor.color_slot, 0);
      }
    }
  } else if (eName.startsWith("editorColorValues")) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      if (editor.color_set >= 0 && editor.color_slot >= 0) {
        sendCommand(SER_WRITE, 100, 39 + (editor.color_slot * 9) + (editor.color_set * 3) + (eId - 500), (int)eVal);
        editor.seta(39 + (editor.color_slot * 9) + (editor.color_set * 3) + (eId - 500), (int)eVal);
      }
    }
  } else if (eId >= 2000 && eId < 2100) {
    if (theEvent.getAction() == ControlP5.ACTION_BROADCAST) {
      if (editor.color_set >= 0 && editor.color_slot >= 0) {
        sendCommand(SER_WRITE, 100, 39 + (editor.color_slot * 9) + (editor.color_set * 3), color_bank[eId - 2000][0]);
        sendCommand(SER_WRITE, 100, 40 + (editor.color_slot * 9) + (editor.color_set * 3), color_bank[eId - 2000][1]);
        sendCommand(SER_WRITE, 100, 41 + (editor.color_slot * 9) + (editor.color_set * 3), color_bank[eId - 2000][2]);
        editor.seta(39 + (editor.color_slot * 9) + (editor.color_set * 3), color_bank[eId - 2000][0]);
        editor.seta(40 + (editor.color_slot * 9) + (editor.color_set * 3), color_bank[eId - 2000][1]);
        editor.seta(41 + (editor.color_slot * 9) + (editor.color_set * 3), color_bank[eId - 2000][2]);
        editor.selectColor(editor.color_set, editor.color_slot);
      }
    }
  }
}

public void sendMode(int m) {
  int mode = (m == 100) ? cur_mode : m;
  sendCommand(SER_WRITE, m, 0, modes[mode].pattern);
  for (int i = 0; i < 3; i++) {
    sendCommand(SER_WRITE, m, i + 1, modes[mode].numColors[i]);
  }
  for (int i = 0; i < 4; i++) {
    sendCommand(SER_WRITE, m, i + 4, modes[mode].patternThresh[i / 2][i % 2]);
  }
  for (int i = 0; i < 4; i++) {
    sendCommand(SER_WRITE, m, i + 8, modes[mode].colorThresh[i / 2][i % 2]);
  }
  for (int i = 0; i < 9; i++) {
    sendCommand(SER_WRITE, m, i + 12, modes[mode].args[i / 3][i % 3]);
  }
  for (int i = 0; i < 18; i++) {
    sendCommand(SER_WRITE, m, i + 21, modes[mode].timings[i / 6][i % 6]);
  }
  for (int i = 0; i < 81; i++) {
    sendCommand(SER_WRITE, m, i + 39, modes[mode].colors[i / 9][(i % 9) / 3][i % 3]);
  }
}

public void sendPatternChange(int v) {
  sendCommand(SER_WRITE, 100, 0, v);
  // Set all args to 0
  for (int i = 0; i < 9; i++) { sendCommand(SER_WRITE, 100, 12 + i, 0); }

  if (v == 0) { // Strobe
    sendCommand(SER_WRITE, 100, 21, 9);
    sendCommand(SER_WRITE, 100, 22, 41);
    sendCommand(SER_WRITE, 100, 23, 0);
    sendCommand(SER_WRITE, 100, 24, 0);
    sendCommand(SER_WRITE, 100, 25, 0);
    sendCommand(SER_WRITE, 100, 26, 0);

    sendCommand(SER_WRITE, 100, 27, 25);
    sendCommand(SER_WRITE, 100, 28, 25);
    sendCommand(SER_WRITE, 100, 29, 0);
    sendCommand(SER_WRITE, 100, 30, 0);
    sendCommand(SER_WRITE, 100, 31, 0);
    sendCommand(SER_WRITE, 100, 32, 0);

    sendCommand(SER_WRITE, 100, 33, 3);
    sendCommand(SER_WRITE, 100, 34, 22);
    sendCommand(SER_WRITE, 100, 35, 0);
    sendCommand(SER_WRITE, 100, 36, 0);
    sendCommand(SER_WRITE, 100, 37, 0);
    sendCommand(SER_WRITE, 100, 38, 0);
  } else if (v == 1) { // Vexer
    sendCommand(SER_WRITE, 100, 21, 9);
    sendCommand(SER_WRITE, 100, 22, 0);
    sendCommand(SER_WRITE, 100, 23, 41);
    sendCommand(SER_WRITE, 100, 24, 0);
    sendCommand(SER_WRITE, 100, 25, 0);
    sendCommand(SER_WRITE, 100, 26, 0);

    sendCommand(SER_WRITE, 100, 27, 5);
    sendCommand(SER_WRITE, 100, 28, 0);
    sendCommand(SER_WRITE, 100, 29, 45);
    sendCommand(SER_WRITE, 100, 30, 0);
    sendCommand(SER_WRITE, 100, 31, 0);
    sendCommand(SER_WRITE, 100, 32, 0);

    sendCommand(SER_WRITE, 100, 33, 3);
    sendCommand(SER_WRITE, 100, 34, 0);
    sendCommand(SER_WRITE, 100, 35, 47);
    sendCommand(SER_WRITE, 100, 36, 0);
    sendCommand(SER_WRITE, 100, 37, 0);
    sendCommand(SER_WRITE, 100, 38, 0);
  } else if (v == 2) { // Edge
    sendCommand(SER_WRITE, 100, 21, 3);
    sendCommand(SER_WRITE, 100, 22, 0);
    sendCommand(SER_WRITE, 100, 23, 8);
    sendCommand(SER_WRITE, 100, 24, 50);
    sendCommand(SER_WRITE, 100, 25, 0);
    sendCommand(SER_WRITE, 100, 26, 0);

    sendCommand(SER_WRITE, 100, 27, 2);
    sendCommand(SER_WRITE, 100, 28, 0);
    sendCommand(SER_WRITE, 100, 29, 8);
    sendCommand(SER_WRITE, 100, 30, 50);
    sendCommand(SER_WRITE, 100, 31, 0);
    sendCommand(SER_WRITE, 100, 32, 0);

    sendCommand(SER_WRITE, 100, 33, 1);
    sendCommand(SER_WRITE, 100, 34, 0);
    sendCommand(SER_WRITE, 100, 35, 8);
    sendCommand(SER_WRITE, 100, 36, 50);
    sendCommand(SER_WRITE, 100, 37, 0);
    sendCommand(SER_WRITE, 100, 38, 0);
  } else if (v == 3) { // Double
    sendCommand(SER_WRITE, 100, 21, 9);
    sendCommand(SER_WRITE, 100, 22, 41);
    sendCommand(SER_WRITE, 100, 23, 41);
    sendCommand(SER_WRITE, 100, 24, 9);
    sendCommand(SER_WRITE, 100, 25, 0);
    sendCommand(SER_WRITE, 100, 26, 0);

    sendCommand(SER_WRITE, 100, 27, 25);
    sendCommand(SER_WRITE, 100, 28, 25);
    sendCommand(SER_WRITE, 100, 29, 25);
    sendCommand(SER_WRITE, 100, 30, 25);
    sendCommand(SER_WRITE, 100, 31, 0);
    sendCommand(SER_WRITE, 100, 32, 0);

    sendCommand(SER_WRITE, 100, 33, 3);
    sendCommand(SER_WRITE, 100, 34, 22);
    sendCommand(SER_WRITE, 100, 35, 3);
    sendCommand(SER_WRITE, 100, 36, 22);
    sendCommand(SER_WRITE, 100, 37, 0);
    sendCommand(SER_WRITE, 100, 38, 0);
  } else if (v == 4) { // Runner
    sendCommand(SER_WRITE, 100, 21, 3);
    sendCommand(SER_WRITE, 100, 22, 22);
    sendCommand(SER_WRITE, 100, 23, 3);
    sendCommand(SER_WRITE, 100, 24, 22);
    sendCommand(SER_WRITE, 100, 25, 25);
    sendCommand(SER_WRITE, 100, 26, 0);

    sendCommand(SER_WRITE, 100, 27, 25);
    sendCommand(SER_WRITE, 100, 28, 25);
    sendCommand(SER_WRITE, 100, 29, 3);
    sendCommand(SER_WRITE, 100, 30, 22);
    sendCommand(SER_WRITE, 100, 31, 25);
    sendCommand(SER_WRITE, 100, 32, 0);

    sendCommand(SER_WRITE, 100, 33, 3);
    sendCommand(SER_WRITE, 100, 34, 22);
    sendCommand(SER_WRITE, 100, 35, 25);
    sendCommand(SER_WRITE, 100, 36, 25);
    sendCommand(SER_WRITE, 100, 37, 25);
    sendCommand(SER_WRITE, 100, 38, 0);
  }
}



final static String[] PATTERNS = {"Strobe", "Vexer", "Edge", "Double", "Runner"};
final static int color_bank[][] = {
  {0, 0, 0},
  {56, 64, 72},
  {24, 0, 0},
  {16, 16, 0},
  {0, 24, 0},
  {0, 16, 16},
  {0, 0, 24},
  {16, 0, 16},
  {255, 0, 0},
  {224, 32, 0},
  {192, 64, 0},
  {160, 96, 0},
  {128, 128, 0},
  {96, 160, 0},
  {64, 192, 0},
  {32, 224, 0},
  {0, 255, 0},
  {0, 224, 32},
  {0, 192, 64},
  {0, 160, 96},
  {0, 128, 128},
  {0, 96, 160},
  {0, 64, 192},
  {0, 32, 224},
  {0, 0, 255},
  {32, 0, 224},
  {64, 0, 192},
  {96, 0, 160},
  {128, 0, 128},
  {160, 0, 96},
  {192, 0, 64},
  {224, 0, 32},
  {64, 64, 64},
  {160, 16, 16},
  {16, 160, 16},
  {16, 16, 160},
  {128, 8, 48},
  {80, 48, 48},
  {128, 48, 8},
  {80, 80, 8},
  {48, 128, 8},
  {48, 80, 48},
  {8, 128, 48},
  {8, 80, 80},
  {8, 48, 128},
  {48, 48, 80},
  {48, 8, 128},
  {80, 8, 80},
};


class Editor {
  // GUI
  Group group;
  Textlabel title;
  Button nextMode;
  Button prevMode;
  DropdownList base;
  ThreshRange patternThresh;
  ThreshRange colorThresh;

  Textlabel[] argLabels = new Textlabel[3];
  Slider[][] args = new Slider[3][3];

  Textlabel[] timingLabels = new Textlabel[6];
  Slider[][] timings = new Slider[3][6];

  Textlabel[] colorLabels = new Textlabel[3];
  Slider[] numColors = new Slider[3];
  Button[][] colors = new Button[3][9];
  Button colorSelect;
  int color_set = -1;
  int color_slot = -1;

  Slider[] colorValues = new Slider[3];
  Button[] colorButtons = new Button[48];

  Button saveMode;
  Button loadMode;
  Textfield modeFilename;
  Button writeMode;
  Button resetMode;
  Button saveLight;
  Button writeLight;
  Textfield lightFilename;
  Button disconnectLight;
  Button viewMode;
  Button viewColor;

  Editor(int x, int y) {
    group = cp5.addGroup("editor")
      .setPosition(x, y)
      .setWidth(1000)
      .setHeight(800)
      .hideBar()
      .hideArrow();

    title = cp5.addTextlabel("editorTitle")
      .setGroup(group)
      .setValue("Mode 1")
      .setFont(createFont("Arial", 32))
      .setPosition(440, 5)
      .setColorValue(color(0));

    patternThresh = new ThreshRange(cp5, "editorPatternThresh")
      .setBroadcast(false)
      .setGroup(group)
      .setLabel("Pattern Thresholds")
      .setBroadcast(true);
    patternThresh.setPosition((group.getWidth() - patternThresh.getWidth()) / 2, 90);
    style("editorPatternThresh");

    colorThresh = new ThreshRange(cp5, "editorColorThresh")
      .setBroadcast(false)
      .setGroup(group)
      .setLabel("Color Set Thresholds")
      .setBroadcast(true);
    colorThresh.setPosition((group.getWidth() - colorThresh.getWidth()) / 2, 500);
    style("editorColorThresh");

    colorSelect = cp5.addButton("editorColorSelect")
      .setGroup(group)
      .setSize(40, 40)
      .setPosition(0, 0)
      .setCaptionLabel("")
      .setColorBackground(color(255))
      .hide();

    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        args[i][j] = cp5.addSlider("editorArgs" + i + "." + j)
          .setBroadcast(false)
          .setCaptionLabel("")
          .setGroup(group)
          .setId(12 + (3 * j) + i)
          .setSize(250, 20)
          .setPosition(125 + (i * 275), 160 + (j * 30))
          .setColorBackground(color(32))
          .setColorActive(color(96))
          .setRange(0, 9)
          .setNumberOfTickMarks(10)
          .showTickMarks(false)
          .setDecimalPrecision(0)
          .setValue(0)
          .setBroadcast(true)
          .hide();

      }

      for (int j = 0; j < 6; j++) {
        timings[i][j] = cp5.addSlider("editorTimings" + i + "." + j)
          .setBroadcast(false)
          .setCaptionLabel("")
          .setGroup(group)
          .setId(21 + (6 * i) + j)
          .setSize(250, 20)
          .setPosition(125 + (i * 275), 280 + (j * 30))
          .setColorBackground(color(32))
          .setColorActive(color(96))
          .setRange(0, 250)
          .setNumberOfTickMarks(251)
          .showTickMarks(false)
          .setDecimalPrecision(0)
          .setValue(0)
          .setBroadcast(true)
          .hide();
      }

      for (int j = 0; j < 9; j++) {
        colors[i][j] = cp5.addButton("editorColor" + i + "." + j, (i * 9) + j)
          .setId(1000)
          .setGroup(group)
          .setSize(32, 32)
          .setPosition(284 + (40 * j), 554 + (50 * i))
          .setCaptionLabel("")
          .setColorBackground(color(0));
      }

      colorLabels[i] = cp5.addTextlabel("editorColorLabels" + i)
        .setGroup(group)
        .setValue("Color Set " + (i + 1))
        .setPosition(30, 562 + (i * 50))
        .setColorValue(color(0));

      numColors[i] = cp5.addSlider("editorNumColors" + i)
        .setBroadcast(false)
        .setCaptionLabel("")
        .setGroup(group)
        .setId(1 + i)
        .setSize(150, 20)
        .setPosition(110, 560 + (i * 50))
        .setColorBackground(color(32))
        .setColorActive(color(96))
        .setRange(1, 9)
        .setNumberOfTickMarks(9)
        .showTickMarks(false)
        .setDecimalPrecision(0)
        .setBroadcast(true);
      style("editorNumColors" + i);
    }

    for (int i = 0; i < 3; i++) {
      argLabels[i] = cp5.addTextlabel("editorArgLabels" + i)
        .setGroup(group)
        .setValue("Arg")
        .setPosition(30, 162 + (i * 30))
        .setColorValue(color(0))
        .hide();
    }

    for (int i = 0; i < 6; i++) {
      timingLabels[i] = cp5.addTextlabel("editorTimingLabels" + i)
        .setGroup(group)
        .setValue("Timing")
        .setPosition(30, 282 + (i * 30))
        .setColorValue(color(0))
        .hide();
    }

    colorValues[0] = cp5.addSlider("editorColorValuesR")
      .setBroadcast(false)
      .setCaptionLabel("")
      .setGroup(group)
      .setId(500)
      .setSize(256, 20)
      .setPosition(660, 560)
      .setColorBackground(color(96, 0, 0))
      .setColorForeground(color(192, 0, 0))
      .setColorActive(color(255, 0, 0))
      .setRange(0, 255)
      .setNumberOfTickMarks(256)
      .showTickMarks(false)
      .setDecimalPrecision(0)
      .setValue(0)
      .setBroadcast(true);

    colorValues[1] = cp5.addSlider("editorColorValuesG")
      .setBroadcast(false)
      .setCaptionLabel("")
      .setGroup(group)
      .setId(501)
      .setSize(256, 20)
      .setPosition(660, 590)
      .setColorBackground(color(0, 96, 0))
      .setColorForeground(color(0, 192, 0))
      .setColorActive(color(0, 255, 0))
      .setRange(0, 255)
      .setNumberOfTickMarks(256)
      .showTickMarks(false)
      .setDecimalPrecision(0)
      .setValue(0)
      .setBroadcast(true);

    colorValues[2] = cp5.addSlider("editorColorValuesB")
      .setBroadcast(false)
      .setCaptionLabel("")
      .setGroup(group)
      .setId(502)
      .setSize(256, 20)
      .setPosition(660, 620)
      .setColorBackground(color(0, 0, 96))
      .setColorForeground(color(0, 0, 192))
      .setColorActive(color(0, 0, 255))
      .setRange(0, 255)
      .setNumberOfTickMarks(256)
      .showTickMarks(false)
      .setDecimalPrecision(0)
      .setValue(0)
      .setBroadcast(true);

    for (int i = 0; i < 48; i++) {
        colorButtons[i] = cp5.addButton("editorColorBank" + i)
          .setId(2000 + i)
          .setGroup(group)
          .setSize(16, 16)
          .setPosition(22 + (20 * i), 702)
          .setCaptionLabel("")
          .setColorActive(translateColor(i))
          .setColorForeground(translateColor(i))
          .setColorBackground(translateColor(i));
    }

    base = cp5.addDropdownList("editorBase")
      .setGroup(group)
      .setLabel("Base Pattern")
      .setPosition(450, 50)
      .setSize(100, 120)
      .setItems(PATTERNS)
      .setItemHeight(20)
      .setBarHeight(20);
    base.getCaptionLabel().toUpperCase(false);
    base.getValueLabel().toUpperCase(false);
    base.getCaptionLabel().getStyle().setPadding(4,4,4,4);
    base.getValueLabel().getStyle().setPadding(4,4,4,4);
    base.close();

    prevMode = cp5.addButton("editorPrevMode")
      .setCaptionLabel("<< Prev")
      .setGroup(group)
      .setSize(60, 20)
      .setPosition(340, 15);
    prevMode.getCaptionLabel().toUpperCase(false);

    nextMode = cp5.addButton("editorNextMode")
      .setCaptionLabel("Next >>")
      .setGroup(group)
      .setSize(60, 20)
      .setPosition(600, 15);
    nextMode.getCaptionLabel().toUpperCase(false);

    resetMode = cp5.addButton("editorResetMode")
      .setCaptionLabel("Reset Mode")
      .setGroup(group)
      .setSize(100, 20)
      .setPosition(30, 730);
    resetMode.getCaptionLabel().toUpperCase(false);

    saveMode = cp5.addButton("editorSaveMode")
      .setCaptionLabel("Save Mode")
      .setGroup(group)
      .setSize(100, 20)
      .setPosition(150, 730);
    saveMode.getCaptionLabel().toUpperCase(false);

    loadMode = cp5.addButton("editorLoadMode")
      .setCaptionLabel("Load Mode")
      .setGroup(group)
      .setSize(100, 20)
      .setPosition(270, 730);
    loadMode.getCaptionLabel().toUpperCase(false);

    writeMode = cp5.addButton("editorWriteMode")
      .setCaptionLabel("Write Mode")
      .setGroup(group)
      .setSize(100, 20)
      .setPosition(390, 730);
    writeMode.getCaptionLabel().toUpperCase(false);

    /* resetLight = cp5.addButton("editorResetLight") */
    /*   .setCaptionLabel("Reset Light") */
    /*   .setGroup(group) */
    /*   .setSize(100, 20) */
    /*   .setPosition(510, 730); */
    /* resetLight.getCaptionLabel().toUpperCase(false); */

    /* saveLight = cp5.addButton("editorSaveLight") */
    /*   .setCaptionLabel("Save Light") */
    /*   .setGroup(group) */
    /*   .setSize(100, 20) */
    /*   .setPosition(630, 730); */
    /* saveLight.getCaptionLabel().toUpperCase(false); */

    /* writeLight = cp5.addButton("editorWriteLight") */
    /*   .setCaptionLabel("Write Light") */
    /*   .setGroup(group) */
    /*   .setSize(100, 20) */
    /*   .setPosition(750, 730); */
    /* writeLight.getCaptionLabel().toUpperCase(false); */

    disconnectLight = cp5.addButton("editorDisconnectLight")
      .setCaptionLabel("Disconnect")
      .setGroup(group)
      .setSize(100, 20)
      .setPosition(870, 730);
    disconnectLight.getCaptionLabel().toUpperCase(false);

    modeFilename = cp5.addTextfield("editorModeFilename")
      .setGroup(group)
      .setCaptionLabel("")
      .setColorBackground(color(0))
      .setPosition(150, 760)
      .setSize(220, 20)
      .setText("vectr.mode")
      .setAutoClear(false);
    modeFilename.getValueLabel().getStyle().setPadding(0, 0, 0, 4);

    /* lightFilename = cp5.addTextfield("editorLightFilename") */
    /*   .setGroup(group) */
    /*   .setCaptionLabel("") */
    /*   .setColorBackground(color(0)) */
    /*   .setPosition(630, 760) */
    /*   .setSize(220, 20) */
    /*   .setText("vectr.light") */
    /*   .setAutoClear(false); */
    /* lightFilename.getValueLabel().getStyle().setPadding(0, 0, 0, 4); */

    viewMode = cp5.addButton("editorViewMode")
      .setCaptionLabel("View Mode")
      .setGroup(group)
      .setColorBackground(color(0, 90, 180))
      .setSize(100, 20)
      .setPosition(678, 660);
    viewMode.getCaptionLabel().toUpperCase(false);

    viewColor = cp5.addButton("editorViewColor")
      .setCaptionLabel("View Color")
      .setGroup(group)
      .setColorBackground(color(0, 45, 90))
      .setSize(100, 20)
      .setPosition(798, 660)
      .hide();
    viewColor.getCaptionLabel().toUpperCase(false);
  }

  public void curModeChanged(int m) {
    title.setText("Mode " + (m + 1));
    seta(0, modes[m].pattern);
    for (int i = 0; i < 3; i++) { seta(i + 1, modes[cur_mode].numColors[i]); }
    for (int i = 0; i < 4; i++) { seta(i + 4, modes[cur_mode].patternThresh[i / 2][i % 2]); }
    for (int i = 0; i < 4; i++) { seta(i + 8, modes[cur_mode].colorThresh[i / 2][i % 2]); }
    for (int i = 0; i < 9; i++) { seta(i + 12, modes[cur_mode].args[i / 3][i % 3]); }
    for (int i = 0; i < 18; i++) { seta(i + 21, modes[cur_mode].timings[i / 6][i % 6]); }
    for (int i = 0; i < 81; i++) { seta(i + 39, modes[cur_mode].colors[i / 9][(i % 9) / 3][i % 3]); }

    color_set = -1;
    color_slot = -1;
    colorSelect.hide();
    viewMode.hide();
    viewColor.hide();
  }

  public void numColorsChanged(int i, int v) {
    for (int j = 0; j < 9; j++) {
      if (j < v) {
        colors[i][j].show();
      } else {
        colors[i][j].hide();
      }
    }
  }

  public void patternThreshChanged(int i, int j) {
    patternThresh.setBroadcast(false).setArrayValue(i, j).setBroadcast(true);
  }

  public void colorThreshChanged(int i, int j) {
    colorThresh.setBroadcast(false).setArrayValue(i, j).setBroadcast(true);
  }

  public void patternChanged(int p) {
    // TODO
    switch (p) {
      case 0: // Strobe
        argLabels[0].setValue("Group Size").show();
        for (int i = 0; i < 3; i++) {
          args[i][0].setBroadcast(false)
            .setRange(0, 9)
            .setNumberOfTickMarks(10)
            .showTickMarks(false)
            .setValue(0)
            .setBroadcast(true)
            .show();
        }

        argLabels[1].setValue("Skip After").show();
        for (int i = 0; i < 3; i++) {
          args[i][1].setBroadcast(false)
            .setRange(0, 9)
            .setNumberOfTickMarks(10)
            .showTickMarks(false)
            .setValue(0)
            .setBroadcast(true)
            .show();
        }

        argLabels[2].setValue("Repeat Group").show();
        for (int i = 0; i < 3; i++) {
          args[i][2].setBroadcast(false)
            .setRange(1, 100)
            .setNumberOfTickMarks(100)
            .showTickMarks(false)
            .setValue(0)
            .setBroadcast(true)
            .show();
        }

        timingLabels[0].setValue("Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][0].show(); }

        timingLabels[1].setValue("Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][1].show(); }

        timingLabels[2].setValue("Tail Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][2].show(); }

        timingLabels[3].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][3].hide(); }

        timingLabels[4].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][4].hide(); }

        timingLabels[5].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][5].hide(); }
        break;

      case 1: // Vexer
        argLabels[0].setValue("Repeat Strobe").show();
        for (int i = 0; i < 3; i++) {
          args[i][0].setBroadcast(false)
            .setRange(1, 100)
            .setNumberOfTickMarks(100)
            .showTickMarks(false)
            .setValue(0)
            .setBroadcast(true)
            .show();
        }

        argLabels[1].setValue("Repeat Tracer").show();
        for (int i = 0; i < 3; i++) {
          args[i][1].setBroadcast(false)
            .setRange(1, 100)
            .setNumberOfTickMarks(100)
            .showTickMarks(false)
            .setValue(0)
            .setBroadcast(true)
            .show();
        }

        argLabels[2].setValue("").hide();
        for (int i = 0; i < 3; i++) { args[i][2].hide(); }

        timingLabels[0].setValue("Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][0].show(); }

        timingLabels[1].setValue("Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][1].show(); }

        timingLabels[2].setValue("Tracer Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][2].show(); }

        timingLabels[3].setValue("Tracer Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][3].show(); }

        timingLabels[4].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][4].hide(); }

        timingLabels[5].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][5].hide(); }
        break;

      case 2: // Edge
        argLabels[0].setValue("Group Size").show();
        for (int i = 0; i < 3; i++) {
          args[i][0].setBroadcast(false)
            .setRange(0, 9)
            .setNumberOfTickMarks(10)
            .showTickMarks(false)
            .setValue(0)
            .setBroadcast(true)
            .show();
        }

        argLabels[1].setValue("").hide();
        for (int i = 0; i < 3; i++) { args[i][1].hide(); }

        argLabels[2].setValue("").hide();
        for (int i = 0; i < 3; i++) { args[i][2].hide(); }

        timingLabels[0].setValue("Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][0].show(); }

        timingLabels[1].setValue("Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][1].show(); }

        timingLabels[2].setValue("Center Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][2].show(); }

        timingLabels[3].setValue("Trailing Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][3].show(); }

        timingLabels[4].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][4].hide(); }

        timingLabels[5].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][5].hide(); }
        break;

      case 3: // Double
        argLabels[0].setValue("Repeat First").show();
        for (int i = 0; i < 3; i++) {
          args[i][0].setBroadcast(false)
            .setRange(1, 100)
            .setNumberOfTickMarks(100)
            .showTickMarks(false)
            .setValue(0)
            .setBroadcast(true)
            .show();
        }

        argLabels[1].setValue("Repeat Second").show();
        for (int i = 0; i < 3; i++) {
          args[i][1].setBroadcast(false)
            .setRange(1, 100)
            .setNumberOfTickMarks(100)
            .showTickMarks(false)
            .setValue(0)
            .setBroadcast(true)
            .show();
        }

        argLabels[2].setValue("").hide();
        for (int i = 0; i < 3; i++) { args[i][2].hide(); }

        timingLabels[0].setValue("First Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][0].show(); }

        timingLabels[1].setValue("First Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][1].show(); }

        timingLabels[2].setValue("Second Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][2].show(); }

        timingLabels[3].setValue("Second Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][3].show(); }

        timingLabels[4].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][4].hide(); }

        timingLabels[5].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][5].hide(); }
        break;

      case 4: // Runner
        argLabels[0].setValue("Group Size").show();
        for (int i = 0; i < 3; i++) {
          args[i][0].setBroadcast(false)
            .setRange(0, 9)
            .setNumberOfTickMarks(10)
            .showTickMarks(false)
            .setValue(0)
            .setBroadcast(true)
            .show();
        }

        argLabels[1].setValue("Skip Between").show();
        for (int i = 0; i < 3; i++) {
          args[i][1].setBroadcast(false)
            .setRange(0, 9)
            .setNumberOfTickMarks(10)
            .showTickMarks(false)
            .setValue(0)
            .setBroadcast(true)
            .show();
        }

        argLabels[2].setValue("Repeat Runner").show();
        for (int i = 0; i < 3; i++) {
          args[i][2].setBroadcast(false)
            .setRange(1, 100)
            .setNumberOfTickMarks(100)
            .showTickMarks(false)
            .setValue(0)
            .setBroadcast(true)
            .show();
        }

        timingLabels[0].setValue("Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][0].show(); }

        timingLabels[1].setValue("Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][1].show(); }

        timingLabels[2].setValue("Runner Strobe").show();
        for (int i = 0; i < 3; i++) { timings[i][2].show(); }

        timingLabels[3].setValue("Runner Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][3].show(); }

        timingLabels[4].setValue("Split Blank").show();
        for (int i = 0; i < 3; i++) { timings[i][4].show(); }

        timingLabels[5].setValue("").hide();
        for (int i = 0; i < 3; i++) { timings[i][5].hide(); }
        break;
    }
  }

  public void seta(int addr, int val) {
    if (addr == 0) {
      base.setBroadcast(false).setValue(val).setBroadcast(true);
      base.setCaptionLabel(base.getItem(val).get("text").toString());
      patternChanged(val);
    } else if (addr < 4) {
      numColors[addr - 1].setBroadcast(false).setValue(val).setBroadcast(true);
      numColorsChanged(addr - 1, val);
    } else if (addr < 8) {
      patternThresh.setBroadcast(false).setArrayValue(addr - 4, val).setBroadcast(true);
    } else if (addr < 12) {
      colorThresh.setBroadcast(false).setArrayValue(addr - 8, val).setBroadcast(true);
    } else if (addr < 21) {
      args[(addr - 12) / 3][(addr - 12) % 3].setBroadcast(false).setValue(val).setBroadcast(true);
    } else if (addr < 39) {
      timings[(addr - 21) / 6][(addr - 21) % 6].setBroadcast(false).setValue(val).setBroadcast(true);
    } else if (addr < 120) {
      int chan = (addr - 39) % 3;
      int slot = (addr - 39) / 9;
      int set = ((addr - 39) % 9) / 3;
      int x, y;

      if (chan == 0) {
        x = modes[cur_mode].colors[slot][set][1];
        y = modes[cur_mode].colors[slot][set][2];
        x = (x == 0) ? 0 : (x / 2) + 128;
        y = (y == 0) ? 0 : (y / 2) + 128;
        val = (val == 0) ? 0 : (val / 2) + 128;
        colors[set][slot].setColorBackground(color(val, x, y));
        colors[set][slot].setColorForeground(color(val, x, y));
        colors[set][slot].setColorActive(color(val, x, y));
      } else if (chan == 1) {
        x = modes[cur_mode].colors[slot][set][0];
        y = modes[cur_mode].colors[slot][set][2];
        x = (x == 0) ? 0 : (x / 2) + 128;
        y = (y == 0) ? 0 : (y / 2) + 128;
        val = (val == 0) ? 0 : (val / 2) + 128;
        colors[set][slot].setColorBackground(color(x, val, y));
        colors[set][slot].setColorForeground(color(x, val, y));
        colors[set][slot].setColorActive(color(x, val, y));
      } else if (chan == 2) {
        x = modes[cur_mode].colors[slot][set][0];
        y = modes[cur_mode].colors[slot][set][1];
        x = (x == 0) ? 0 : (x / 2) + 128;
        y = (y == 0) ? 0 : (y / 2) + 128;
        val = (val == 0) ? 0 : (val / 2) + 128;
        colors[set][slot].setColorBackground(color(x, y, val));
        colors[set][slot].setColorForeground(color(x, y, val));
        colors[set][slot].setColorActive(color(x, y, val));
      }
    }
  }

  public void selectColor(float v) {
    selectColor((int)v / 9, (int)v % 9);
  }

  public void selectColor(int set, int slot) {
    if (slot >= modes[cur_mode].numColors[set]) { return; }

    color_set = set;
    color_slot = slot;

    float p[] = colors[set][slot].getPosition();
    colorSelect.setPosition(p[0] - 4, p[1] - 4).show();
    viewMode.show();
    viewColor.show();

    for (int i = 0; i < 3; i++) {
      colorValues[i].setBroadcast(false)
        .setValue(modes[cur_mode].colors[slot][set][i])
        .setBroadcast(true);
    }
  }
}


public void style(String theControllerName) {
  Controller c = cp5.getController(theControllerName);
  c.getCaptionLabel().toUpperCase(false);
  c.getCaptionLabel().getStyle().setPadding(4,4,4,4);
  c.getCaptionLabel().getStyle().setMargin(-4,0,0,0);
}

public int translateColor(int i) {
  int r, g, b;
  r = (color_bank[i][0] == 0) ? 0 : 128 + (color_bank[i][0] / 2);
  g = (color_bank[i][1] == 0) ? 0 : 128 + (color_bank[i][1] / 2);
  b = (color_bank[i][2] == 0) ? 0 : 128 + (color_bank[i][2] / 2);
  return (255 << 24) + (r << 16) + (g << 8) + b;
}
class Mode {
  int       pattern;
  int[]     numColors = new int[3];
  int[][]   patternThresh = new int[2][2];
  int[][]   colorThresh = new int[2][2];
  int[][]   args = new int[3][3];
  int[][]   timings = new int[3][6];
  int[][][] colors = new int[9][3][3];

  Mode() {
  }

  public int geta(int addr) {
    if (addr == 0) {
      return pattern;
    } else if (addr < 4) {
      return numColors[addr - 1];
    } else if (addr < 8) {
      return patternThresh[(addr - 4) / 2][(addr - 4) % 2];
    } else if (addr < 12) {
      return colorThresh[(addr - 8) / 2][(addr - 8) % 2];
    } else if (addr < 21) {
      return args[(addr - 12) / 3][(addr - 12) % 3];
    } else if (addr < 39) {
      return timings[(addr - 21) / 6][(addr - 21) % 6];
    } else if (addr < 120) {
      return colors[(addr - 39) / 9][((addr - 39) % 9) / 3][(addr - 39) % 3];
    }
    return -1;
  }

  public void seta(int addr, int val) {
    if (addr == 0) {
      pattern = val;
    } else if (addr < 4) {
      numColors[addr - 1] = val;
    } else if (addr < 8) {
      patternThresh[(addr - 4) / 2][(addr - 4) % 2] = val;
    } else if (addr < 12) {
      colorThresh[(addr - 8) / 2][(addr - 8) % 2] = val;
    } else if (addr < 21) {
      args[(addr - 12) / 3][(addr - 12) % 3] = val;
    } else if (addr < 39) {
      timings[(addr - 21) / 6][(addr - 21) % 6] = val;
    } else if (addr < 120) {
      colors[(addr - 39) / 9][((addr - 39) % 9) / 3][(addr - 39) % 3] = val;
    }
  }

  public JSONArray j_numColors() {
    JSONArray jarr = new JSONArray();
    for (int i = 0; i < 3; i++) {
      jarr.setInt(i, numColors[i]);
    }
    return jarr;
  }

  public JSONArray j_patternThresh() {
    JSONArray jarr = new JSONArray();
    for (int i = 0; i < 2; i++) {
      JSONArray jarr1 = new JSONArray();
      for (int j = 0; j < 2; j++) {
        jarr1.setInt(j, patternThresh[i][j]);
      }
      jarr.setJSONArray(i, jarr1);
    }
    return jarr;
  }

  public JSONArray j_colorThresh() {
    JSONArray jarr = new JSONArray();
    for (int i = 0; i < 2; i++) {
      JSONArray jarr1 = new JSONArray();
      for (int j = 0; j < 2; j++) {
        jarr1.setInt(j, colorThresh[i][j]);
      }
      jarr.setJSONArray(i, jarr1);
    }
    return jarr;
  }

  public JSONArray j_args() {
    JSONArray jarr = new JSONArray();
    for (int i = 0; i < 3; i++) {
      JSONArray jarr1 = new JSONArray();
      for (int j = 0; j < 3; j++) {
        jarr1.setInt(j, args[i][j]);
      }
      jarr.setJSONArray(i, jarr1);
    }
    return jarr;
  }

  public JSONArray j_timings() {
    JSONArray jarr = new JSONArray();
    for (int i = 0; i < 3; i++) {
      JSONArray jarr1 = new JSONArray();
      for (int j = 0; j < 6; j++) {
        jarr1.setInt(j, timings[i][j]);
      }
      jarr.setJSONArray(i, jarr1);
    }
    return jarr;
  }

  public JSONArray j_colors() {
    JSONArray jarr = new JSONArray();
    for (int i = 0; i < 3; i++) {
      JSONArray jarr1 = new JSONArray();
      for (int j = 0; j < 9; j++) {
        JSONArray jarr2 = new JSONArray();
        for (int k = 0; k < 3; k++) {
          jarr2.setInt(k, colors[j][i][k]);
        }
        jarr1.setJSONArray(j, jarr2);
      }
      jarr.setJSONArray(i, jarr1);
    }
    return jarr;
  }

  public JSONObject asJSON() {
    JSONObject j_mode = new JSONObject();
    j_mode.setInt("pattern", pattern);
    j_mode.setJSONArray("num_colors", j_numColors());
    j_mode.setJSONArray("pattern_thresh", j_patternThresh());
    j_mode.setJSONArray("color_thresh", j_colorThresh());
    j_mode.setJSONArray("args", j_args());
    j_mode.setJSONArray("timings", j_timings());
    j_mode.setJSONArray("colors", j_colors());
    return j_mode;
  }

  public void json_numColors(JSONArray jarr) {
    for (int i = 0; i < 3; i++) {
      numColors[i] = jarr.getInt(i);
    }
  }

  public void json_patternThresh(JSONArray jarr) {
    for (int i = 0; i < 2; i++) {
      JSONArray jarr1 = jarr.getJSONArray(i);
      for (int j = 0; j < 2; j++) {
        patternThresh[i][j] = jarr1.getInt(j);
      }
    }
  }

  public void json_colorThresh(JSONArray jarr) {
    for (int i = 0; i < 2; i++) {
      JSONArray jarr1 = jarr.getJSONArray(i);
      for (int j = 0; j < 2; j++) {
        colorThresh[i][j] = jarr1.getInt(j);
      }
    }
  }

  public void json_args(JSONArray jarr) {
    for (int i = 0; i < 3; i++) {
      JSONArray jarr1 = jarr.getJSONArray(i);
      for (int j = 0; j < 3; j++) {
        args[i][j] = jarr1.getInt(j);
      }
    }
  }

  public void json_timings(JSONArray jarr) {
    for (int i = 0; i < 3; i++) {
      JSONArray jarr1 = jarr.getJSONArray(i);
      for (int j = 0; j < 6; j++) {
        timings[i][j] = jarr1.getInt(j);
      }
    }
  }

  public void json_colors(JSONArray jarr) {
    for (int i = 0; i < 3; i++) {
      JSONArray jarr1 = jarr.getJSONArray(i);
      for (int j = 0; j < 9; j++) {
        JSONArray jarr2 = jarr1.getJSONArray(j);
        for (int k = 0; k < 3; k++) {
          colors[j][i][k] = jarr2.getInt(k);
        }
      }
    }
  }

  public void fromJSON(JSONObject json) {
    pattern = json.getInt("pattern");
    json_numColors(json.getJSONArray("num_colors"));
    json_patternThresh(json.getJSONArray("pattern_thresh"));
    json_colorThresh(json.getJSONArray("color_thresh"));
    json_args(json.getJSONArray("args"));
    json_timings(json.getJSONArray("timings"));
    json_colors(json.getJSONArray("colors"));
  }
}










public class ThreshRange extends Controller<ThreshRange> {
  protected static final String MANY_SPACES = "                    ";
  protected static final int MODE_OFF = -1;
  protected static final int MODE_MINA = 0;
  protected static final int MODE_MIDA = 1;
  protected static final int MODE_MAXA = 2;
  protected static final int MODE_MINB = 3;
  protected static final int MODE_MIDB = 4;
  protected static final int MODE_MAXB = 5;

  protected static final int HORIZONTAL = 0;
  protected static final int VERTICAL = 1;

  public int alignValueLabel = CENTER;
  private int mode = -1;

  protected int handleSize = 6;
  protected int handleSize2 = 3;
  public int autoWidth = 99;
  public int autoHeight = 9;
  public  PVector autoSpacing = new PVector(0, 5, 0);

  protected float _myValuePosition;
  protected float _myValueRange;

  protected boolean isDragging;
  protected boolean isDraggable = true;
  protected boolean isFirstClick;

  //protected Label _myValueLabel;  // For low value
  protected Label _myMidValueLabel;
  protected Label _myHighValueLabel;

  protected int minAHandle = 0;
  protected int maxAHandle = 0;
  protected int minBHandle = 0;
  protected int maxBHandle = 0;

  int dA = 0;
  int dB = 0;


  public ThreshRange(ControlP5 theControlP5, String theName) {
    this(theControlP5, theControlP5.getDefaultTab(), theName, 0, 32, 4, 14, 18, 28, 0, 0, 792, 20);
    theControlP5.register(theControlP5.papplet, theName, this);
  }

  public ThreshRange(
      ControlP5 theControlP5,
      ControllerGroup<?> theParent,
      String theName,
      float theMin,
      float theMax,
      float theDefaultMinAValue,
      float theDefaultMaxAValue,
      float theDefaultMinBValue,
      float theDefaultMaxBValue,
      int theX,
      int theY,
      int theWidth,
      int theHeight) {

    super(theControlP5, theParent, theName, theX, theY, theWidth, theHeight);

    _myArrayValue = new float[] {theDefaultMinAValue , theDefaultMaxAValue, theDefaultMinBValue, theDefaultMaxBValue};

    _myMin = theMin;
    _myMax = theMax;
    _myValueRange = _myMax - _myMin;

    minAHandle = (int)(_myArrayValue[0] * 24) + 3;
    maxAHandle = (int)(_myArrayValue[1] * 24) + 9;
    minBHandle = (int)(_myArrayValue[2] * 24) + 15;
    maxBHandle = (int)(_myArrayValue[3] * 24) + 21;
    dA = maxAHandle - minAHandle;
    dB = maxBHandle - minBHandle;

    _myCaptionLabel = new controlP5.Label(cp5, theName)
      .setColor(0)
      .align(CENTER, TOP_OUTSIDE);

    _myValueLabel = new controlP5.Label(cp5, theName + "LowLabel")
      .setColor(0)
      .set("" + (int)theDefaultMinAValue)
      .setFont(createFont("Arial", 10))
      .align(LEFT, BOTTOM_OUTSIDE);

    _myMidValueLabel = new controlP5.Label(cp5, theName + "MidLabel")
      .setColor(0)
      .set("" + (int)theDefaultMaxAValue + MANY_SPACES + (int)theDefaultMinBValue)
      .setFont(createFont("Arial", 10))
      .align(CENTER, BOTTOM_OUTSIDE);

    _myHighValueLabel = new controlP5.Label(cp5, theName + "HighLabel")
      .setColor(0)
      .set("" + (int)theDefaultMaxBValue)
      .setFont(createFont("Arial", 10))
      .align(RIGHT, BOTTOM_OUTSIDE);

    _myValue = theDefaultMinAValue;
    update();
  }

  @Override public ThreshRange setColorValueLabel(int theColor) {
    _myValueLabel.setColor(theColor);
    _myMidValueLabel.setColor(theColor);
    _myHighValueLabel.setColor(theColor);
    return this;
  }

  @Override public ThreshRange setColorCaptionLabel(int theColor) {
    _myCaptionLabel.setColor(theColor);
    return this;
  }

  public ThreshRange setLowValueLabel(final String theLabel) {
    _myValueLabel.set(theLabel);
    return this;
  }

  public ThreshRange setMidValueLabel(final String theLabel) {
    _myMidValueLabel.set(theLabel);
    return this;
  }

  public ThreshRange setHighValueLabel(final String theLabel) {
    _myHighValueLabel.set(theLabel);
    return this;
  }

  public ThreshRange setSliderMode(int theMode) {
    return this;
  }

  public ThreshRange setHandleSize(int theSize) {
    handleSize = theSize;
    handleSize2 = theSize / 2;
    setMinA(_myArrayValue[0], false);
    setMaxA(_myArrayValue[1], false);
    setMinB(_myArrayValue[2], false);
    setMaxB(_myArrayValue[3], false);
    return this;
  }

  public int getMode() {
    final float posX = x(_myParent.getAbsolutePosition()) + x(position);
    final float posY = y(_myParent.getAbsolutePosition()) + y(position);
    final float mX = mouseX;
    final float mY = mouseY;

    if (mY < posY || mY > posY + getHeight()) {
      // Not inside
      return MODE_OFF;
    }

    int x0 = (int)(posX + minAHandle);
    int x1 = (int)(posX + maxAHandle);
    int x2 = (int)(posX + minBHandle);
    int x3 = (int)(posX + maxBHandle);

    if (mX >= x0 - handleSize2 && mX < x0 + handleSize2) {
      return MODE_MINA;
    } else if (mX >= x0 + handleSize2 && mX < x1 - handleSize2) {
      return MODE_MIDA;
    } else if (mX >= x1 - handleSize2 && mX < x1 + handleSize2) {
      return MODE_MAXA;
    } else if (mX >= x2 - handleSize2 && mX < x2 + handleSize2) {
      return MODE_MINB;
    } else if (mX >= x2 + handleSize2 && mX < x3 - handleSize2) {
      return MODE_MIDB;
    } else if (mX >= x3 - handleSize2 && mX < x3 + handleSize2) {
      return MODE_MAXB;
    }
    return MODE_OFF;
  }

  @Override public void mousePressed() {
    mode = getMode();
  }

  public ThreshRange updateInternalEvents(PApplet theApplet) {
    if (isVisible) {
      int c = mouseX - pmouseX;
      if (c == 0) {
        return this;
      }
      if (isMousePressed && !cp5.isAltDown()) {
        switch (mode) {
          case MODE_MINA:
            // 0 - (MaxA
            minAHandle = PApplet.max(3, PApplet.min(maxAHandle - 6, minAHandle + c));
            break;
          case MODE_MAXA:
            // MinA) - (MinB
            maxAHandle = PApplet.max(minAHandle + 6, PApplet.min(minBHandle - 6, maxAHandle + c));
            break;
          case MODE_MINB:
            // MaxA) - (MaxB
            minBHandle = PApplet.max(maxAHandle + 6, PApplet.min(maxBHandle - 6, minBHandle + c));
            break;
          case MODE_MAXB:
            // MinB) - width
            maxBHandle = PApplet.max(minBHandle + 6, PApplet.min(getWidth() - 3, maxBHandle + c));
            break;

          case MODE_MIDA:
            minAHandle = PApplet.max(3, PApplet.min(minBHandle - dA - 6, minAHandle + c));
            maxAHandle = PApplet.max(minAHandle + 6, PApplet.min(minBHandle - 6, minAHandle + dA));
            break;
          case MODE_MIDB:
            minBHandle = PApplet.max(maxAHandle + 6, PApplet.min(getWidth() - dB - 3, minBHandle + c));
            maxBHandle = PApplet.max(minBHandle + 6, PApplet.min(getWidth() - 3, minBHandle + dB));
            break;
        }
        update();
        dA = maxAHandle - minAHandle;
        dB = maxBHandle - minBHandle;
      }
    }
    return this;
  }

  @Override public ThreshRange setValue(float theValue) {
    _myValue = theValue;
    broadcast(ARRAY);
    return this;
  }

  @Override public ThreshRange update() {
    _myArrayValue[0] = min((minAHandle - 3) / 24, 32);
    _myArrayValue[1] = min((maxAHandle - 9) / 24, 32);
    _myArrayValue[2] = min((minBHandle - 15) / 24, 32);
    _myArrayValue[3] = min((maxBHandle - 21) / 24, 32);

    _myValueLabel.set("" + (int)_myArrayValue[0]);
    _myMidValueLabel.set("" + (int)_myArrayValue[1] + MANY_SPACES + (int)_myArrayValue[2]);
    _myHighValueLabel.set("" + (int)_myArrayValue[3]);
    return setValue(_myValue);
  }

  public ThreshRange setDraggable(boolean theFlag) {
    isDraggable = theFlag;
    isDragging = (theFlag == false) ? false : isDragging;
    return this;
  }

  public float[] getArrayValue() {
    return _myArrayValue;
  }

  protected float snapValue(float theValue) {
    return (float)(int)theValue;
  }

  private ThreshRange setMinA(float theValue, boolean isUpdate) {
    _myArrayValue[0] = PApplet.max(_myMin, snapValue(theValue));
    minAHandle = (int)(_myArrayValue[0] * 24) + 3;
    dA = maxAHandle - minAHandle;
    return (isUpdate) ? update() : this;
  }

  public ThreshRange setMinA(float theValue) {
    return setMinA(theValue, true);
  }

  private ThreshRange setMaxA(float theValue, boolean isUpdate) {
    _myArrayValue[1] = PApplet.max(_myMin, snapValue(theValue));
    maxAHandle = (int)(_myArrayValue[1] * 24) + 9;
    dA = maxAHandle - minAHandle;
    return (isUpdate) ? update() : this;
  }

  public ThreshRange setMaxA(float theValue) {
    return setMaxA(theValue, true);
  }

  private ThreshRange setMinB(float theValue, boolean isUpdate) {
    _myArrayValue[2] = PApplet.max(_myMin, snapValue(theValue));
    minBHandle = (int)(_myArrayValue[2] * 24) + 15;
    dB = maxBHandle - minBHandle;
    return (isUpdate) ? update() : this;
  }

  public ThreshRange setMinB(float theValue) {
    return setMinB(theValue, true);
  }

  private ThreshRange setMaxB(float theValue, boolean isUpdate) {
    _myArrayValue[3] = PApplet.max(_myMin, snapValue(theValue));
    maxBHandle = (int)(_myArrayValue[3] * 24) + 21;
    dB = maxBHandle - minBHandle;
    return (isUpdate) ? update() : this;
  }

  public ThreshRange setMaxB(float theValue) {
    return setMaxB(theValue, true);
  }

  public ThreshRange setArrayValue(int i, float v) {
    if (i == 0) {
      setMinA(v, false);
    } else if (i == 1) {
      setMaxA(v, false);
    } else if (i == 2) {
      setMinB(v, false);
    } else if (i == 3) {
      setMaxB(v, false);
    }
    return update();
  }

  @Override public ThreshRange setArrayValue(float[] theArray) {
    setMinA(theArray[0], false);
    setMaxA(theArray[1], false);
    setMinB(theArray[2], false);
    setMaxB(theArray[3], false);
    return update();
  }

  @Override public ThreshRange setMin(float theValue) {
    _myMin = theValue;
    _myValueRange = _myMax - _myMin;
    return setMinA(_myArrayValue[0]);
  }

  @Override public ThreshRange setMax(float theValue) {
    _myMax = theValue;
    _myValueRange = _myMax - _myMin;
    return setMaxB(_myArrayValue[1]);
  }

  public float getMinA() {
    return _myArrayValue[0];
  }

  public float getMaxA() {
    return _myArrayValue[1];
  }

  public float getMinB() {
    return _myArrayValue[2];
  }

  public float getMaxB() {
    return _myArrayValue[3];
  }

  @Override public ThreshRange setWidth(int theValue) {
    super.setWidth(theValue);
    return this;
  }

  @Override public ThreshRange setHeight(int theValue) {
    super.setHeight(theValue);
    return this;
  }

  @Override public void mouseReleased() {
    isDragging = false;
    // Align
    switch (mode) {
      case MODE_MINA:
        minAHandle = (int)(_myArrayValue[0] * 24) + 3;
        break;
      case MODE_MAXA:
        maxAHandle = (int)(_myArrayValue[1] * 24) + 9;
        break;
      case MODE_MINB:
        minBHandle = (int)(_myArrayValue[2] * 24) + 15;
        break;
      case MODE_MAXB:
        maxBHandle = (int)(_myArrayValue[3] * 24) + 21;
        break;
      case MODE_MIDA:
        minAHandle = (int)(_myArrayValue[0] * 24) + 3;
        maxAHandle = (int)(_myArrayValue[1] * 24) + 9;
        break;
      case MODE_MIDB:
        minBHandle = (int)(_myArrayValue[2] * 24) + 15;
        maxBHandle = (int)(_myArrayValue[3] * 24) + 21;
        break;
    }
    dA = maxAHandle - minAHandle;
    dB = maxBHandle - minBHandle;
    mode = MODE_OFF;
  }

  @Override public void mouseReleasedOutside() {
    mouseReleased();
  }

  @Override public void onLeave() {
    isDragging = false;
  }

  public ThreshRange setRange(float theMinValue, float theMaxValue) {
    setMin(theMinValue);
    setMax(theMaxValue);
    return this;
  }

  public ThreshRange setRangeValues(float theMinA, float theMaxA, float theMinB, float theMaxB) {
    return setArrayValue(new float[] {theMinA, theMaxA, theMinB, theMaxB});
  }

  @Override public ThreshRange updateDisplayMode(int theMode) {
    _myDisplayMode = theMode;
    switch (theMode) {
      case (DEFAULT):
        _myControllerView = new ThreshRangeView();
        break;
      case (SPRITE):
        _myControllerView = new ThreshRangeSpriteView();
        break;
      case (IMAGE):
        _myControllerView = new ThreshRangeImageView();
        break;
      case (CUSTOM):
      default:
        break;
    }
    return this;
  }

  class ThreshRangeSpriteView implements ControllerView<ThreshRange> {
    public void display(PGraphics theGraphics, ThreshRange theController) {
      ControlP5.logger().log(Level.INFO, "ThreshRangeSpriteDisplay not available.");
    }
  }

  class ThreshRangeView implements ControllerView<ThreshRange> {
    public void display(PGraphics theGraphics, ThreshRange theController) {
      int high = getMode();
      theGraphics.pushMatrix();

      // Pattern Zones
      theGraphics.fill(0);
      theGraphics.rect(0, 0, getWidth(), getHeight());

      theGraphics.fill(color(255, 0, 0));
      theGraphics.rect(0, 0, minAHandle, getHeight());
      theGraphics.fill(color(255, 255, 0));
      theGraphics.rect(minAHandle, 0, maxAHandle - minAHandle, getHeight());
      theGraphics.fill(color(0, 255, 0));
      theGraphics.rect(maxAHandle, 0, minBHandle - maxAHandle, getHeight());
      theGraphics.fill(color(0, 255, 255));
      theGraphics.rect(minBHandle, 0, maxBHandle - minBHandle, getHeight());
      theGraphics.fill(color(0, 0, 255));
      theGraphics.rect(maxBHandle, 0, getWidth() - maxBHandle, getHeight());

      theGraphics.fill(255);
      theGraphics.stroke(0);
      theGraphics.rect(minAHandle - handleSize2, 0, handleSize, getHeight());
      theGraphics.rect(maxAHandle - handleSize2, 0, handleSize, getHeight());
      theGraphics.rect(minBHandle - handleSize2, 0, handleSize, getHeight());
      theGraphics.rect(maxBHandle - handleSize2, 0, handleSize, getHeight());

      if (isLabelVisible) {
        _myCaptionLabel.draw(theGraphics, 0, 0, theController);
        _myValueLabel.draw(theGraphics, 0, 0, theController);
        _myMidValueLabel.draw(theGraphics, 0, 0, theController);
        _myHighValueLabel.draw(theGraphics, 0, 0, theController);
      }

      theGraphics.popMatrix();
    }
  }

  class ThreshRangeImageView implements ControllerView<ThreshRange> {
    public void display(PGraphics theGraphics, ThreshRange theController) {
      ControlP5.logger().log(Level.INFO, "ThreshRangeImageDisplay not implemented.");
    }
  }

  @Override public String toString() {
    return "type:\tThreshRange\n" + super.toString();
  }

  @Deprecated public float lowValue() {
    return getMinA();
  }

  @Deprecated public float highValue() {
    return getMaxB();
  }

  @Deprecated public float[] arrayValue() {
    return _myArrayValue;
  }
}
  public void settings() {  size(1000, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "vectrui" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
