********************************************************************************
* INSTALLATION                                                                 *
********************************************************************************

* Have the correct cable and the cable's driver installed:
    https://www.silabs.com/products/mcu/Pages/USBtoUARTBridgeVCPDrivers.aspx

* Have the latest Java Runtime Enviroment installed:
    http://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html

* Install the firmware to every chip:
    1. Download XLoader: http://russemotto.com/xloader/
    2. Plug in the chip
    3. Follow the instructions using "Arduino Uno" for the board type and "115200" for
       baud rate. Make sure to select the correct hex file when uploading.

* Run VectrUI or enjoy the presets:
    When running VectrUI, it will ask you to select a serial port. The port you
    should look like "COM4" or (less likely) "COM3" or "COM5". If you do not see this,
    try unplugging the light and plugging it back in or restarting.


********************************************************************************
* INSTRUCTIONS                                                                 *
********************************************************************************

In depth video tutorials are available on this YouTube playlist:
    https://www.youtube.com/playlist?list=PL2-rlIDsAnb5hCKwbkAIAeSQNEVPjpVWo
