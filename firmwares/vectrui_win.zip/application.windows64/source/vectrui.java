import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.event.KeyEvent; 
import processing.serial.*; 
import controlP5.*; 
import javax.swing.JFileChooser; 
import javax.swing.filechooser.FileNameExtensionFilter; 
import java.util.ArrayList; 
import java.util.logging.Level; 
import processing.core.PApplet; 
import processing.core.PGraphics; 
import processing.core.PVector; 
import controlP5.*; 
import java.util.ArrayList; 
import java.util.logging.Level; 
import processing.core.PApplet; 
import processing.core.PGraphics; 
import processing.core.PVector; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class vectrui extends PApplet {







ControlP5 cp5;

// Main
static final int ID_TYPE              = 100;
static final int ID_COLOREDIT         = 300;
static final int ID_COLORBANK         = 5000;

// Shared
static final int ID_PATTERN          = 1000;
static final int ID_ARG              = 1100;
static final int ID_TIMING           = 1200;
static final int ID_NUMCOLORS        = 1300;
static final int ID_COLORS           = 1400;

// Vectr Only
static final int ID_PATTERN_TRESH    = 1900;
static final int ID_COLOR_TRESH      = 1901;

// Primer Only
static final int ID_TRIGGER_MODE     = 2900;
static final int ID_TRIGGER_TRESH    = 2901;

final static String[] PATTERNS = {
  "Strobe",
  "Vexer",
  "Edge",
  "Multi",
  "Runner",
  "Stepper",
  "Random",
  /* "Flux", */
};
final static String[] TRIGGERMODES = {"Off", "Velocity", "Tilt", "Roll", "Flip"};
final static String[] MODETYPES = {"Vectr", "Primr"};

int COLOR_BANK[][] = {
  {208, 0, 0},      // red
  {182, 28, 0},     // sunrise
  {156, 56, 0},     // orange
  {130, 84, 0},     // banana
  {104, 112, 0},    // yellow
  {78, 140, 0},     // firefly
  {52, 168, 0},     // lime
  {26, 196, 0},     // emerald
  {0, 224, 0},      // green
  {0, 196, 30},     // seafoam
  {0, 168, 60},     // turquoise
  {0, 140, 90},     // ocean
  {0, 112, 120},    // cyan
  {0, 84, 150},     // sapphire
  {0, 56, 180},     // sky blue
  {0, 28, 210},     // royal blue
  {0, 0, 240},      // blue
  {26, 0, 210},     // indigo
  {52, 0, 180},     // purple
  {78, 0, 150},     // violet
  {104, 0, 120},    // magenta
  {130, 0, 90},     // blush
  {156, 0, 60},     // pink
  {182, 0, 30},     // sunset
  {104, 112, 120},  // white
  {130, 84, 90},    // redish white
  {78, 140, 90},    // greenish white
  {78, 84, 150},    // blueish white
  {156, 56, 60},    // pastel red
  {143, 112, 45},   // pastel
  {130, 140, 30},   // pastel yellow
  {104, 154, 45},   // pastel
  {52, 168, 60},    // pastel green
  {39, 154, 120},   // pastel
  {26, 140, 150},   // pastel cyan
  {39, 112, 165},   // pastel
  {52, 56, 180},    // pastel blue
  {104, 42, 165},   // pastel
  {130, 28, 150},   // pastel magenta
  {143, 42, 120},   // pastel
  {0, 0, 0},        // blank
  {13, 14, 16},     // dim white
  {26, 0, 0},       // dim red
  {20, 21, 0},      // dim yellow
  {0, 28, 0},       // dim green
  {0, 21, 24},      // dim cyan
  {0, 0, 32},       // dim blue
  {20, 0, 24},      // dim magenta
};

static final int SER_VERSION = 111;
static final int SER_DUMP           = 10;
static final int SER_DUMP_LIGHT     = 11;
static final int SER_SAVE           = 20;
static final int SER_READ           = 30;
static final int SER_WRITE          = 40;
static final int SER_WRITE_LIGHT    = 41;
static final int SER_WRITE_MODE     = 42;
static final int SER_WRITE_MODE_END = 43;
static final int SER_CHANGE_MODE    = 50;
static final int SER_RESET_MODE     = 51;
static final int SER_VIEW_MODE      = 100;
static final int SER_VIEW_COLOR     = 110;
static final int SER_DUMP_START     = 200;
static final int SER_DUMP_END       = 210;
static final int SER_HANDSHAKE      = 250;
static final int SER_HANDSHACK      = 251;
static final int SER_DISCONNECT     = 254;

int num_ports = 0;
int port_num = -1;
Serial ports[] = new Serial[10];
Serial port = null;

// State variables
boolean connected_serial = false;
boolean initialized = false;
boolean reading = false;
boolean flashing = false;
boolean view_mode = true;

// Light variables
int cur_mode = 0;
String file_path = "";

// All the groups
Group gMain;
Group gSerial;

Textlabel tlSerial;
String[] sSerial = new String[4];
Button[] bSerial = new Button[4];
Button bRefreshSerial;

Mode mode;
Mode[] modes = new Mode[7];


public void setup() {
  surface.setTitle("VectR UI (Beta 1)");
  
  frameRate(120);
  
  _loadColorBank("colorbank.json");

  cp5 = new ControlP5(this);
  cp5.setFont(createFont("Comfortaa-Bold", 14));

  gMain = cp5.addGroup("main")
    .setPosition(0, 0)
    .setWidth(1040)
    .setHeight(720)
    .hideBar()
    .hideArrow();
  mode = new Mode(gMain);

  gSerial = cp5.addGroup("serial")
    .setPosition(0, 0)
    .setWidth(1040)
    .setHeight(720)
    .hideBar()
    .hideArrow();

  cp5.addTextlabel("tlWelcome")
    .setGroup(gSerial)
    .setValue("Welcome to\n     VectR")
    .setFont(createFont("Comfortaa-Regular", 72))
    .setPosition(300, 150)
    .setSize(120, 40)
    .setColorValue(color(192, 192, 255));

  tlSerial = cp5.addTextlabel("tlSerial")
    .setGroup(gSerial)
    .setValue("Pick a serial port:")
    .setFont(createFont("Comfortaa-Regular", 32))
    .setPosition(380, 350)
    .setSize(120, 40)
    .setColorValue(color(240));

  for (int i = 0; i < 4; i++) {
    bSerial[i] = cp5.addButton("Serial" + i)
      .setCaptionLabel("")
      .setGroup(gSerial)
      .setId(10 + i)
      .setPosition(370, 400 + (30 * i))
      .hide();
    style(bSerial[i], 300);
  }

  for (int i = 0; i < 7; i++) {
    modes[i] = new Mode();
  }
}

public void draw() {
  background(16);
  if (!connected_serial) {
    for (String p: Serial.list()) {
      if (num_ports < 4 && !p.contains("Bluetooth")) {
        try {
          int i = (port_num >= 0) ? port_num : num_ports;
          ports[i] = new Serial(this, p, 115200);
          sSerial[i] = p;
          bSerial[i].setCaptionLabel(p).show();
          println("Found serial port " + p + " #" + i + ": " + ports[i]);
          if (port_num > 0) { num_ports++; }
        } catch (Exception e) {
        }
      }
    }
    gSerial.show();
    gMain.hide();
  } else if (!initialized) {
    if (port.available() >= 3) {
      readCommand();
    }
    gSerial.hide();
    gMain.hide();
  } else {
    while (port.available() >= 3) {
      readCommand();
    }
    if (reading || flashing) {
      gMain.hide();
    } else {
      gMain.show();
    }
    gSerial.hide();
  }
}

public void sendCommand(int cmd) {
  sendCommand(cmd, 0, 0, 0);
}

public void sendCommand(int cmd, int in0) {
  sendCommand(cmd, in0, 0, 0);
}

public void sendCommand(int cmd, int in0, int in1) {
  sendCommand(cmd, in0, in1, 0);
}

public void sendCommand(int cmd, int in0, int in1, int in2) {
  println("send " + cmd + " " + in0 + " " + in1 + " " + in2);
  if (initialized) {
    port.write(cmd);
    port.write(in0);
    port.write(in1);
    port.write(in2);
  }
}

public void readCommand() {
  int cmd = port.read();
  int addr = port.read();
  int val = port.read();
  println("get " + cmd + " " + addr + " " + val);

  if (cmd == SER_HANDSHAKE) {
    if (addr == SER_VERSION && val == SER_VERSION) {
      initialized = true;
      reading = true;
      sendCommand(SER_HANDSHAKE, SER_VERSION, SER_VERSION);
    }
  } else if (cmd == SER_HANDSHACK) {
    cur_mode = addr;
    sendCommand(SER_DUMP, 0, 0);
  } else if (cmd == SER_DUMP_START) {
    mode.deselectColor();
    cur_mode = addr;
    reading = true;
  } else if (cmd == SER_DUMP_END) {
    cur_mode = addr;
    reading = false;
    mode.tlTitle.setValue("Mode " + (cur_mode + 1));
  } else if (cmd == SER_DUMP_LIGHT) {
    flashing = false;
    actuallySaveLightFile();
  } else if (cmd < 7) {
    if (flashing) {
      modes[cmd].seta(addr, val);
    } else if (cmd == cur_mode) {
      mode.seta(addr, val);
    }
  }
}


public void style(ThreshRange thr) {
  thr.getCaptionLabel().toUpperCase(false)
    .getStyle().setPadding(4, 4, 4, 4)
    .setMargin(-4, 0, 0, 0);
}

public void style(Button btn, int w) {
  btn.setSize(w, 20)
    .setColorBackground(color(48))
    .setColorForeground(color(96))
    .setColorActive(color(128));
  btn.getCaptionLabel().toUpperCase(false)
    .setColor(color(240))
    .getStyle().setPadding(-1, 0, 0, 0);
}

public void style(DropdownList ddl) {
  ddl.getCaptionLabel().toUpperCase(false).getStyle().setPadding(4, 0, 0, 4);
  ddl.getValueLabel().toUpperCase(false).getStyle().setPadding(4, 0, 0, 4);
  ddl.setLabel("")
    .setColorBackground(color(48))
    .setColorForeground(color(96))
    .setColorActive(color(128))
    .setItemHeight(20)
    .setBarHeight(20)
    .close();
}

public void style(Slider sld, int _width, int _min, int _max) {
  sld.setBroadcast(false)
    .setTriggerEvent(ControlP5.RELEASE)
    .setSize(_width, 20)
    .setColorBackground(color(48))
    .setColorActive(color(128))
    .setRange(_min, _max)
    .setNumberOfTickMarks(_max - _min + 1)
    .showTickMarks(false)
    .setDecimalPrecision(0)
    .setValue(_min)
    .setBroadcast(true);
}

public int translateColor(int r, int g, int b) {
  r = (r == 0) ? 0 : 32 + ((r * 7) / 8);
  g = (g == 0) ? 0 : 32 + ((g * 7) / 8);
  b = (b == 0) ? 0 : 32 + ((b * 7) / 8);
  return (255 << 24) + (r << 16) + (g << 8) + b;
}

public int translateColor(int[] c) {
  return translateColor(c[0], c[1], c[2]);
}

public int getColorBankColor(int i, int s) {
  return translateColor(COLOR_BANK[i][0] >> s, COLOR_BANK[i][1] >> s, COLOR_BANK[i][2] >> s);
}


//********************************************************************************
// Button actions
//********************************************************************************
public void prevMode(int v) {
  if (!view_mode) viewMode(0);
  sendCommand(SER_CHANGE_MODE, 99);
}

public void nextMode(int v) {
  if (!view_mode) viewMode(0);
  sendCommand(SER_CHANGE_MODE, 101);
}

public void loadColorBank() {
  selectInput("Select json color bank file", "_loadColorBank");
}

public void _loadColorBank(File file) {
  if (file == null) {
  } else {
    _loadColorBank(file.getAbsolutePath());
    mode.loadColorBank();
  }
}

public void _loadColorBank(String fname) {
  try {
    JSONArray jarr = loadJSONArray(fname);
    for (int i = 0; i < 48; i++) {
      JSONArray jarr1 = jarr.getJSONArray(i);
      for (int j = 0; j < 3; j++) {
        COLOR_BANK[i][j] = jarr1.getInt(j);
      }
    }
  } catch (Exception ex) {
    println("Loading colorbank.json failed! Falling back on default. " + ex);
  }
}

public void uploadLight() {
  selectInput("Select light file to upload to the light", "_uploadLightFile");
}

public void _uploadLightFile(File file) {
  if (file == null) {
  } else {
    try {
      flashing = true;
      String path = file.getAbsolutePath();
      JSONArray ja = loadJSONArray(path);
      for (int i = 0; i < 7; i++) {
        modes[i].fromJSON(ja.getJSONObject(i));
        for (int c = 0; c < 16; c++) {
          for (int b = 0; b < 8; b++) {
            sendCommand(SER_WRITE_LIGHT, i, b, modes[i].geta(b));
            delay(2);
          }
          delay(5);
        }
      }
      sendCommand(SER_CHANGE_MODE, cur_mode);
      flashing = false;
    } catch (Exception ex) {
      println("Write light failed! " + ex);
    }
  }
}

public void saveLight() {
  selectOutput("Select light file to save to", "_saveLightFile");
}

public void actuallySaveLightFile() {
  JSONArray ja = new JSONArray();

  for (int i = 0; i < 7; i++) {
    ja.setJSONObject(i, modes[i].getJSON());
  }

  try {
    saveJSONArray(ja, file_path, "compact");
  } catch (Exception ex) {
    println("Save light failed! " + ex);
  }
}

public void _saveLightFile(File file) {
  if (file == null) {
  } else {
    file_path = file.getAbsolutePath();
    if (!file_path.endsWith(".light")) file_path = file_path + ".light";
    flashing = true;
    sendCommand(SER_DUMP_LIGHT);
  }
}

public void uploadMode() {
  selectInput("Select mode file to load", "_uploadModeFile");
}

public void _uploadModeFile(File file) {
  if (file == null) {
  } else {
    try {
      String path = file.getAbsolutePath();
      mode.fromJSON(loadJSONObject(path));
      for (int b = 0; b < mode._MODESIZE; b++) {
        sendCommand(SER_WRITE, b, mode.geta(b));
      }
      sendCommand(SER_SAVE);
    } catch (Exception ex) {
      println("Load mode failed! " + ex);
    }
  }
}

public void saveMode() {
  selectOutput("Select mode file to save", "_saveModeFile");
}

public void _saveModeFile(File file) {
  if (file == null) {
  } else {
    String path = file.getAbsolutePath();
    if (!path.endsWith(".mode")) path = path + ".mode";
    try {
      saveJSONObject(mode.getJSON(), path, "compact");
    } catch (Exception ex) {
      println("Save mode failed! " + ex);
    }
  }
}

public void writeChanges(int v) {
  sendCommand(SER_SAVE);
}

public void resetChanges(int v) {
  sendCommand(SER_CHANGE_MODE, cur_mode);
}

public void disconnectLight(int v) {
  sendCommand(SER_DISCONNECT);

  sSerial[port_num] = "";
  bSerial[port_num].hide();

  connected_serial = false;
  initialized = false;
  cur_mode = 0;
  port_num = -1;
}

public void viewMode(int v) {
  view_mode = true;
  sendCommand(SER_VIEW_MODE);
  mode.bViewMode.setColorBackground(color(128));
  mode.bViewColor.setColorBackground(color(48));
}

public void viewColor(int v) {
  view_mode = false;
  sendCommand(SER_VIEW_COLOR, mode.getColorSet(), mode.getColorSlot());
  mode.bViewMode.setColorBackground(color(48));
  mode.bViewColor.setColorBackground(color(128));
}

public void controlEvent(CallbackEvent theEvent) {
  Controller eController = theEvent.getController();
  String eName = eController.getName();
  int eVal = (int)eController.getValue();
  int eId = eController.getId();
  int eAction = theEvent.getAction();

  if (eId == ID_TYPE) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      mode.setType(eVal);
    } else if (eAction == ControlP5.ACTION_LEAVE) {
      mode.dlType.close();
    }
  } else if (eId >= ID_PATTERN && eId < ID_PATTERN + 2) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      mode.setPattern(eId - ID_PATTERN, eVal);
    } else if (eAction == ControlP5.ACTION_LEAVE) {
      mode.closeDropdowns();
    }
  } else if (eId == ID_TRIGGER_MODE) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      mode.setTriggerMode(eVal);
      mode.sendTriggerMode();
    } else if (eAction == ControlP5.ACTION_LEAVE) {
      mode.pmode.dlTriggerMode.close();
    }
  } else if (eId == ID_PATTERN_TRESH) {
    if (eAction == ControlP5.ACTION_RELEASED || eAction == ControlP5.ACTION_RELEASEDOUTSIDE) {
      mode.setPatternThresh(eController.getArrayValue());
      mode.sendPatternThresh();
    }
  } else if (eId == ID_COLOR_TRESH) {
    if (eAction == ControlP5.ACTION_RELEASED || eAction == ControlP5.ACTION_RELEASEDOUTSIDE) {
      mode.setColorThresh(eController.getArrayValue());
      mode.sendColorThresh();
    }
  } else if (eId == ID_TRIGGER_TRESH) {
    if (eAction == ControlP5.ACTION_RELEASED || eAction == ControlP5.ACTION_RELEASEDOUTSIDE) {
      mode.setTriggerThresh(eController.getArrayValue());
      mode.sendTriggerThresh();
    }
  } else if (eId >= ID_ARG && eId < ID_ARG + 15) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      mode.setArgs(eId - ID_ARG, eVal);
      mode.sendArgs(eId - ID_ARG);
    }
  } else if (eId >= ID_TIMING && eId < ID_TIMING + 24) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      mode.setTimings(eId - ID_TIMING, eVal);
      mode.sendTimings(eId - ID_TIMING);
    }
  } else if (eId >= ID_NUMCOLORS && eId < ID_NUMCOLORS + 3) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      mode.setNumColors(eId - ID_NUMCOLORS, eVal);
      mode.sendNumColors(eId - ID_NUMCOLORS);
    }
  } else if (eId >= ID_COLORS && eId < ID_COLORS + 27) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      mode.selectColor(eId - ID_COLORS);
      if (!view_mode) {
        viewColor(0);
      }
    }
  } else if (eId >= ID_COLOREDIT && eId < ID_COLOREDIT + 3) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      mode.setColor(mode.getColorSet(), mode.getColorSlot(), eId - ID_COLOREDIT, eVal);
      mode.sendColor(mode.getColorSet(), mode.getColorSlot(), eId - ID_COLOREDIT);
    }
  } else if (eId >= ID_COLORBANK) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      int s = (eId - ID_COLORBANK) / 100;
      int i = (eId - ID_COLORBANK) % 100;
      int[] c = {COLOR_BANK[i][0] >> s, COLOR_BANK[i][1] >> s, COLOR_BANK[i][2] >> s};
      mode.setColor(mode.getColorSet(), mode.getColorSlot(), c);
      mode.sendColor(mode.getColorSet(), mode.getColorSlot());
    }
  } else if (eName.startsWith("Serial")) {
    if (eAction == ControlP5.ACTION_BROADCAST) {
      println("Connect to port " + (10 - eId));
      port = ports[eId - 10];
      port_num = eId - 10;
      connected_serial = true;
    }
  }
}


public boolean oob(float x, float _min, float _max) {
  return x < _min || x > _max;
}

public boolean oob(int x, int _min, int _max) {
  return x < _min || x > _max;
}
class Mode {
  boolean use_gui = true;

  static final int _TYPE = 0;
  static final int _MODESIZE = 128;

  int   _type = 0;
  int[] data = new int[_MODESIZE];

  VectrMode vmode;
  PrimerMode pmode;

  Group gMain;
  Group gVectr;
  Group gPrimer;
  Group gTitle;
  Group gControls;
  Group gColorEdit;
  Group gColorBank;

  // Title
  Textlabel tlTitle;
  Button bNextMode;
  Button bPrevMode;

  // Controls
  Button bSaveMode;
  Button bLoadMode;
  Button bWriteMode;
  Button bResetMode;
  Button bSaveLight;
  Button bWriteLight;
  Button bDisconnectLight;
  Button bLoadColors;

  // ColorEdit
  Slider[] slColorValues = new Slider[3];
  Button bViewMode;
  Button bViewColor;

  // ColorBank
  Button[][] bColorBank = new Button[48][4];

  DropdownList dlType;


  Mode() {
    use_gui = false;
    vmode = new VectrMode();
    pmode = new PrimerMode();
  }

  Mode(Group g) {
    gMain = g;

    dlType = cp5.addDropdownList("type")
      .setGroup(gMain)
      .setId(ID_TYPE)
      /* .setPosition(50, 20) */
      .setPosition(580, 20)
      .setSize(90, 60)
      .setItems(MODETYPES);
    style(dlType);

    gTitle = cp5.addGroup("title")
      .setGroup(gMain)
      .setPosition(300, 10)
      .hideBar()
      .hideArrow();
    makeTitle();

    bDisconnectLight = cp5.addButton("disconnectLight")
      .setCaptionLabel("Disconnect")
      .setGroup(gMain)
      .setPosition(50, 20);
    style(bDisconnectLight, 90);

    bLoadColors = cp5.addButton("loadColorBank")
      .setCaptionLabel("Load Colors")
      .setGroup(gMain)
      .setPosition(170, 20);
    style(bLoadColors, 90);

    gControls = cp5.addGroup("controls")
      .setGroup(gMain)
      .setPosition(30, 680)
      .hideBar()
      .hideArrow();
    makeControls();

    gColorEdit = cp5.addGroup("colorEdit")
      .setGroup(gMain)
      .setPosition(554, 540)
      .hideBar()
      .hideArrow()
      .hide();
    makeColorEdit();

    gVectr = cp5.addGroup("vectr")
      .setGroup(gMain)
      .setPosition(20, 60)
      .hideBar()
      .hideArrow();
    vmode = new VectrMode(gVectr);
    gVectr.hide();

    gPrimer = cp5.addGroup("primer")
      .setGroup(gMain)
      .setPosition(20, 60)
      .hideBar()
      .hideArrow();
    pmode = new PrimerMode(gPrimer);
    gPrimer.hide();

    gColorBank = cp5.addGroup("colorBank")
      .setGroup(gMain)
      .setPosition(820, 0)
      .hideBar()
      .hideArrow();
    makeColorBank();

    dlType.bringToFront();
  }

  public int geta(int addr) {
    if (addr < 0 || addr >= _MODESIZE) {
    } else if (addr == 0) {
      if (_type != 0 && _type != 1) {
        // force vectr mode
        _type = 0;
      }
      return _type;
    } else {
      if (_type != 1) {
        return vmode.geta(addr);
      } else {
        return pmode.geta(addr);
      }
    }
    return 0;
  }

  public void seta(int addr, int val) {
    if (addr < 0 || addr >= _MODESIZE) {
    } else if (addr == 0) {
      setType(val);
      if (_type == 1) {
        pmode.setTriggerMode(0);
      }
    } else {
      if (_type != 1) {
        vmode.seta(addr, val);
      } else {
        pmode.seta(addr, val);
      }
    }
  }

  public void resetTypeGui() {
    gVectr.hide();
    gPrimer.hide();

    if (_type != 1) {
      gVectr.show();
      vmode.deselectColor();
      vmode.setPattern(0);
      for (int i = 0; i < 4; i++) {
        vmode.setPatternThresh(i, 32);
        vmode.setColorThresh(i, 32);
      }
      for (int i = 0; i < 3; i++) {
        vmode.setNumColors(i, 3);
        vmode.setColor(i, 0, COLOR_BANK[0]);
        vmode.setColor(i, 1, COLOR_BANK[8]);
        vmode.setColor(i, 2, COLOR_BANK[16]);
        vmode.setColor(i, 3, COLOR_BANK[24]);
        vmode.setColor(i, 4, COLOR_BANK[24]);
        vmode.setColor(i, 5, COLOR_BANK[24]);
        vmode.setColor(i, 6, COLOR_BANK[24]);
        vmode.setColor(i, 7, COLOR_BANK[24]);
        vmode.setColor(i, 8, COLOR_BANK[24]);
      }
    } else {
      gPrimer.show();
      pmode.deselectColor();
      pmode.setPattern(0, 0);
      pmode.setPattern(1, 0);
      pmode.setTriggerMode(0);
      for (int i = 0; i < 2; i++) {
        pmode.setTriggerThresh(i, 32);
      }
      for (int i = 0; i < 2; i++) {
        pmode.setNumColors(i, 3);
        pmode.setColor(i, 0, COLOR_BANK[0]);
        pmode.setColor(i, 1, COLOR_BANK[8]);
        pmode.setColor(i, 2, COLOR_BANK[16]);
        pmode.setColor(i, 3, COLOR_BANK[24]);
        pmode.setColor(i, 4, COLOR_BANK[24]);
        pmode.setColor(i, 5, COLOR_BANK[24]);
        pmode.setColor(i, 6, COLOR_BANK[24]);
        pmode.setColor(i, 7, COLOR_BANK[24]);
        pmode.setColor(i, 8, COLOR_BANK[24]);
      }
    }

    deselectColor();
    resetPatternGui();
    resetArgsAndTimings();
  }

  public void resetPatternGui() {
    if (_type != 1) {
      vmode.resetPatternGui();
    } else {
      pmode.resetPatternGui(0);
      pmode.resetPatternGui(1);
    }
  }

  public void resetArgsAndTimings() {
    if (_type != 1) {
      vmode.resetArgsAndTimings();
    } else {
      pmode.resetArgsAndTimings(0);
      pmode.resetArgsAndTimings(1);
    }
  }

  public void resetArgsAndTimings(int i) {
    if (_type == 1) {
      pmode.resetArgsAndTimings(i);
    }
  }

  public void deselectColor() {
    gColorEdit.hide();
    if (_type != 1) {
      vmode.deselectColor();
    } else {
      pmode.deselectColor();
    }
  }

  public void selectColor(int i) {
    boolean success = false;
    if (_type != 1) {
      success = vmode.selectColor(i);
    } else {
      success = pmode.selectColor(i);
    }
    if (success) {
      if (!view_mode) {
        sendCommand(SER_VIEW_COLOR, getColorSet(), getColorSlot());
      }
      gColorEdit.show();
    }
  }

  //********************************************************************************
  // Setters
  //********************************************************************************
  // Type
  public void setType(int val) {
    if (oob(val, 0, 1)) { val = 0; }
    int old = _type;
    _type = val;
    if (use_gui) {
      dlType.setBroadcast(false).setValue(_type).setBroadcast(true);
      dlType.setCaptionLabel(dlType.getItem(val).get("text").toString());
      if (old != _type) {
        resetTypeGui();
        sendMode();
      }
    }
  }

  public void sendType() {
    sendCommand(SER_WRITE, _TYPE, _type);
  }

  // Pattern
  public void setPattern(int val) {
    setPattern(0, val);
  }

  public void setPattern(int i, int val) {
    if (_type != 1) {
      vmode.setPattern(val);
    } else {
      pmode.setPattern(i, val);
    }
  }

  public void sendPattern() {
    sendPattern(0);
  }

  public void sendPattern(int i) {
    if (_type != 1) {
      vmode.sendPattern();
    } else {
      pmode.sendPattern(i);
    }
  }

  // Args
  public void setArgs(int i, int val) {
    if (_type != 1) {
      vmode.setArgs(i, val);
    } else {
      pmode.setArgs(i, val);
    }
  }

  public void sendArgs(int i) {
    if (_type != 1) {
      vmode.sendArgs(i);
    } else {
      pmode.sendArgs(i);
    }
  }

  // Timings
  public void setTimings(int i, int val) {
    if (_type != 1) {
      vmode.setTimings(i, val);
    } else {
      pmode.setTimings(i, val);
    }
  }

  public void setTimings(int x, int y, int val) {
    if (_type != 1) {
      vmode.setTimings(x, y, val);
    } else {
      pmode.setTimings(x, y, val);
    }
  }

  public void sendTimings(int i) {
    if (_type != 1) {
      vmode.sendTimings(i);
    } else {
      pmode.sendTimings(i);
    }
  }

  public void sendTimings(int x, int y) {
    if (_type != 1) {
      vmode.sendTimings(x, y);
    } else {
      pmode.sendTimings(x, y);
    }
  }

  // Num Colors
  public void setNumColors(int i, int val) {
    if (_type != 1) {
      vmode.setNumColors(i, val);
    } else {
      pmode.setNumColors(i, val);
    }
  }

  public void sendNumColors(int i) {
    if (_type != 1) {
      vmode.sendNumColors(i);
    } else {
      pmode.sendNumColors(i);
    }
  }

  // Colors
  public void setColor(int _set, int _color, int _channel, int val) {
    if (_type != 1) {
      vmode.setColor(_set, _color, _channel, val);
    } else {
      pmode.setColor(_set, _color, _channel, val);
    }
  }

  public void setColor(int _set, int _color, int[] val) {
    if (_type != 1) {
      vmode.setColor(_set, _color, val);
    } else {
      pmode.setColor(_set, _color, val);
    }
  }

  public void setColor(int i, int val) {
    if (_type != 1) {
      vmode.setColor(i, val);
    } else {
      pmode.setColor(i, val);
    }
  }

  public void sendColor(int _set, int _color, int _channel) {
    if (_type != 1) {
      vmode.sendColor(_set, _color, _channel);
    } else {
      pmode.sendColor(_set, _color, _channel);
    }
  }

  public void sendColor(int _set, int _color) {
    if (_type != 1) {
      vmode.sendColor(_set, _color);
    } else {
      pmode.sendColor(_set, _color);
    }
  }

  // Pattern Thresh - Vectr only
  public void setPatternThresh(float[] val) {
    if (_type != 1) {
      vmode.setPatternThresh(val);
    }
  }

  public void setPatternThresh(int i, int val) {
    if (_type != 1) {
      vmode.setPatternThresh(i, val);
    }
  }

  public void sendPatternThresh() {
    if (_type != 1) {
      vmode.sendPatternThresh();
    }
  }

  // Color Thresh - Vectr only
  public void setColorThresh(float[] val) {
    if (_type != 1) {
      vmode.setColorThresh(val);
    }
  }

  public void setColorThresh(int i, int val) {
    if (_type != 1) {
      vmode.setColorThresh(i, val);
    }
  }

  public void sendColorThresh() {
    if (_type != 1) {
      vmode.sendColorThresh();
    }
  }

  // Trigger Mode - Primer Only
  public void setTriggerMode(int val) {
    if (_type == 1) {
      pmode.setTriggerMode(val);
    }
  }

  public void sendTriggerMode() {
    if (_type == 1) {
      pmode.sendTriggerMode();
    }
  }

  // Trigger Thresh - Primer Only
  public void setTriggerThresh(float[] val) {
    if (_type == 1) {
      pmode.setTriggerThresh(val);
    }
  }

  public void setTriggerThresh(int i, int val) {
    if (_type == 1) {
      pmode.setTriggerThresh(i, val);
    }
  }

  public void sendTriggerThresh() {
    if (_type == 1) {
      pmode.sendTriggerThresh();
    }
  }


  //********************************************************************************
  // JSON
  //********************************************************************************
  public void fromJSON(JSONObject jo) {
    try {
      setType(jo.getInt("type"));
    } catch (Exception ex) {
      setType(0);
    }
    if (_type != 1) {
      vmode.fromJSON(jo);
    } else {
      pmode.fromJSON(jo);
    }

    for (int i = 0; i < _MODESIZE; i++) {
      sendCommand(SER_WRITE, i, geta(i));
    }
  }

  public JSONObject getJSON() {
    JSONObject jo = new JSONObject();
    if (_type != 1) {
      jo = vmode.getJSON();
    } else {
      jo = pmode.getJSON();
    }
    jo.setInt("type", _type);
    return jo;
  }

  public void makeTitle() {
    tlTitle = cp5.addTextlabel("tlTitle")
      .setGroup(gTitle)
      .setValue("Mode 1")
      .setFont(createFont("Comfortaa-Regular", 32))
      .setPosition(60, 0)
      .setSize(120, 40)
      .setColorValue(color(240));

    bPrevMode = cp5.addButton("prevMode")
      .setCaptionLabel("<<")
      .setGroup(gTitle)
      .setPosition(0, 10);
    style(bPrevMode, 20);

    bNextMode = cp5.addButton("nextMode")
      .setCaptionLabel(">>")
      .setGroup(gTitle)
      .setPosition(220, 10);
    style(bNextMode, 20);
  }

  public void makeControls() {
    bResetMode = cp5.addButton("resetChanges")
      .setCaptionLabel("Undo Edits")
      .setGroup(gControls)
      .setPosition(5, 0);
    style(bResetMode, 90);

    bWriteMode = cp5.addButton("writeChanges")
      .setCaptionLabel("Save Edits")
      .setGroup(gControls)
      .setPosition(105, 0);
    style(bWriteMode, 90);

    bSaveMode = cp5.addButton("saveMode")
      .setCaptionLabel("Save Mode")
      .setGroup(gControls)
      .setPosition(305, 0);
    style(bSaveMode, 90);

    bLoadMode = cp5.addButton("uploadMode")
      .setCaptionLabel("Upload Mode")
      .setGroup(gControls)
      .setPosition(405, 0);
    style(bLoadMode, 90);

    bSaveLight = cp5.addButton("saveLight")
      .setCaptionLabel("Save Light")
      .setGroup(gControls)
      .setPosition(605, 0);
    style(bSaveLight, 90);

    bWriteLight = cp5.addButton("uploadLight")
      .setCaptionLabel("Upload Light")
      .setGroup(gControls)
      .setPosition(705, 0);
    style(bWriteLight, 90);
  }

  public void makeColorEdit() {
    slColorValues[0] = cp5.addSlider("ColorValuesRed")
      .setGroup(gColorEdit)
      .setId(ID_COLOREDIT + 0)
      .setLabel("")
      .setPosition(0, 0);
    style(slColorValues[0], 256, 0, 255);
    slColorValues[0].setColorBackground(color(64, 0, 0))
      .setColorForeground(color(128, 0, 0))
      .setColorActive(color(192, 0, 0));

    slColorValues[1] = cp5.addSlider("ColorValuesGreen")
      .setGroup(gColorEdit)
      .setId(ID_COLOREDIT + 1)
      .setLabel("")
      .setPosition(0, 30);
    style(slColorValues[1], 256, 0, 255);
    slColorValues[1].setColorBackground(color(0, 64, 0))
      .setColorForeground(color(0, 128, 0))
      .setColorActive(color(0, 192, 0));

    slColorValues[2] = cp5.addSlider("ColorValuesBlue")
      .setGroup(gColorEdit)
      .setId(ID_COLOREDIT + 2)
      .setLabel("")
      .setPosition(0, 60);
    style(slColorValues[2], 256, 0, 255);
    slColorValues[2].setColorBackground(color(0, 0, 64))
      .setColorForeground(color(0, 0, 128))
      .setColorActive(color(0, 0, 192));

    bViewMode = cp5.addButton("viewMode")
      .setCaptionLabel("View Mode")
      .setGroup(gColorEdit)
      .setPosition(15, 100);
    style(bViewMode, 100);
    bViewMode.setColorBackground(color(128))
      .setColorForeground(color(96));

    bViewColor = cp5.addButton("viewColor")
      .setCaptionLabel("View Color")
      .setGroup(gColorEdit)
      .setPosition(141, 100);
    style(bViewColor, 100);
    bViewColor.setColorBackground(color(48))
      .setColorForeground(color(96));
  }

  public void makeColorBank() {
    for (int g = 0; g < 6; g++) {
      for (int c = 0; c < 8; c++) {
        for (int s = 0; s < 4; s++) {
          bColorBank[(g * 8) + c][s] = cp5.addButton("ColorBank" + ((g * 8) + c) + "." + s)
            .setGroup(gColorBank)
            .setId(ID_COLORBANK + ((g * 8) + c) + (100 * s))
            .setLabel("")
            .setSize(16, 16)
            .setPosition(24 + 4 + (24 * c), 22 + 4 + (116 * g) + (24 * s))
            .setColorBackground(getColorBankColor((g * 8) + c, s))
            .setColorForeground(getColorBankColor((g * 8) + c, s))
            .setColorActive(getColorBankColor((g * 8) + c, s));
        }
      }
    }
  }

  public void loadColorBank() {
    for (int c = 0; c < 48; c++) {
      for (int s = 0; s < 4; s++) {
        bColorBank[c][s]
          .setColorActive(getColorBankColor(c, s))
          .setColorBackground(getColorBankColor(c, s))
          .setColorForeground(getColorBankColor(c, s));
      }
    }
  }

  public int getColorSet() {
    if (_type != 1) {
      return vmode.color_set;
    } else {
      return pmode.color_set;
    }
  }

  public int getColorSlot() {
    if (_type != 1) {
      return vmode.color_slot;
    } else {
      return pmode.color_slot;
    }
  }

  public void closeDropdowns() {
    vmode.dlPattern.close();
    pmode.dlPattern[0].close();
    pmode.dlPattern[1].close();
  }

  public void sendMode() {
    if (!reading) {
      sendCommand(SER_WRITE_MODE);
      for (int i = 0; i < _MODESIZE; i++) {
        sendCommand(SER_WRITE, i, geta(i));
        delay(2);
      }
      sendCommand(SER_WRITE_MODE_END);
    }
  }
}
class PrimerMode {
  boolean use_gui = true;

  static final int _TRIGGER_MODE = 1;
  static final int _TRIGGER_THRESH = 2;
  static final int _PATTERN = 4;
  static final int _ARGS = 6;
  static final int _TIMINGS = 16;
  static final int _NUMCOLORS = 32;
  static final int _COLORS = 34;
  static final int _PADDING = 88;

  int       triggerMode = 0;
  int[]     triggerThresh = new int[2];
  int[]     pattern = new int[2];
  int[][]   args = new int[2][5];
  int[][]   timings = new int[2][8];
  int[]     numColors = new int[2];
  int[][][] colors = new int[2][9][3];

  //********************************************************************************
  // GUI Elements
  //********************************************************************************
  Group gPrimer;
  Group gPatternArgs;
  Group gTimings;
  Group gColors;

  Textlabel tlTriggerMode;
  DropdownList dlTriggerMode;
  TriggerRange trTriggerThresh;
  Textlabel[] tlPatternLabel = new Textlabel[2];
  DropdownList[] dlPattern = new DropdownList[2];
  Textlabel[][] tlArgLabels = new Textlabel[2][5];
  Slider[][] slArgs = new Slider[2][5];
  Textlabel[][] tlTimingLabels = new Textlabel[2][8];
  Slider[][] slTimings = new Slider[2][8];
  Slider[] slNumColors = new Slider[2];
  Button[][] bColors = new Button[2][9];
  /* Button[][] bColorBgs = new Button[2][9]; */

  Button bSelectedColor;
  int color_set = -1;
  int color_slot = -1;


  PrimerMode() {
    use_gui = false;
  }

  PrimerMode(Group g) {
    gPrimer = g;

    tlTriggerMode = cp5.addTextlabel("PrimerTriggerModeLabel")
        .setGroup(gPatternArgs)
        .setValue("Trigger Mode")
        .setPosition(640, -40)
        .setSize(80, 20)
        .setColorValue(color(240));

    dlTriggerMode = cp5.addDropdownList("PrimerTriggerMode")
      .setGroup(gPrimer)
      .setId(ID_TRIGGER_MODE)
      .setPosition(680, -40)
      .setSize(90, 120)
      .setItems(TRIGGERMODES);
    style(dlTriggerMode);

    trTriggerThresh = new TriggerRange(cp5, "PrimerTriggerThresh")
      .setGroup(gPrimer)
      .setId(ID_TRIGGER_TRESH)
      .setPosition(4, 15)
      .setLabel("Trigger Thresholds");

    gPatternArgs = cp5.addGroup("PrimerPatternArgs")
      .setGroup(gPrimer)
      .setPosition(0, 75)
      .setSize(800, 100)
      .hideBar()
      .hideArrow();

    gTimings = cp5.addGroup("PrimerTimings")
      .setGroup(gPrimer)
      .setPosition(0, 210)
      .hideBar()
      .hideArrow();

    gColors = cp5.addGroup("PrimerColorGroup")
      .setGroup(gPrimer)
      .setPosition(10, 480)
      .hideBar()
      .hideArrow();

    gPatternArgs.bringToFront();

    // Pattern
    for (int i = 1; i >= 0; i--) {
      tlPatternLabel[i] = cp5.addTextlabel("PrimerPatternLabel" + i)
          .setGroup(gPatternArgs)
          .setValue("Pattern " + (i + 1))
          .setPosition(0, 50 * i)
          .setSize(80, 20)
          .setColorValue(color(240));

      dlPattern[i] = cp5.addDropdownList("PrimerPattern" + i)
        .setGroup(gPatternArgs)
        .setId(ID_PATTERN + i)
        .setPosition(0, 20 + (50 * i))
        .setSize(80, 160)
        .setItems(PATTERNS);
      style(dlPattern[i]);

      for (int j = 0; j < 5; j++) {
        tlArgLabels[i][j] = cp5.addTextlabel("PrimerArgLabels" + i + "." + j)
          .setGroup(gPatternArgs)
          .setValue("Arg " + ((5 * i) + j + 1))
          .setPosition(150 + (137 * j), 50 * i)
          .setSize(100, 20)
          .setColorValue(color(240));

        slArgs[i][j] = cp5.addSlider("PrimerArgs" + i + "." + j)
          .setGroup(gPatternArgs)
          .setId(ID_ARG + (5 * i) + j)
          .setLabel("")
          .setPosition(150 + (137 * j), 20 + (50 * i));
        style(slArgs[i][j], 101, 0, 10);
      }

      for (int j = 0; j < 8; j++) {
        tlTimingLabels[i][j] = cp5.addTextlabel("PrimerTimingLabels" + i + "." + j)
          .setGroup(gTimings)
          .setValue("Timing" + (j + 1))
          .setPosition(450 * i, 30 * j)
          .setSize(200, 20)
          .setColorValue(color(240));

        slTimings[i][j] = cp5.addSlider("PrimerTimings" + i + "." + j)
          .setGroup(gTimings)
          .setId(ID_TIMING + (8 * i) + j)
          .setLabel("")
          .setPosition(150 + (450 * i), 30 * j);
        style(slTimings[i][j], 201, 0, 200);
      }

      slNumColors[i] = cp5.addSlider("PrimerNumColors" + i)
        .setGroup(gColors)
        .setId(ID_NUMCOLORS + i)
        .setLabel("")
        .setPosition(0, 30 + (40 * i));
      style(slNumColors[i], 90, 1, 9);

      for (int j = 0; j < 9; j++) {
        /* bColorBgs[i][j] = cp5.addButton("PrimerColorBgs" + i + "." + j) */
        /*   .setGroup(gColors) */
        /*   .setLabel("") */
        /*   .setSize(34, 34) */
        /*   .setPosition(113 + (40 * j), 23 + (40 * i)) */
        /*   .setColorBackground(color(64)) */
        /*   .setColorForeground(color(192)) */
        /*   .setColorActive(color(240)); */

        bColors[i][j] = cp5.addButton("PrimerColors" + i + "." + j)
          .setGroup(gColors)
          .setId(ID_COLORS + (i * 9) + j)
          .setLabel("")
          .setSize(32, 32)
          .setPosition(114 + (40 * j), 24 + (40 * i))
          .setColorBackground(color(0))
          .setColorForeground(color(0))
          .setColorActive(color(0));
      }
    }

    bSelectedColor = cp5.addButton("PrimerSelectedColor")
      .setGroup(gColors)
      .setSize(40, 40)
      .setColorBackground(color(255))
      .setColorForeground(color(255))
      .setColorActive(color(255))
      .setLabel("")
      .hide();

    gPatternArgs.bringToFront();
    dlTriggerMode.bringToFront();
  }

  public int geta(int addr) {
    if (addr < _TRIGGER_THRESH) {   return triggerMode;
    } else if (addr < _PATTERN) {   return triggerThresh[(addr - _TRIGGER_THRESH + 1) % 2];
    } else if (addr < _ARGS) {      return pattern[addr - _PATTERN];
    } else if (addr < _TIMINGS) {   return args[(addr - _ARGS) / 5][(addr - _ARGS) % 5];
    } else if (addr < _NUMCOLORS) { return timings[(addr - _TIMINGS) / 8][(addr - _TIMINGS) % 8];
    } else if (addr < _COLORS) {    return numColors[addr - _NUMCOLORS];
    } else if (addr < _PADDING) {   return colors[(addr - _COLORS) / 27][((addr - _COLORS) % 27) / 3][(addr - _COLORS) % 3];
    }
    return 0;
  }

  public void seta(int addr, int val) {
    if (addr < _TRIGGER_THRESH) {   setTriggerMode(val);
    } else if (addr < _PATTERN) {   setTriggerThresh((addr - _TRIGGER_THRESH + 1) % 2, val);
    } else if (addr < _ARGS) {      setPattern(addr - _PATTERN, val);
    } else if (addr < _TIMINGS) {   setArgs(addr - _ARGS, val);
    } else if (addr < _NUMCOLORS) { setTimings(addr - _TIMINGS, val);
    } else if (addr < _COLORS) {    setNumColors(addr - _NUMCOLORS, val);
    } else if (addr < _PADDING) {   setColor(addr - _COLORS, val);
    }
  }

  public void deselectColor() {
    bSelectedColor.hide();
    color_set = color_slot = -1;
    viewMode(0);
  }

  public boolean selectColor(int i) {
    return selectColor(i / 9, i % 9);
  }

  public boolean selectColor(int _set, int _color) {
    if (_set < 0 || _set >= 3 || _color < 0 || _color >= numColors[_set]) {
    } else {
      float[] pos = bColors[_set][_color].getPosition();
      color_set = _set;
      color_slot = _color;
      bSelectedColor.setPosition(pos[0] - 4, pos[1] - 4).show();
      bColors[_set][_color].bringToFront();
      mode.gColorEdit.show();
      mode.slColorValues[0].setBroadcast(false).setValue(colors[_set][_color][0]).setBroadcast(true);
      mode.slColorValues[1].setBroadcast(false).setValue(colors[_set][_color][1]).setBroadcast(true);
      mode.slColorValues[2].setBroadcast(false).setValue(colors[_set][_color][2]).setBroadcast(true);
      return true;
    }
    return false;
  }

  public void updateColor(int _set, int _color) {
    int c = translateColor(colors[_set][_color]);
    if (use_gui) {
      bColors[_set][_color].setColorBackground(c);
      bColors[_set][_color].setColorForeground(c);
      bColors[_set][_color].setColorActive(c);

      if (_set == color_set && _color == color_slot) {
        mode.slColorValues[0].setBroadcast(false).setValue(colors[_set][_color][0]).setBroadcast(true);
        mode.slColorValues[1].setBroadcast(false).setValue(colors[_set][_color][1]).setBroadcast(true);
        mode.slColorValues[2].setBroadcast(false).setValue(colors[_set][_color][2]).setBroadcast(true);
      }
    }
  }

  public void updateArg(int _set, int i, String label, int _min, int _max) {
    tlArgLabels[_set][i].setValue(label).show();
    slArgs[_set][i].setBroadcast(false)
      .setRange(_min, _max)
      .setNumberOfTickMarks(_max - _min + 1)
      .showTickMarks(false)
      .setBroadcast(true)
      .show();
  }

  public void updateArg(int _set, int i) {
    tlArgLabels[_set][i].hide();
    slArgs[_set][i].hide();
  }

  public void updateTiming(int _set, int i, String label) {
    tlTimingLabels[_set][i].setValue(label).show();
    slTimings[_set][i].show();
  }

  public void updateTiming(int _set, int i) {
    tlTimingLabels[_set][i].hide();
    slTimings[_set][i].hide();
  }

  public void resetPatternGui(int i) {
    switch (pattern[i]) {
      case 0:
        updateArg(i, 0, "Group Size", 0, 9);
        updateArg(i, 1, "Skip After", 0, 9);
        updateArg(i, 2, "Repeat Group", 1, 100);
        updateArg(i, 3);
        updateArg(i, 4);
        updateTiming(i, 0, "Strobe");
        updateTiming(i, 1, "Blank");
        updateTiming(i, 2, "Tail Blank");
        updateTiming(i, 3);
        updateTiming(i, 4);
        updateTiming(i, 5);
        updateTiming(i, 6);
        updateTiming(i, 7);
        break;
      case 1:
        updateArg(i, 0, "Repeat Strobe", 1, 100);
        updateArg(i, 1, "Repeat Tracer", 1, 100);
        updateArg(i, 2);
        updateArg(i, 3);
        updateArg(i, 4);
        updateTiming(i, 0, "Strobe");
        updateTiming(i, 1, "Blank");
        updateTiming(i, 2, "Tracer Strobe");
        updateTiming(i, 3, "Tracer Blank");
        updateTiming(i, 4, "Split Blank");
        updateTiming(i, 5);
        updateTiming(i, 6);
        updateTiming(i, 7);
        break;
      case 2:
        updateArg(i, 0, "Group Size", 0, 9);
        updateArg(i, 1);
        updateArg(i, 2);
        updateArg(i, 3);
        updateArg(i, 4);
        updateTiming(i, 0, "Strobe");
        updateTiming(i, 1, "Blank");
        updateTiming(i, 2, "Center Strobe");
        updateTiming(i, 3, "Tail Blank");
        updateTiming(i, 4);
        updateTiming(i, 5);
        updateTiming(i, 6);
        updateTiming(i, 7);
        break;
      case 3:
        updateArg(i, 0, "Repeat First", 1, 100);
        updateArg(i, 1, "Repeat Second", 1, 100);
        updateArg(i, 2, "Repeat Third", 1, 100);
        updateArg(i, 3, "Skip Colors", 0, 8);
        updateArg(i, 4, "Use Third", 0, 1);
        updateTiming(i, 0, "First Strobe");
        updateTiming(i, 1, "First Blank");
        updateTiming(i, 2, "Second Strobe");
        updateTiming(i, 3, "Second Blank");
        updateTiming(i, 4, "Third Strobe");
        updateTiming(i, 5, "Third Blank");
        updateTiming(i, 6, "Separating Blank");
        updateTiming(i, 7);
        break;
      case 4:
        updateArg(i, 0, "Group Size", 0, 9);
        updateArg(i, 1, "Skip Between", 0, 9);
        updateArg(i, 2, "Repeat Runner", 1, 100);
        updateArg(i, 3);
        updateArg(i, 4);
        updateTiming(i, 0, "Strobe");
        updateTiming(i, 1, "Blank");
        updateTiming(i, 2, "Runner Strobe");
        updateTiming(i, 3, "Runner Blank");
        updateTiming(i, 4, "Separating Blank");
        updateTiming(i, 5);
        updateTiming(i, 6);
        updateTiming(i, 7);
        break;
      case 5:
        updateArg(i, 0, "Use Steps", 1, 7);
        updateArg(i, 1, "Random Steps", 0, 1);
        updateArg(i, 2, "Random Colors", 0, 1);
        updateArg(i, 3);
        updateArg(i, 4);
        updateTiming(i, 0, "Blank");
        updateTiming(i, 1, "Step 1");
        updateTiming(i, 2, "Step 2");
        updateTiming(i, 3, "Step 3");
        updateTiming(i, 4, "Step 4");
        updateTiming(i, 5, "Step 5");
        updateTiming(i, 6, "Step 6");
        updateTiming(i, 7, "Step 7");
        break;
      case 6:
        updateArg(i, 0, "Random Colors", 0, 1);
        updateArg(i, 1, "Time Multiplier", 1, 10);
        updateArg(i, 2);
        updateArg(i, 3);
        updateArg(i, 4);
        updateTiming(i, 0, "Strobe Low");
        updateTiming(i, 1, "Strobe High");
        updateTiming(i, 2, "Blank Low");
        updateTiming(i, 3, "Blank High");
        updateTiming(i, 4);
        updateTiming(i, 5);
        updateTiming(i, 6);
        updateTiming(i, 7);
        break;
      case 7:
        updateArg(i, 0, "Steps", 0, 100);
        updateArg(i, 1, "Strobe/Blank", 0, 1);
        updateArg(i, 2, "Up/Down/Both", 0, 2);
        updateArg(i, 3);
        updateArg(i, 4);
        updateTiming(i, 0, "Strobe");
        updateTiming(i, 1, "Blank");
        updateTiming(i, 2, "Flux");
        updateTiming(i, 3);
        updateTiming(i, 4);
        updateTiming(i, 5);
        updateTiming(i, 6);
        updateTiming(i, 7);
        break;
    }
  }

  public void resetArgsAndTimings(int i) {
    switch (pattern[i]) {
      case 0:
        setArgs((5 * i) + 0, 0);
        setArgs((5 * i) + 1, 0);
        setArgs((5 * i) + 2, 0);
        setArgs((5 * i) + 3, 0);
        setArgs((5 * i) + 4, 0);
        setTimings(i, 0, 5);
        setTimings(i, 1, 8);
        setTimings(i, 2, 0);
        setTimings(i, 3, 0);
        setTimings(i, 4, 0);
        setTimings(i, 5, 0);
        setTimings(i, 6, 0);
        setTimings(i, 7, 0);
        break;
      case 1:
        setArgs((5 * i) + 0, 1);
        setArgs((5 * i) + 1, 1);
        setArgs((5 * i) + 2, 0);
        setArgs((5 * i) + 3, 0);
        setArgs((5 * i) + 4, 0);
        setTimings(i, 0, 5);
        setTimings(i, 1, 1);
        setTimings(i, 2, 20);
        setTimings(i, 3, 0);
        setTimings(i, 4, 0);
        setTimings(i, 5, 0);
        setTimings(i, 6, 0);
        setTimings(i, 7, 0);
        break;
      case 2:
        setArgs((5 * i) + 0, 0);
        setArgs((5 * i) + 1, 0);
        setArgs((5 * i) + 2, 0);
        setArgs((5 * i) + 3, 0);
        setArgs((5 * i) + 4, 0);
        setTimings(i, 0, 2);
        setTimings(i, 1, 0);
        setTimings(i, 2, 5);
        setTimings(i, 3, 50);
        setTimings(i, 4, 0);
        setTimings(i, 5, 0);
        setTimings(i, 6, 0);
        setTimings(i, 7, 0);
        break;
      case 3:
        setArgs((5 * i) + 0, 2);
        setArgs((5 * i) + 1, 2);
        setArgs((5 * i) + 2, 0);
        setArgs((5 * i) + 3, 0);
        setArgs((5 * i) + 4, 0);
        setTimings(i, 0, 5);
        setTimings(i, 1, 8);
        setTimings(i, 2, 1);
        setTimings(i, 3, 12);
        setTimings(i, 4, 5);
        setTimings(i, 5, 0);
        setTimings(i, 6, 0);
        setTimings(i, 7, 0);
        break;
      case 4:
        setArgs((5 * i) + 0, 0);
        setArgs((5 * i) + 1, 0);
        setArgs((5 * i) + 2, 5);
        setArgs((5 * i) + 3, 0);
        setArgs((5 * i) + 4, 0);
        setTimings(i, 0, 5);
        setTimings(i, 1, 0);
        setTimings(i, 2, 1);
        setTimings(i, 3, 12);
        setTimings(i, 4, 12);
        setTimings(i, 5, 0);
        setTimings(i, 6, 0);
        setTimings(i, 7, 0);
        break;
      case 5:
        setArgs((5 * i) + 0, 5);
        setArgs((5 * i) + 1, 0);
        setArgs((5 * i) + 2, 0);
        setArgs((5 * i) + 3, 0);
        setArgs((5 * i) + 4, 0);
        setTimings(i, 0, 10);
        setTimings(i, 1, 2);
        setTimings(i, 2, 4);
        setTimings(i, 3, 6);
        setTimings(i, 4, 8);
        setTimings(i, 5, 10);
        setTimings(i, 6, 0);
        setTimings(i, 7, 0);
        break;
      case 6:
        setArgs((5 * i) + 0, 1);
        setArgs((5 * i) + 1, 4);
        setArgs((5 * i) + 2, 0);
        setArgs((5 * i) + 3, 0);
        setArgs((5 * i) + 4, 0);
        setTimings(i, 0, 1);
        setTimings(i, 1, 5);
        setTimings(i, 2, 5);
        setTimings(i, 3, 5);
        setTimings(i, 4, 0);
        setTimings(i, 5, 0);
        setTimings(i, 6, 0);
        setTimings(i, 7, 0);
        break;
      case 7:
        setArgs((5 * i) + 0, 10);
        setArgs((5 * i) + 1, 1);
        setArgs((5 * i) + 2, 2);
        setArgs((5 * i) + 3, 0);
        setArgs((5 * i) + 4, 0);
        setTimings(i, 0, 1);
        setTimings(i, 1, 0);
        setTimings(i, 2, 1);
        setTimings(i, 3, 0);
        setTimings(i, 4, 0);
        setTimings(i, 5, 0);
        setTimings(i, 6, 0);
        setTimings(i, 7, 0);
        break;
    }
  }

  public void setTriggerMode(int val) {
    if (oob(val, 0, 5)) { return; };

    triggerMode = val;
    if (use_gui) {
      dlTriggerMode.setBroadcast(false).setValue(triggerMode).setBroadcast(true);
      dlTriggerMode.setCaptionLabel(dlTriggerMode.getItem(triggerMode).get("text").toString());
      trTriggerThresh.setTriggerMode(triggerMode);
    }
  }

  public void sendTriggerMode() {
    sendCommand(SER_WRITE, _TRIGGER_MODE, triggerMode);
  }

  public void setTriggerThresh(float[] val) {
    triggerThresh[0] = (int)val[0];
    triggerThresh[1] = (int)val[1];

    if (use_gui) {
      trTriggerThresh.setBroadcast(false).setArrayValue(triggerThresh).setBroadcast(true);
    }
  }

  public void setTriggerThresh(int i, int val) {
    if (oob(i, 0, 1) || oob(val, 0, 32)) { return; }
    triggerThresh[i] = val;

    if (use_gui) {
      trTriggerThresh.setBroadcast(false).setArrayValue(triggerThresh).setBroadcast(true);
    }
  }

  public void sendTriggerThresh() {
    sendCommand(SER_WRITE, _TRIGGER_THRESH + 0, triggerThresh[1]);
    sendCommand(SER_WRITE, _TRIGGER_THRESH + 1, triggerThresh[0]);
  }


  // Pattern
  public void setPattern(int i, int val) {
    if (oob(i, 0, 1) || oob(val, 0, 6)) { return; }
    int old = pattern[i];
    pattern[i] = val;
    if (use_gui) {
      dlPattern[i].setBroadcast(false).setValue(pattern[i]).setBroadcast(true);
      dlPattern[i].setCaptionLabel(dlPattern[i].getItem(val).get("text").toString());
      resetPatternGui(i);
      if (old != pattern[i]) {
        resetArgsAndTimings(i);
        mode.sendMode();
      }
    }
  }

  public void sendPattern(int i) {
    sendCommand(SER_WRITE, _PATTERN + i, pattern[i]);
  }

  // Args
  public void setArgs(int i, int val) {
    if (oob(i, 0, 9)) { return; }

    args[i / 5][i % 5] = val;
    if (use_gui) {
      slArgs[i / 5][i % 5].setBroadcast(false).setValue(args[i / 5][i % 5]).setBroadcast(true);
    }
  }

  public void sendArgs(int i) {
    sendCommand(SER_WRITE, _ARGS + i, args[i / 5][i % 5]);
  }

  // Timings
  public void setTimings(int i, int val) {
    setTimings(i / 8, i % 8, val);
  }

  public void setTimings(int x, int y, int val) {
    if (oob(x, 0, 1) || oob(y, 0, 7)) { return; }

    timings[x][y] = val;
    if (use_gui) {
      slTimings[x][y].setBroadcast(false).setValue(timings[x][y]).setBroadcast(true);
    }
  }

  public void sendTimings(int i) {
    sendTimings(i / 8, i % 8);
  }

  public void sendTimings(int x, int y) {
    sendCommand(SER_WRITE, _TIMINGS + (8 * x) + y, timings[x][y]);
  }

  // Num colors
  public void setNumColors(int i, int val) {
    if (oob(i, 0, 1) || oob(val, 1, 9)) { return; }

    numColors[i] = val;
    if (color_set == i && color_slot >= numColors[i]) {
      deselectColor();
    }
    if (use_gui) {
      for (int j = 0; j < 9; j++) {
        if (j < numColors[i]) { bColors[i][j].show(); } //bColorBgs[i][j].show(); }
        else                  { bColors[i][j].hide(); } //bColorBgs[i][j].hide(); }
      }
      slNumColors[i].setBroadcast(false).setValue(numColors[i]).setBroadcast(true);
    }
  }

  public void sendNumColors(int i) {
    sendCommand(SER_WRITE, _NUMCOLORS + i, numColors[i]);
  }

  // Colors
  public void setColor(int _set, int _color, int _channel, int val) {
    if (oob(_set, 0, 1) || oob(_color, 0, 8) || oob(_channel, 0, 2)) { return; }

    colors[_set][_color][_channel] = val;
    updateColor(_set, _color);
  }

  public void setColor(int _set, int _color, int[] val) {
    if (oob(_set, 0, 1) || oob(_color, 0, 8)) { return; }

    colors[_set][_color][0] = val[0];
    colors[_set][_color][1] = val[1];
    colors[_set][_color][2] = val[2];
    updateColor(_set, _color);
  }

  public void setColor(int i, int val) {
    setColor(i / 27, (i % 27) / 3, i % 3, val);
  }

  public void sendColor(int _set, int _color, int _channel) {
    if (oob(_set, 0, 1) || oob(_color, 0, 8) || oob(_channel, 0, 2)) { return; }
    sendCommand(SER_WRITE, _COLORS + (_set * 27) + (_color * 3) + _channel, colors[_set][_color][_channel]);
  }

  public void sendColor(int _set, int _color) {
    if (oob(_set, 0, 1) || oob(_color, 0, 8)) { return; }
    sendColor(_set, _color, 0);
    sendColor(_set, _color, 1);
    sendColor(_set, _color, 2);
  }

  //********************************************************************************
  //** JSON
  //********************************************************************************
  public void fromJSON(JSONObject j) {
    triggerMode = j.getInt("trigger_mode");
    setTriggerThresh(j.getJSONArray("trigger_thresh"));
    setPattern(j.getJSONArray("pattern"));
    setArgs(j.getJSONArray("args"));
    setTimings(j.getJSONArray("timings"));
    setNumColors(j.getJSONArray("num_colors"));
    setColors(j.getJSONArray("colors"));
  }

  public JSONObject getJSON() {
    JSONObject jo = new JSONObject();
    jo.setInt("trigger_mode", triggerMode);
    jo.setJSONArray("trigger_thresh", getTriggerThresh());
    jo.setJSONArray("pattern", getPattern());
    jo.setJSONArray("args", getArgs());
    jo.setJSONArray("timings", getTimings());
    jo.setJSONArray("num_colors", getNumColors());
    jo.setJSONArray("colors", getColors());
    return jo;
  }

  public JSONArray getTriggerThresh() {
    JSONArray ja = new JSONArray();
    ja.setInt(0, triggerThresh[0]);
    ja.setInt(1, triggerThresh[1]);
    return ja;
  }

  public JSONArray getPattern() {
    JSONArray ja = new JSONArray();
    ja.setInt(0, pattern[0]);
    ja.setInt(1, pattern[1]);
    return ja;
  }

  public JSONArray getArgs() {
    JSONArray ja = new JSONArray();
    for (int i = 0; i < 2; i++) {
      JSONArray ja1 = new JSONArray();
      for (int j = 0; j < 5; j++) {
        ja1.setInt(j, args[i][j]);
      }
      ja.setJSONArray(i, ja1);
    }
    return ja;
  }

  public JSONArray getTimings() {
    JSONArray ja = new JSONArray();
    for (int i = 0; i < 2; i++) {
      JSONArray ja1 = new JSONArray();
      for (int j = 0; j < 8; j++) {
        ja1.setInt(j, timings[i][j]);
      }
      ja.setJSONArray(i, ja1);
    }
    return ja;
  }

  public JSONArray getNumColors() {
    JSONArray ja = new JSONArray();
    for (int i = 0; i < 2; i++) {
      ja.setInt(i, numColors[i]);
    }
    return ja;
  }

  public JSONArray getColors() {
    JSONArray ja = new JSONArray();
    for (int i = 0; i < 2; i++) {
      JSONArray ja1 = new JSONArray();
      for (int j = 0; j < 9; j++) {
        JSONArray ja2 = new JSONArray();
        for (int k = 0; k < 3; k++) {
          if (j < numColors[i]) {
            ja2.setInt(k, colors[i][j][k]);
          } else {
            ja2.setInt(k, 0);
          }
        }
        ja1.setJSONArray(j, ja2);
      }
      ja.setJSONArray(i, ja1);
    }
    return ja;
  }

  public void setTriggerThresh(JSONArray ja) {
    setTriggerThresh(0, ja.getInt(0));
    setTriggerThresh(1, ja.getInt(1));
  }

  public void setPattern(JSONArray ja) {
    setPattern(0, ja.getInt(0));
    setPattern(1, ja.getInt(1));
  }

  public void setArgs(JSONArray ja) {
    for (int i = 0; i < 2; i++) {
      JSONArray ja1 = ja.getJSONArray(i);
      for (int j = 0; j < 5; j++) {
        try {
          setArgs(i, ja1.getInt(i));
        } catch (Exception ex) {
          setArgs((i * 5) + j, 0);
        }
      }
    }
  }

  public void setTimings(JSONArray ja) {
    for (int i = 0; i < 2; i++) {
      JSONArray ja1 = ja.getJSONArray(i);
      for (int j = 0; j < 8; j++) {
        try {
          setTimings(i, j, ja1.getInt(j));
        } catch (Exception ex) {
          setTimings(i, j, 0);
        }
      }
    }
  }

  public void setNumColors(JSONArray ja) {
    for (int i = 0; i < 2; i++) {
      setNumColors(i, ja.getInt(i));
    }
  }

  public void setColors(JSONArray ja) {
    for (int _set = 0; _set < 2; _set++) {
      JSONArray ja1 = ja.getJSONArray(_set);
      for (int _color = 0; _color < 9; _color++) {
        JSONArray ja2 = ja1.getJSONArray(_color);
        for (int _channel = 0; _channel < 3; _channel++) {
          setColor(_set, _color, _channel, ja2.getInt(_channel));
        }
      }
    }
  }
}










public class ThreshRange extends Controller<ThreshRange> {
  int HANDLESIZE = 6;
  int HANDLESIZE2 = 3;

  int mode = -1;
  int _myMin = 0;
  int _myMax = 32;

  String myName;
  Label[] _myValueLabels = new Label[5];
  int[] _myHandles = new int[4];
  boolean isDragging;


  public ThreshRange(ControlP5 _cp5, String _name) {
    super(_cp5, _cp5.getDefaultTab(), _name, 0, 0, 792, 20);
    myName = _name;
    _cp5.register(_cp5.papplet, _name, this);
    makeLabels();
    _myArrayValue = new float[4];
    float[] _d = {4, 14, 18, 28};
    setArrayValue(_d);
    update();
  }

  protected void makeLabels() {
    _myCaptionLabel = new controlP5.Label(cp5, myName)
      .setColor(240)
      .toUpperCase(false)
      .setFont(createFont("Comfortaa-Bold", 18))
      .align(CENTER, TOP_OUTSIDE);
    _myCaptionLabel.getStyle().setPadding(4, 4, 4, 4)
      .setMargin(-4, 0, 0, 0);

    String[] label_names = {"ZeroLabel", "MinALabel", "MaxALabel", "MinBLabel", "MaxBLabel"};
    int[] aligns = {LEFT, LEFT, CENTER, RIGHT, RIGHT};
    int[] paddings = {0, 160, 0, 160, 0};
    for (int i = 0; i < 5; i++) {
      _myValueLabels[i] = new controlP5.Label(cp5, myName + label_names[i])
        .setColor(240)
        .toUpperCase(false)
        .set("")
        .align(aligns[i], BOTTOM_OUTSIDE)
        .setPadding(paddings[i], 5);
    }
  }

  public int getMode() {
    final float posX = x(_myParent.getAbsolutePosition()) + x(position);
    final float posY = y(_myParent.getAbsolutePosition()) + y(position);
    final float mX = mouseX - posX;
    final float mY = mouseY - posY;

    if (mY < 0 || mY > getHeight()) {
      return -1;
    }

    for (int i = 0; i < 4; i++) {
      if (mX > _myHandles[i] - HANDLESIZE2 && mX < _myHandles[i] + HANDLESIZE2) {
        return i;
      }
    }
    return -1;
  }

  @Override public void mousePressed() {
    mode = getMode();
  }

  public ThreshRange updateInternalEvents(PApplet theApplet) {
    if (isVisible) {
      int c = mouseX - pmouseX;
      if (c == 0) { return this; }
      if (isMousePressed && !cp5.isAltDown()) {
        if (mode >= 0 && mode < 4) {
          updateHandle(mode, _myHandles[mode] + c);
          updateLabels();
        }
      }
    }
    return this;
  }

  public float getValue(int i) {
    return _myArrayValue[i];
  }

  public ThreshRange setValue(int i, float theValue, boolean isUpdate) {
    if (i >= 0 && i < 4) {
      _myArrayValue[i] = theValue;
    }
    if (isUpdate) {
      updateHandleByValue(i);
      update();
    }
    return this;
  }

  public ThreshRange setValue(int i, float theValue) {
    return setValue(i, theValue, true);
  }

  public float[] getArrayValue() {
    return _myArrayValue;
  }

  public ThreshRange setArrayValue(int[] theArray) {
    for (int i = 0; i < 4; i++) {
      setValue(i, theArray[i], false);
    }
    update();
    return this;
  }

  // Call this to update handles based on value
  public void updateHandleByValue(int i) {
    _myHandles[i] = ((int)_myArrayValue[i] * (HANDLESIZE * 4)) + (HANDLESIZE * i) + HANDLESIZE2;
  }

  public void updateHandlesByValue() {
    for (int i = 0; i < 4; i++) { updateHandleByValue(i); }
  }

  // Call this when the GUI updates the position - it'll update the value as well
  public void updateHandle(int i, int v) {
    int[] tabs = {0, _myHandles[0], _myHandles[1], _myHandles[2], _myHandles[3], getWidth()};
    _myHandles[i] = PApplet.max(tabs[i] + HANDLESIZE2, PApplet.min(tabs[i + 2] - HANDLESIZE2, v));
    setValue(i, _myHandles[i] / (HANDLESIZE * 4), false);
  }

  public void updateLabels() {
    String[] labels = {"A", "A->B", "B", "B->C", "C"};
    int[] vals = {0, (int)_myArrayValue[0], (int)_myArrayValue[1], (int)_myArrayValue[2], (int)_myArrayValue[3], 32};
    for (int i = 0; i < 5; i++) {
      _myValueLabels[i].set(labels[i] + ": " + vals[i] + " - " + vals[i + 1]);
    }
  }

  @Override public ThreshRange update() {
    updateHandlesByValue();
    updateLabels();
    return this;
  }


  //********************************************************************************
  // GUI Stuff
  //********************************************************************************
  class ThreshRangeView implements ControllerView<ThreshRange> {
    public void display(PGraphics theGraphics, ThreshRange theController) {
      int hl = getMode();
      theGraphics.pushMatrix();

      theGraphics.fill(0);
      theGraphics.stroke(64);
      theGraphics.rect(0, 0, getWidth(), getHeight());

      int[] colors = {color(255, 0, 0), color(255, 255, 0), color(0, 255, 0), color(0, 255, 255), color(0, 0, 255)};
      int[] tabs = {0, _myHandles[0], _myHandles[1], _myHandles[2], _myHandles[3], getWidth()};
      for (int i = 0; i < 5; i++) {
        theGraphics.fill(colors[i]);
        theGraphics.rect(tabs[i], 0, tabs[i + 1] - tabs[i], getHeight());
      }

      for (int i = 0; i < 4; i++) {
        theGraphics.fill((hl == i) ? 128 : 255);
        theGraphics.stroke((hl == i) ? 255 : 0);
        theGraphics.rect(_myHandles[i] - HANDLESIZE2, 0, HANDLESIZE, getHeight());
      }

      if (isLabelVisible) {
        _myCaptionLabel.draw(theGraphics, 0, 0, theController);
        for (int i = 0; i < 5; i++) {
          _myValueLabels[i].draw(theGraphics, 0, 0, theController);
        }
      }

      theGraphics.popMatrix();
      theGraphics.noStroke();
    }
  }

  @Override public void mouseReleased() {
    isDragging = false;
    update();
    mode = -1;
  }

  @Override public void mouseReleasedOutside() {
    mouseReleased();
  }

  @Override public void onLeave() {
    isDragging = false;
  }

  @Override public ThreshRange updateDisplayMode(int theMode) {
    _myDisplayMode = theMode;
    switch (theMode) {
      case (DEFAULT):
        _myControllerView = new ThreshRangeView();
        break;
      case (SPRITE):
        _myControllerView = new ThreshRangeSpriteView();
        break;
      case (IMAGE):
        _myControllerView = new ThreshRangeImageView();
        break;
      case (CUSTOM):
      default:
        break;
    }
    return this;
  }

  class ThreshRangeImageView implements ControllerView<ThreshRange> {
    public void display(PGraphics theGraphics, ThreshRange theController) {
      ControlP5.logger().log(Level.INFO, "ThreshRangeImageDisplay not implemented.");
    }
  }

  class ThreshRangeSpriteView implements ControllerView<ThreshRange> {
    public void display(PGraphics theGraphics, ThreshRange theController) {
      ControlP5.logger().log(Level.INFO, "ThreshRangeSpriteDisplay not available.");
    }
  }

  @Override public String toString() {
    return "type:\tThreshRange\n" + super.toString();
  }
}










public class TriggerRange extends Controller<TriggerRange> {
  int HANDLESIZE = 12;
  int HANDLESIZE2 = 6;

  int mode = -1;
  int _myMin = 0;
  int _myMax = 32;
  int triggerMode = 0;

  String myName;
  Label[] _myValueLabels = new Label[2];
  int[] _myHandles = new int[2];
  boolean isDragging;


  public TriggerRange(ControlP5 _cp5, String _name) {
    super(_cp5, _cp5.getDefaultTab(), _name, 0, 0, 792, 20);
    myName = _name;
    _cp5.register(_cp5.papplet, _name, this);
    makeLabels();
    _myArrayValue = new float[2];
    float[] _d = {14, 18};
    setArrayValue(_d);
    update();
  }

  protected void makeLabels() {
    _myCaptionLabel = new controlP5.Label(cp5, myName)
      .setColor(240)
      .toUpperCase(false)
      .setFont(createFont("Comfortaa-Bold", 18))
      .align(CENTER, TOP_OUTSIDE);
    _myCaptionLabel.getStyle().setPadding(4, 4, 4, 4)
      .setMargin(-4, 0, 0, 0);

    String[] label_names = {"MinLabel", "MaxLabel"};
    int[] aligns = {LEFT, RIGHT};
    int[] paddings = {0, 0};
    for (int i = 0; i < 2; i++) {
      _myValueLabels[i] = new controlP5.Label(cp5, myName + label_names[i])
        .setColor(240)
        .toUpperCase(false)
        .set("")
        .align(aligns[i], BOTTOM_OUTSIDE)
        .setPadding(paddings[i], 5);
    }
  }

  public int getMode() {
    final float posX = x(_myParent.getAbsolutePosition()) + x(position);
    final float posY = y(_myParent.getAbsolutePosition()) + y(position);
    final float mX = mouseX - posX;
    final float mY = mouseY - posY;

    if (mY < 0 || mY > getHeight()) {
      return -1;
    }

    for (int i = 0; i < 2; i++) {
      if (mX > _myHandles[i] - HANDLESIZE2 && mX < _myHandles[i] + HANDLESIZE2) {
        return i;
      }
    }
    return -1;
  }

  public TriggerRange setTriggerMode(int v) {
    triggerMode = v;
    return update();
  }

  public TriggerRange updateInternalEvents(PApplet theApplet) {
    if (isVisible) {
      int c = mouseX - pmouseX;
      if (c == 0) { return this; }
      if (isMousePressed && !cp5.isAltDown()) {
        if (mode >= 0 && mode < 2) {
          updateHandle(mode, _myHandles[mode] + c);
          updateLabels();
        }
      }
    }
    return this;
  }

  public float getValue(int i) {
    return _myArrayValue[i];
  }

  public TriggerRange setValue(int i, float theValue, boolean isUpdate) {
    if (i >= 0 && i < 2) {
      _myArrayValue[i] = theValue;
    }
    if (isUpdate) {
      updateHandleByValue(i);
      update();
    }
    return this;
  }

  public TriggerRange setValue(int i, float theValue) {
    return setValue(i, theValue, true);
  }

  public float[] getArrayValue() {
    return _myArrayValue;
  }

  public TriggerRange setArrayValue(int[] theArray) {
    for (int i = 0; i < 2; i++) {
      setValue(i, theArray[i], false);
    }
    update();
    return this;
  }

  // Call this to update handles based on value
  public void updateHandleByValue(int i) {
    _myHandles[i] = ((int)_myArrayValue[i] * (HANDLESIZE * 2)) + (HANDLESIZE * i) + HANDLESIZE2;
  }

  public void updateHandlesByValue() {
    for (int i = 0; i < 2; i++) { updateHandleByValue(i); }
  }

  // Call this when the GUI updates the position - it'll update the value as well
  public void updateHandle(int i, int v) {
    int[] tabs = {0, _myHandles[0], _myHandles[1], getWidth()};
    _myHandles[i] = PApplet.max(tabs[i] + HANDLESIZE2, PApplet.min(tabs[i + 2] - HANDLESIZE2, v));
    setValue(i, _myHandles[i] / (HANDLESIZE * 2), false);
  }

  public void updateLabels() {
    if (triggerMode < 1 || triggerMode > 4) {
    } else {
      String[] labels = {"Trigger A", "Trigger B"};
      int v;
      for (int i = 0; i < 2; i++) {
        if (triggerMode == 1) {
          v = (int)_myArrayValue[i];
        } else {
          v = ((int)_myArrayValue[i] * 5) - 80;
        }
        _myValueLabels[i].set(labels[i] + ": " + v);
      }
    }

  }

  @Override public TriggerRange update() {
    updateHandlesByValue();
    updateLabels();
    return this;
  }


  //********************************************************************************
  // GUI Stuff
  //********************************************************************************
  class TriggerRangeView implements ControllerView<TriggerRange> {
    public void display(PGraphics theGraphics, TriggerRange theController) {
      if (triggerMode < 1 || triggerMode > 4) {
        return;
      }

      int hl = getMode();
      theGraphics.pushMatrix();

      theGraphics.fill(0);
      theGraphics.stroke(64);
      theGraphics.rect(0, 0, getWidth(), getHeight());

      int[] colors = {color(255, 0, 0), color(255, 0, 255), color(0, 0, 255)};
      int[] tabs = {0, _myHandles[0], _myHandles[1], getWidth()};
      for (int i = 0; i < 3; i++) {
        theGraphics.fill(colors[i]);
        theGraphics.rect(tabs[i], 0, tabs[i + 1] - tabs[i], getHeight());
      }

      for (int i = 0; i < 2; i++) {
        theGraphics.fill((hl == i) ? 128 : 255);
        theGraphics.stroke((hl == i) ? 255 : 0);
        theGraphics.rect(_myHandles[i] - HANDLESIZE2, 0, HANDLESIZE, getHeight());
      }

      if (isLabelVisible) {
        _myCaptionLabel.draw(theGraphics, 0, 0, theController);
        for (int i = 0; i < 2; i++) {
          _myValueLabels[i].draw(theGraphics, 0, 0, theController);
        }
      }

      theGraphics.popMatrix();
      theGraphics.noStroke();
    }
  }

  @Override public void mousePressed() {
    mode = getMode();
  }

  @Override public void mouseReleased() {
    isDragging = false;
    update();
    mode = -1;
  }

  @Override public void mouseReleasedOutside() {
    mouseReleased();
  }

  @Override public void onLeave() {
    isDragging = false;
  }

  @Override public TriggerRange updateDisplayMode(int theMode) {
    _myDisplayMode = theMode;
    switch (theMode) {
      case (DEFAULT):
        _myControllerView = new TriggerRangeView();
        break;
      case (SPRITE):
        _myControllerView = new TriggerRangeSpriteView();
        break;
      case (IMAGE):
        _myControllerView = new TriggerRangeImageView();
        break;
      case (CUSTOM):
      default:
        break;
    }
    return this;
  }

  class TriggerRangeImageView implements ControllerView<TriggerRange> {
    public void display(PGraphics theGraphics, TriggerRange theController) {
      ControlP5.logger().log(Level.INFO, "TriggerRangeImageDisplay not implemented.");
    }
  }

  class TriggerRangeSpriteView implements ControllerView<TriggerRange> {
    public void display(PGraphics theGraphics, TriggerRange theController) {
      ControlP5.logger().log(Level.INFO, "TriggerRangeSpriteDisplay not available.");
    }
  }

  @Override public String toString() {
    return "type:\tTriggerRange\n" + super.toString();
  }
}
class VectrMode {
  boolean use_gui = true;

  static final int _PATTERN = 1;
  static final int _ARGS = 2;
  static final int _PATTERNTHRESH = 7;
  static final int _TIMINGS = 11;
  static final int _COLORTHRESH = 35;
  static final int _NUMCOLORS = 39;
  static final int _COLORS = 42;
  static final int _PADDING = 123;

  int       pattern;
  int[]     args = new int[5];
  int[]     patternThresh = new int[4];
  int[][]   timings = new int[3][8];
  int[]     colorThresh = new int[4];
  int[]     numColors = new int[3];
  int[][][] colors = new int[3][9][3];

  //********************************************************************************
  // GUI Elements
  //********************************************************************************
  Group gVectr;
  Group gPatternArgs;
  Group gTimings;
  Group gColors;

  Textlabel tlPatternLabel;
  ThreshRange trPatternThresh;
  ThreshRange trColorThresh;
  DropdownList dlPattern;
  Textlabel[] tlArgLabels = new Textlabel[5];
  Slider[] slArgs = new Slider[5];
  Textlabel[] tlTimingLabels = new Textlabel[8];
  Slider[][] slTimings = new Slider[3][8];
  Slider[] slNumColors = new Slider[3];
  Button[][] bColors = new Button[3][9];
  /* Button[][] bColorBgs = new Button[3][9]; */

  Button bSelectedColor;
  int color_set = -1;
  int color_slot = -1;

  VectrMode() {
    use_gui = false;
  }

  VectrMode(Group g) {
    gVectr = g;

    gPatternArgs = cp5.addGroup("VectrPatternArgs")
      .setGroup(gVectr)
      .setPosition(0, 0)
      .setSize(800, 50)
      .hideBar()
      .hideArrow();

    trPatternThresh = new ThreshRange(cp5, "VectrPatternThresh")
      .setGroup(gVectr)
      .setId(ID_PATTERN_TRESH)
      .setPosition(4, 80)
      .setLabel("Pattern Thresholds");

    gTimings = cp5.addGroup("VectrTimings")
      .setGroup(gVectr)
      .setPosition(0, 145)
      .hideBar()
      .hideArrow();

    trColorThresh = new ThreshRange(cp5, "VectrColorThresh")
      .setGroup(gVectr)
      .setId(ID_COLOR_TRESH)
      .setPosition(4, 415)
      .setLabel("Color Thresholds");

    gColors = cp5.addGroup("VectrColorGroup")
      .setGroup(gVectr)
      .setPosition(10, 480)
      .hideBar()
      .hideArrow();

    tlPatternLabel = cp5.addTextlabel("VectrPatternLabel")
        .setGroup(gPatternArgs)
        .setValue("Pattern")
        .setPosition(0, 0)
        .setSize(80, 20)
        .setColorValue(color(240));

    dlPattern = cp5.addDropdownList("VectrPattern")
      .setGroup(gPatternArgs)
      .setId(ID_PATTERN)
      .setPosition(0, 20)
      .setSize(80, 160)
      .setItems(PATTERNS);
    style(dlPattern);

    for (int i = 0; i < 5; i++) {
      tlArgLabels[i] = cp5.addTextlabel("VectrArgLabels" + i)
        .setGroup(gPatternArgs)
        .setValue("Arg " + (i + 1))
        .setPosition(150 + (137 * i), 0)
        .setSize(100, 20)
        .setColorValue(color(240));

      slArgs[i] = cp5.addSlider("VectrArgs" + i)
        .setGroup(gPatternArgs)
        .setId(ID_ARG + i)
        .setLabel("")
        .setPosition(150 + (137 * i), 20);
      style(slArgs[i], 101, 0, 10);
    }

    for (int j = 0; j < 8; j++) {
      tlTimingLabels[j] = cp5.addTextlabel("VectrTimingLabels" + j)
        .setGroup(gTimings)
        .setValue("Timing" + (j + 1))
        .setPosition(0, 30 * j)
        .setSize(200, 20)
        .setColorValue(color(240));

      for (int i = 0; i < 3; i++) {
        slTimings[i][j] = cp5.addSlider("VectrTimings" + i + "." + j)
          .setGroup(gTimings)
          .setId(ID_TIMING + (8 * i) + j)
          .setLabel("")
          .setPosition(150 + (225 * i), 30 * j);
        style(slTimings[i][j], 201, 0, 200);
      }
    }

    for (int i = 0; i < 3; i++) {
      slNumColors[i] = cp5.addSlider("VectrNumColors" + i)
        .setGroup(gColors)
        .setId(ID_NUMCOLORS + i)
        .setLabel("")
        .setPosition(0, 10 + (40 * i));
      style(slNumColors[i], 90, 1, 9);

      for (int j = 0; j < 9; j++) {
        /* bColorBgs[i][j] = cp5.addButton("VectrColorBgs" + i + "." + j) */
        /*   .setGroup(gColors) */
        /*   .setLabel("") */
        /*   .setSize(34, 34) */
        /*   .setPosition(113 + (40 * j), 3 + (40 * i)) */
        /*   .setColorBackground(color(64)) */
        /*   .setColorForeground(color(192)) */
        /*   .setColorActive(color(240)); */

        bColors[i][j] = cp5.addButton("VectrColors" + i + "." + j)
          .setGroup(gColors)
          .setId(ID_COLORS + (i * 9) + j)
          .setLabel("")
          .setSize(32, 32)
          .setPosition(114 + (40 * j), 4 + (40 * i));
      }
    }

    bSelectedColor = cp5.addButton("VectrSelectedColor")
      .setGroup(gColors)
      .setSize(40, 40)
      .setColorBackground(color(255))
      .setColorForeground(color(255))
      .setColorActive(color(255))
      .setLabel("")
      .hide();

    gPatternArgs.bringToFront();
  }

  public int geta(int addr) {
    if (addr < _ARGS) {                 return pattern;
    } else if (addr < _PATTERNTHRESH) { return args[addr - _ARGS];
    } else if (addr < _TIMINGS) {       return patternThresh[addr - _PATTERNTHRESH];
    } else if (addr < _COLORTHRESH) {   return timings[(addr - _TIMINGS) / 8][(addr - _TIMINGS) % 8];
    } else if (addr < _NUMCOLORS) {     return colorThresh[addr - _COLORTHRESH];
    } else if (addr < _COLORS) {        return numColors[addr - _NUMCOLORS];
    } else if (addr < _PADDING) {       return colors[(addr - _COLORS) / 27][((addr - _COLORS) % 27) / 3][(addr - _COLORS) % 3];
    }
    return 0;
  }

  public void seta(int addr, int val) {
    if (addr < _ARGS) {                 setPattern(val);
    } else if (addr < _PATTERNTHRESH) { setArgs(addr - _ARGS, val);
    } else if (addr < _TIMINGS) {       setPatternThresh(addr - _PATTERNTHRESH, val);
    } else if (addr < _COLORTHRESH) {   setTimings(addr - _TIMINGS, val);
    } else if (addr < _NUMCOLORS) {     setColorThresh(addr - _COLORTHRESH, val);
    } else if (addr < _COLORS) {        setNumColors(addr - _NUMCOLORS, val);;
    } else if (addr < _PADDING) {       setColor(addr - _COLORS, val);
    }
  }

  public void deselectColor() {
    bSelectedColor.hide();
    color_set = color_slot = -1;
    viewMode(0);
  }

  public boolean selectColor(int i) {
    return selectColor(i / 9, i % 9);
  }

  public boolean selectColor(int _set, int _color) {
    if (_set < 0 || _set >= 3 || _color < 0 || _color >= numColors[_set]) {
    } else {
      float[] pos = bColors[_set][_color].getPosition();
      color_set = _set;
      color_slot = _color;
      bSelectedColor.setPosition(pos[0] - 4, pos[1] - 4).show();
      bColors[_set][_color].bringToFront();
      mode.slColorValues[0].setBroadcast(false).setValue(colors[_set][_color][0]).setBroadcast(true);
      mode.slColorValues[1].setBroadcast(false).setValue(colors[_set][_color][1]).setBroadcast(true);
      mode.slColorValues[2].setBroadcast(false).setValue(colors[_set][_color][2]).setBroadcast(true);
      return true;
    }
    return false;
  }

  public void updateColor(int _set, int _color) {
    int c = translateColor(colors[_set][_color]);
    if (use_gui) {
      bColors[_set][_color].setColorBackground(c);
      bColors[_set][_color].setColorForeground(c);
      bColors[_set][_color].setColorActive(c);

      if (_set == color_set && _color == color_slot) {
        mode.slColorValues[0].setBroadcast(false).setValue(colors[_set][_color][0]).setBroadcast(true);
        mode.slColorValues[1].setBroadcast(false).setValue(colors[_set][_color][1]).setBroadcast(true);
        mode.slColorValues[2].setBroadcast(false).setValue(colors[_set][_color][2]).setBroadcast(true);
      }
    }
  }

  public void updateArg(int i, String label, int _min, int _max) {
    tlArgLabels[i].setValue(label).show();
    slArgs[i].setBroadcast(false)
      .setRange(_min, _max)
      .setNumberOfTickMarks(_max - _min + 1)
      .showTickMarks(false)
      .setBroadcast(true)
      .show();
  }

  public void updateArg(int i) {
    tlArgLabels[i].hide();
    slArgs[i].hide();
  }

  public void updateTiming(int i, String label) {
    tlTimingLabels[i].setValue(label).show();
    slTimings[0][i].show();
    slTimings[1][i].show();
    slTimings[2][i].show();
  }

  public void updateTiming(int i) {
    tlTimingLabels[i].hide();
    slTimings[0][i].hide();
    slTimings[1][i].hide();
    slTimings[2][i].hide();
  }

  public void resetPatternGui() {
    switch (pattern) {
      case 0:
        updateArg(0, "Group Size", 0, 9);
        updateArg(1, "Skip After", 0, 9);
        updateArg(2, "Repeat Group", 1, 100);
        updateArg(3);
        updateArg(4);
        updateTiming(0, "Strobe");
        updateTiming(1, "Blank");
        updateTiming(2, "Tail Blank");
        updateTiming(3);
        updateTiming(4);
        updateTiming(5);
        updateTiming(6);
        updateTiming(7);
        break;
      case 1:
        updateArg(0, "Repeat Strobe", 1, 100);
        updateArg(1, "Repeat Tracer", 1, 100);
        updateArg(2);
        updateArg(3);
        updateArg(4);
        updateTiming(0, "Strobe");
        updateTiming(1, "Blank");
        updateTiming(2, "Tracer Strobe");
        updateTiming(3, "Tracer Blank");
        updateTiming(4, "Split Blank");
        updateTiming(5);
        updateTiming(6);
        updateTiming(7);
        break;
      case 2:
        updateArg(0, "Group Size", 0, 9);
        updateArg(1);
        updateArg(2);
        updateArg(3);
        updateArg(4);
        updateTiming(0, "Strobe");
        updateTiming(1, "Blank");
        updateTiming(2, "Center Strobe");
        updateTiming(3, "Tail Blank");
        updateTiming(4);
        updateTiming(5);
        updateTiming(6);
        updateTiming(7);
        break;
      case 3:
        updateArg(0, "Repeat First", 1, 100);
        updateArg(1, "Repeat Second", 1, 100);
        updateArg(2, "Repeat Third", 1, 100);
        updateArg(3, "Skip Colors", 0, 8);
        updateArg(4, "Use Third", 0, 1);
        updateTiming(0, "First Strobe");
        updateTiming(1, "First Blank");
        updateTiming(2, "Second Strobe");
        updateTiming(3, "Second Blank");
        updateTiming(4, "Third Strobe");
        updateTiming(5, "Third Blank");
        updateTiming(6, "Separating Blank");
        updateTiming(7);
        break;
      case 4:
        updateArg(0, "Group Size", 0, 9);
        updateArg(1, "Skip Between", 0, 9);
        updateArg(2, "Repeat Runner", 1, 100);
        updateArg(3);
        updateArg(4);
        updateTiming(0, "Strobe");
        updateTiming(1, "Blank");
        updateTiming(2, "Runner Strobe");
        updateTiming(3, "Runner Blank");
        updateTiming(4, "Separating Blank");
        updateTiming(5);
        updateTiming(6);
        updateTiming(7);
        break;
      case 5:
        updateArg(0, "Use Steps", 1, 7);
        updateArg(1, "Random Steps", 0, 1);
        updateArg(2, "Random Colors", 0, 1);
        updateArg(3);
        updateArg(4);
        updateTiming(0, "Blank");
        updateTiming(1, "Step 1");
        updateTiming(2, "Step 2");
        updateTiming(3, "Step 3");
        updateTiming(4, "Step 4");
        updateTiming(5, "Step 5");
        updateTiming(6, "Step 6");
        updateTiming(7, "Step 7");
        break;
      case 6:
        updateArg(0, "Random Colors", 0, 1);
        updateArg(1, "Time Multiplier", 1, 10);
        updateArg(2);
        updateArg(3);
        updateArg(4);
        updateTiming(0, "Strobe Low");
        updateTiming(1, "Strobe High");
        updateTiming(2, "Blank Low");
        updateTiming(3, "Blank High");
        updateTiming(4);
        updateTiming(5);
        updateTiming(6);
        updateTiming(7);
        break;
      case 7:
        updateArg(0, "Steps", 0, 100);
        updateArg(1, "Strobe/Blank", 0, 1);
        updateArg(2, "Up/Down/Both", 0, 2);
        updateArg(3);
        updateArg(4);
        updateTiming(0, "Strobe");
        updateTiming(1, "Blank");
        updateTiming(2, "Flux");
        updateTiming(3);
        updateTiming(4);
        updateTiming(5);
        updateTiming(6);
        updateTiming(7);
        break;
    }
  }

  public void resetArgsAndTimings() {
    switch (pattern) {
      case 0:
        setArgs(0, 0);
        setArgs(1, 0);
        setArgs(2, 0);
        setArgs(3, 0);
        setArgs(4, 0);
        for (int i = 0; i < 3; i++) {
          setTimings(i, 0, 5);
          setTimings(i, 1, 8);
          setTimings(i, 2, 0);
          setTimings(i, 3, 0);
          setTimings(i, 4, 0);
          setTimings(i, 5, 0);
          setTimings(i, 6, 0);
          setTimings(i, 7, 0);
        }
        break;
      case 1:
        setArgs(0, 1);
        setArgs(1, 1);
        setArgs(2, 0);
        setArgs(3, 0);
        setArgs(4, 0);
        for (int i = 0; i < 3; i++) {
          setTimings(i, 0, 5);
          setTimings(i, 1, 1);
          setTimings(i, 2, 20);
          setTimings(i, 3, 0);
          setTimings(i, 4, 0);
          setTimings(i, 5, 0);
          setTimings(i, 6, 0);
          setTimings(i, 7, 0);
        }
        break;
      case 2:
        setArgs(0, 0);
        setArgs(1, 0);
        setArgs(2, 0);
        setArgs(3, 0);
        setArgs(4, 0);
        for (int i = 0; i < 3; i++) {
          setTimings(i, 0, 2);
          setTimings(i, 1, 0);
          setTimings(i, 2, 5);
          setTimings(i, 3, 50);
          setTimings(i, 4, 0);
          setTimings(i, 5, 0);
          setTimings(i, 6, 0);
          setTimings(i, 7, 0);
        }
        break;
      case 3:
        setArgs(0, 2);
        setArgs(1, 2);
        setArgs(2, 0);
        setArgs(3, 0);
        setArgs(4, 0);
        for (int i = 0; i < 3; i++) {
          setTimings(i, 0, 5);
          setTimings(i, 1, 8);
          setTimings(i, 2, 1);
          setTimings(i, 3, 12);
          setTimings(i, 4, 5);
          setTimings(i, 5, 0);
          setTimings(i, 6, 0);
          setTimings(i, 7, 0);
        }
        break;
      case 4:
        setArgs(0, 0);
        setArgs(1, 0);
        setArgs(2, 5);
        setArgs(3, 0);
        setArgs(4, 0);
        for (int i = 0; i < 3; i++) {
          setTimings(i, 0, 5);
          setTimings(i, 1, 0);
          setTimings(i, 2, 1);
          setTimings(i, 3, 12);
          setTimings(i, 4, 12);
          setTimings(i, 5, 0);
          setTimings(i, 6, 0);
          setTimings(i, 7, 0);
        }
        break;
      case 5:
        setArgs(0, 5);
        setArgs(1, 0);
        setArgs(2, 0);
        setArgs(3, 0);
        setArgs(4, 0);
        for (int i = 0; i < 3; i++) {
          setTimings(i, 0, 10);
          setTimings(i, 1, 2);
          setTimings(i, 2, 4);
          setTimings(i, 3, 6);
          setTimings(i, 4, 8);
          setTimings(i, 5, 10);
          setTimings(i, 6, 0);
          setTimings(i, 7, 0);
        }
        break;
      case 6:
        setArgs(0, 1);
        setArgs(1, 4);
        setArgs(2, 0);
        setArgs(3, 0);
        setArgs(4, 0);
        for (int i = 0; i < 3; i++) {
          setTimings(i, 0, 1);
          setTimings(i, 1, 5);
          setTimings(i, 2, 5);
          setTimings(i, 3, 5);
          setTimings(i, 4, 0);
          setTimings(i, 5, 0);
          setTimings(i, 6, 0);
          setTimings(i, 7, 0);
        }
        break;
      case 7:
        setArgs(0, 10);
        setArgs(1, 1);
        setArgs(2, 2);
        setArgs(3, 0);
        setArgs(4, 0);
        for (int i = 0; i < 3; i++) {
          setTimings(i, 0, 1);
          setTimings(i, 1, 0);
          setTimings(i, 2, 1);
          setTimings(i, 3, 0);
          setTimings(i, 4, 0);
          setTimings(i, 5, 0);
          setTimings(i, 6, 0);
          setTimings(i, 7, 0);
        }
        break;
    }
  }

  // Pattern
  public void setPattern(int val) {
    if (oob(val, 0, 6)) { return; }
    int old = pattern;
    pattern = val;
    if (use_gui) {
      dlPattern.setBroadcast(false).setValue(pattern).setBroadcast(true);
      dlPattern.setCaptionLabel(dlPattern.getItem(val).get("text").toString());
      resetPatternGui();
      if (old != pattern) {
        resetArgsAndTimings();
        mode.sendMode();
      }
    }
  }

  public void sendPattern() {
    sendCommand(SER_WRITE, _PATTERN, pattern);
  }

  // Args
  public void setArgs(int i, int val) {
    if (oob(i, 0, 4)) { return; }

    args[i] = val;
    if (use_gui) {
      slArgs[i].setBroadcast(false).setValue(args[i]).setBroadcast(true);
    }
  }

  public void sendArgs(int i) {
    sendCommand(SER_WRITE, _ARGS + i, args[i]);
  }

  // Pattern Thresh
  public void setPatternThresh(float[] val) {
    if (oob(val[0], 0, val[1]) || oob(val[1], val[0], val[2]) || oob(val[2], val[1], val[3]) || oob(val[3], val[2], 32)) { return; }

    patternThresh[0] = (int)val[0];
    patternThresh[1] = (int)val[1];
    patternThresh[2] = (int)val[2];
    patternThresh[3] = (int)val[3];

    if (use_gui) {
      trPatternThresh.setBroadcast(false).setArrayValue(patternThresh).setBroadcast(true);
    }
  }

  public void setPatternThresh(int i, int val) {
    if (oob(i, 0, 3) || oob(val, 0, 32)) { return; }

    patternThresh[i] = val;
    if (use_gui) {
      trPatternThresh.setBroadcast(false).setArrayValue(patternThresh).setBroadcast(true);
    }
  }

  public void sendPatternThresh() {
    sendCommand(SER_WRITE, _PATTERNTHRESH + 0, patternThresh[0]);
    sendCommand(SER_WRITE, _PATTERNTHRESH + 1, patternThresh[1]);
    sendCommand(SER_WRITE, _PATTERNTHRESH + 2, patternThresh[2]);
    sendCommand(SER_WRITE, _PATTERNTHRESH + 3, patternThresh[3]);
  }

  // Timings
  public void setTimings(int i, int val) {
    setTimings(i / 8, i % 8, val);
  }

  public void setTimings(int x, int y, int val) {
    if (oob(x, 0, 2) || oob(y, 0, 7)) { return; }

    timings[x][y] = val;
    if (use_gui) {
      slTimings[x][y].setBroadcast(false).setValue(timings[x][y]).setBroadcast(true);
    }
  }

  public void sendTimings(int i) {
    sendTimings(i / 8, i % 8);
  }

  public void sendTimings(int x, int y) {
    sendCommand(SER_WRITE, _TIMINGS + (8 * x) + y, timings[x][y]);
  }

  // Color Thresh
  public void setColorThresh(float[] val) {
    if (oob(val[0], 0, val[1]) || oob(val[1], val[0], val[2]) || oob(val[2], val[1], val[3]) || oob(val[3], val[2], 32)) { return; }

    colorThresh[0] = (int)val[0];
    colorThresh[1] = (int)val[1];
    colorThresh[2] = (int)val[2];
    colorThresh[3] = (int)val[3];
    if (use_gui) {
      trColorThresh.setBroadcast(false).setArrayValue(val).setBroadcast(true);
    }
  }

  public void setColorThresh(int i, int val) {
    if (oob(i, 0, 3) || oob(val, 0, 32)) { return; }

    colorThresh[i] = val;
    if (use_gui) {
      trColorThresh.setBroadcast(false).setArrayValue(colorThresh).setBroadcast(true);
    }
  }

  public void sendColorThresh() {
    sendCommand(SER_WRITE, _COLORTHRESH + 0, colorThresh[0]);
    sendCommand(SER_WRITE, _COLORTHRESH + 1, colorThresh[1]);
    sendCommand(SER_WRITE, _COLORTHRESH + 2, colorThresh[2]);
    sendCommand(SER_WRITE, _COLORTHRESH + 3, colorThresh[3]);
  }

  // Num colors
  public void setNumColors(int i, int val) {
    if (oob(i, 0, 2) || oob(val, 1, 9)) { return; }

    numColors[i] = val;
    if (color_set == i && color_slot >= numColors[i]) {
      deselectColor();
    }
    if (use_gui) {
      for (int j = 0; j < 9; j++) {
        if (j < numColors[i]) { bColors[i][j].show(); } //bColorBgs[i][j].show(); }
        else                  { bColors[i][j].hide(); } //bColorBgs[i][j].hide(); }
      }
      slNumColors[i].setBroadcast(false).setValue(numColors[i]).setBroadcast(true);
    }
  }

  public void sendNumColors(int i) {
    sendCommand(SER_WRITE, _NUMCOLORS + i, numColors[i]);
  }

  // Colors
  public void setColor(int _set, int _color, int _channel, int val) {
    if (oob(_set, 0, 2) || oob(_color, 0, 8) || oob(_channel, 0, 2)) { return; }

    colors[_set][_color][_channel] = val;
    updateColor(_set, _color);
  }

  public void setColor(int _set, int _color, int[] val) {
    if (oob(_set, 0, 2) || oob(_color, 0, 8)) { return; }

    colors[_set][_color][0] = val[0];
    colors[_set][_color][1] = val[1];
    colors[_set][_color][2] = val[2];
    updateColor(_set, _color);
  }

  public void setColor(int i, int val) {
    setColor(i / 27, (i % 27) / 3, i % 3, val);
  }

  public void sendColor(int _set, int _color, int _channel) {
    if (oob(_set, 0, 2) || oob(_color, 0, 8) || oob(_channel, 0, 2)) { return; }
    sendCommand(SER_WRITE, _COLORS + (_set * 27) + (_color * 3) + _channel, colors[_set][_color][_channel]);
  }

  public void sendColor(int _set, int _color) {
    if (oob(_set, 0, 2) || oob(_color, 0, 8)) { return; }
    sendColor(_set, _color, 0);
    sendColor(_set, _color, 1);
    sendColor(_set, _color, 2);
  }

  //********************************************************************************
  //** JSON
  //********************************************************************************
  public void fromJSON(JSONObject j) {
    setPattern(j.getInt("pattern"));
    setArgs(j.getJSONArray("args"));
    setPatternThresh(j.getJSONArray("pattern_thresh"));
    setTimings(j.getJSONArray("timings"));
    setColorThresh(j.getJSONArray("color_thresh"));
    setNumColors(j.getJSONArray("num_colors"));
    setColors(j.getJSONArray("colors"));
  }

  public JSONObject getJSON() {
    JSONObject jo = new JSONObject();
    jo.setInt("pattern", pattern);
    jo.setJSONArray("args", getArgs());
    jo.setJSONArray("pattern_thresh", getPatternThresh());
    jo.setJSONArray("timings", getTimings());
    jo.setJSONArray("color_thresh", getColorThresh());
    jo.setJSONArray("num_colors", getNumColors());
    jo.setJSONArray("colors", getColors());
    return jo;
  }

  public JSONArray getArgs() {
    JSONArray ja = new JSONArray();
    for (int i = 0; i < 5; i++) {
      ja.setInt(i, args[i]);
    }
    return ja;
  }

  public JSONArray getPatternThresh() {
    JSONArray ja = new JSONArray();
    for (int i = 0; i < 4; i++) {
      ja.setInt(i, patternThresh[i]);
    }
    return ja;
  }

  public JSONArray getTimings() {
    JSONArray ja = new JSONArray();
    for (int i = 0; i < 3; i++) {
      JSONArray ja1 = new JSONArray();
      for (int j = 0; j < 8; j++) {
        ja1.setInt(j, timings[i][j]);
      }
      ja.setJSONArray(i, ja1);
    }
    return ja;
  }

  public JSONArray getColorThresh() {
    JSONArray ja = new JSONArray();
    for (int i = 0; i < 4; i++) {
      ja.setInt(i, colorThresh[i]);
    }
    return ja;
  }

  public JSONArray getNumColors() {
    JSONArray ja = new JSONArray();
    for (int i = 0; i < 3; i++) {
      ja.setInt(i, numColors[i]);
    }
    return ja;
  }

  public JSONArray getColors() {
    JSONArray ja = new JSONArray();
    for (int i = 0; i < 3; i++) {
      JSONArray ja1 = new JSONArray();
      for (int j = 0; j < 9; j++) {
        JSONArray ja2 = new JSONArray();
        for (int k = 0; k < 3; k++) {
          if (j < numColors[i]) {
            ja2.setInt(k, colors[i][j][k]);
          } else {
            ja2.setInt(k, 0);
          }
        }
        ja1.setJSONArray(j, ja2);
      }
      ja.setJSONArray(i, ja1);
    }
    return ja;
  }


  public void setArgs(JSONArray ja) {
    for (int i = 0; i < 5; i++) {
      try {
        setArgs(i, ja.getInt(i));
      } catch (Exception ex) {
        setArgs(i, 0);
      }
    }
  }

  public void setPatternThresh(JSONArray ja) {
    try {
      for (int i = 0; i < 4; i++) {
        setPatternThresh(i, ja.getInt(i));
      }
    } catch (Exception ex) {
      for (int i = 0; i < 2; i++) {
        JSONArray ja1 = ja.getJSONArray(i);
        for (int j = 0; j < 2; j++) {
          setPatternThresh((i * 2) + j, ja1.getInt(j));
        }
      }
    }
  }

  public void setTimings(JSONArray ja) {
    for (int i = 0; i < 3; i++) {
      JSONArray ja1 = ja.getJSONArray(i);
      for (int j = 0; j < 8; j++) {
        try {
          setTimings(i, j, ja1.getInt(j));
        } catch (Exception ex) {
          setTimings(i, j, 0);
        }
      }
    }
  }

  public void setColorThresh(JSONArray ja) {
    try {
      for (int i = 0; i < 4; i++) {
        setColorThresh(i, ja.getInt(i));
      }
    } catch (Exception ex) {
      for (int i = 0; i < 2; i++) {
        JSONArray ja1 = ja.getJSONArray(i);
        for (int j = 0; j < 2; j++) {
          setPatternThresh((i * 2) + j, ja1.getInt(j));
        }
      }
    }
  }

  public void setNumColors(JSONArray ja) {
    for (int i = 0; i < 3; i++) {
      setNumColors(i, ja.getInt(i));
    }
  }

  public void setColors(JSONArray ja) {
    for (int _set = 0; _set < 3; _set++) {
      JSONArray ja1 = ja.getJSONArray(_set);
      for (int _color = 0; _color < 9; _color++) {
        JSONArray ja2 = ja1.getJSONArray(_color);
        for (int _channel = 0; _channel < 3; _channel++) {
          setColor(_set, _color, _channel, ja2.getInt(_channel));
        }
      }
    }
  }
}
  public void settings() {  size(1060, 720);  smooth(8); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "vectrui" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
